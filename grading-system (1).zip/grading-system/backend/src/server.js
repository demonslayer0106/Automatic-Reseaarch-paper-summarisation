require('dotenv').config();
const express = require('express');
const cors = require('cors');

const { initDb } = require('./db');
const authRoutes = require('./routes/authRoutes');
const assessmentRoutes = require('./routes/assessmentRoutes');
const answerSheetRoutes = require('./routes/answerSheetRoutes');
const referenceDocRoutes = require('./routes/referenceDocRoutes');
const gradingRoutes = require('./routes/gradingRoutes');
const reviewRoutes = require('./routes/reviewRoutes');
const evaluationRoutes = require('./routes/evaluationRoutes');

if (!process.env.JWT_SECRET) {
  console.error('Missing JWT_SECRET in .env — copy .env.example to .env and set one.');
  process.exit(1);
}

if (!process.env.DATABASE_URL) {
  console.error('Missing DATABASE_URL in .env — a Postgres connection string is required (see .env.example).');
  process.exit(1);
}

const app = express();

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '5mb' })); // reference-document text pastes can be long

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth', authRoutes);
app.use('/api/assessments', assessmentRoutes);       // chunk 3
app.use('/api/answer-sheets', answerSheetRoutes);    // chunk 3 (upload) + chunk 4 (processing)
app.use('/api/reference-documents', referenceDocRoutes); // chunk 5 (RAG corpus)
app.use('/api/grading', gradingRoutes);              // chunk 5 (run grading + final results)
app.use('/api/review', reviewRoutes);                // chunk 6 (human review)
app.use('/api/evaluation', evaluationRoutes);        // human-vs-AI evaluation dataset + metrics

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

// Global error handler — catches multer file-filter errors, size-limit errors,
// and anything else thrown/passed to next(err) so the client always gets JSON.
app.use((err, req, res, next) => {
  if (err) {
    const status = err.status || 400;
    return res.status(status).json({ error: err.message || 'Something went wrong' });
  }
  next();
});

const PORT = process.env.PORT || 4000;

// initDb() now issues real (async) CREATE TABLE/CREATE EXTENSION queries
// against Postgres, so the server only starts listening once that's done —
// otherwise the first request could race the schema being created.
initDb()
  .then(() => {
    app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('Failed to initialize the database:', err.message);
    process.exit(1);
  });
