const { Pool } = require('pg');

/**
 * DRIVER NOTE: Postgres, via the `pg` package, connected using DATABASE_URL
 * (backend/.env). Vector search for the RAG corpus uses the `pgvector`
 * Postgres extension instead of sqlite-vec — same idea (a `vector` column
 * type + nearest-neighbor distance operators), just running as a real
 * database server instead of a single file, which is what makes this
 * deployable anywhere with more than one server instance or an ephemeral
 * filesystem (see README).
 *
 * Every other file in this project was written against a synchronous,
 * better-sqlite3-style `db.prepare(sql).get/all/run(params)` API using `?`
 * placeholders. Postgres has no synchronous driver (every query is a real
 * network round trip), so that exact shape isn't possible — but the shim
 * below keeps everything ELSE about that shape the same: same `?`
 * placeholders (converted to Postgres's `$1, $2...` internally), same
 * get/all/run method names, same `db.transaction(fn)` call pattern. The
 * only mechanical change needed elsewhere was adding `await` and, inside a
 * transaction callback, using the `tx` handle passed into it instead of the
 * outer `db` (so every query in that transaction runs on the same
 * connection — see makeDb/transaction below).
 */
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function toPgSql(sql) {
  let i = 0;
  return sql.replace(/\?/g, () => `$${++i}`);
}

function makeDb(executor) {
  return {
    async run(sql, params = []) {
      const result = await executor.query(toPgSql(sql), params);
      return { changes: result.rowCount, rows: result.rows };
    },
    async get(sql, params = []) {
      const result = await executor.query(toPgSql(sql), params);
      return result.rows[0];
    },
    async all(sql, params = []) {
      const result = await executor.query(toPgSql(sql), params);
      return result.rows;
    },
    // Runs `fn(tx)` inside BEGIN/COMMIT/ROLLBACK on a single dedicated
    // connection. `fn` must issue all its queries through the `tx` handle
    // it's given (tx.run/tx.get/tx.all), not the outer `db` — the outer
    // `db` draws a fresh connection from the pool per call, which would
    // silently break atomicity.
    transaction(fn) {
      return async (...args) => {
        const client = await pool.connect();
        const tx = makeDb(client);
        try {
          await client.query('BEGIN');
          const result = await fn(tx, ...args);
          await client.query('COMMIT');
          return result;
        } catch (err) {
          await client.query('ROLLBACK');
          throw err;
        } finally {
          client.release();
        }
      };
    },
  };
}

const db = makeDb(pool);

const EMBEDDING_DIM = Number(process.env.EMBEDDING_DIM || 768);

async function initDb() {
  await pool.query('CREATE EXTENSION IF NOT EXISTS vector');

  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id            SERIAL PRIMARY KEY,
      name          TEXT NOT NULL,
      email         TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role          TEXT NOT NULL CHECK(role IN ('admin','faculty')),
      created_at    TIMESTAMPTZ DEFAULT NOW()
    );
  `);
  // ---------- Chunk 3: Upload & Setup ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS assessments (
      id                    TEXT PRIMARY KEY,
      title                 TEXT NOT NULL,
      created_by            INTEGER NOT NULL REFERENCES users(id),
      reference_updated_at  TIMESTAMPTZ,
      created_at            TIMESTAMPTZ DEFAULT NOW()
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS rubric_items (
      id               TEXT PRIMARY KEY,
      assessment_id    TEXT NOT NULL REFERENCES assessments(id),
      question_number  TEXT NOT NULL,
      question_text    TEXT NOT NULL,
      max_marks        REAL NOT NULL CHECK(max_marks > 0),
      sort_order       INTEGER NOT NULL,
      UNIQUE(assessment_id, question_number)
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS rubric_criteria (
      id              TEXT PRIMARY KEY,
      rubric_item_id  TEXT NOT NULL REFERENCES rubric_items(id),
      description     TEXT NOT NULL,
      marks           REAL NOT NULL CHECK(marks >= 0)
    );
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS answer_sheets (
      id                  TEXT PRIMARY KEY,
      assessment_id       TEXT NOT NULL REFERENCES assessments(id),
      student_identifier  TEXT NOT NULL,
      file_name           TEXT NOT NULL,
      file_path           TEXT NOT NULL,
      status              TEXT NOT NULL DEFAULT 'uploaded'
                            CHECK(status IN ('uploaded','processing','processed','failed')),
      uploaded_by         INTEGER NOT NULL REFERENCES users(id),
      uploaded_at         TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ---------- Chunk 4: OCR / Segmentation output ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS structured_answers (
      id                TEXT PRIMARY KEY,
      answer_sheet_id   TEXT NOT NULL REFERENCES answer_sheets(id),
      question_number   TEXT NOT NULL,
      answer_text       TEXT NOT NULL,
      ocr_confidence    REAL NOT NULL,
      UNIQUE(answer_sheet_id, question_number)
    );
  `);

  // ---------- Chunk 5: AI Grading Agent — RAG corpus ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_sources (
      id            TEXT PRIMARY KEY,
      assessment_id TEXT NOT NULL REFERENCES assessments(id),
      title         TEXT NOT NULL,
      source_path   TEXT,
      chunk_count   INTEGER NOT NULL DEFAULT 0,
      uploaded_at   TIMESTAMPTZ DEFAULT NOW()
    );
  `);
  // The embedding lives directly on the chunk row — pgvector needs no
  // separate rowid-linked virtual table the way sqlite-vec did, so the
  // seq/rowid bridging that used to exist just for that is gone.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS document_chunks (
      id               TEXT PRIMARY KEY,
      source_id        TEXT NOT NULL REFERENCES reference_sources(id),
      assessment_id    TEXT NOT NULL REFERENCES assessments(id),
      source_title     TEXT NOT NULL,
      chunk_text       TEXT NOT NULL,
      embedding        vector(${EMBEDDING_DIM})
    );
  `);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_document_chunks_assessment ON document_chunks(assessment_id);`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS grading_results (
      id                  TEXT PRIMARY KEY,
      assessment_id       TEXT NOT NULL REFERENCES assessments(id),
      answer_sheet_id     TEXT NOT NULL REFERENCES answer_sheets(id),
      question_number     TEXT NOT NULL,
      student_identifier  TEXT NOT NULL,
      question_text       TEXT NOT NULL,
      answer_text         TEXT NOT NULL,
      marks_awarded       REAL NOT NULL,
      max_marks           REAL NOT NULL,
      criterion_results   TEXT NOT NULL,
      explanation          TEXT NOT NULL,
      evidence             TEXT NOT NULL,
      confidence_score     REAL NOT NULL,
      review_status        TEXT NOT NULL DEFAULT 'pending_review'
                            CHECK(review_status IN ('auto_approved','pending_review','reviewed')),
      is_current            INTEGER NOT NULL DEFAULT 1,
      grading_run_id        TEXT NOT NULL,
      grading_model         TEXT NOT NULL,
      ocr_model              TEXT,
      evidence_as_of          TIMESTAMPTZ,
      created_at          TIMESTAMPTZ DEFAULT NOW()
    );
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_grading_results_current
      ON grading_results(answer_sheet_id, question_number) WHERE is_current = 1;
  `);

  // ---------- Chunk 5: async grading jobs ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS grading_jobs (
      id              TEXT PRIMARY KEY,
      answer_sheet_id TEXT NOT NULL REFERENCES answer_sheets(id),
      status          TEXT NOT NULL DEFAULT 'queued'
                        CHECK(status IN ('queued','running','completed','failed')),
      total           INTEGER NOT NULL DEFAULT 0,
      completed       INTEGER NOT NULL DEFAULT 0,
      error           TEXT,
      started_at      TIMESTAMPTZ,
      finished_at     TIMESTAMPTZ,
      created_at      TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ---------- Chunk 6: Human Review ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS review_decisions (
      id                    TEXT PRIMARY KEY,
      grading_result_id     TEXT NOT NULL REFERENCES grading_results(id),
      reviewer_id           INTEGER NOT NULL REFERENCES users(id),
      final_marks_awarded   REAL NOT NULL,
      reviewer_notes        TEXT,
      decided_at            TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ---------- Audit trail ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS audit_log (
      id              TEXT PRIMARY KEY,
      actor_user_id   INTEGER REFERENCES users(id),
      action          TEXT NOT NULL,
      entity_type     TEXT NOT NULL,
      entity_id       TEXT NOT NULL,
      metadata        TEXT,
      created_at      TIMESTAMPTZ DEFAULT NOW()
    );
  `);

  // ---------- Evaluation dataset (AI grade vs human grade) ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS human_evaluations (
      id                     TEXT PRIMARY KEY,
      grading_result_id      TEXT NOT NULL REFERENCES grading_results(id),
      evaluator_id            INTEGER NOT NULL REFERENCES users(id),
      human_marks_awarded    REAL NOT NULL,
      notes                  TEXT,
      created_at              TIMESTAMPTZ DEFAULT NOW()
    );
  `);
}

module.exports = { db, initDb };
