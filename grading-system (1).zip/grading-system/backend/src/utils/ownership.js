const { db } = require('../db');

/**
 * Fetches an assessment and checks whether `user` is allowed to see it.
 * Admins can access every assessment. Faculty can only access assessments
 * they personally created. Returns { assessment } on success, or
 * { error: { status, message } } on failure — callers check `.error`
 * rather than relying on a thrown exception (see route files, which wrap
 * handlers in asyncHandler so an unexpected throw still reaches the
 * client as JSON instead of hanging the request).
 */
async function checkAssessmentAccess(assessmentId, user) {
  const assessment = await db.get('SELECT * FROM assessments WHERE id = ?', [assessmentId]);
  if (!assessment) {
    return { error: { status: 404, message: 'Assessment not found' } };
  }
  if (user.role !== 'admin' && assessment.created_by !== user.id) {
    return { error: { status: 403, message: 'You do not have access to this assessment' } };
  }
  return { assessment };
}

/**
 * Same access rule, starting from an answer_sheet_id instead — resolves
 * the sheet's assessment first, then applies the same check.
 */
async function checkAnswerSheetAccess(answerSheetId, user) {
  const sheet = await db.get('SELECT * FROM answer_sheets WHERE id = ?', [answerSheetId]);
  if (!sheet) {
    return { error: { status: 404, message: 'Answer sheet not found' } };
  }
  const { assessment, error } = await checkAssessmentAccess(sheet.assessment_id, user);
  if (error) return { error };
  return { sheet, assessment };
}

/**
 * Same access rule, starting from a grading_result_id.
 */
async function checkGradingResultAccess(gradingResultId, user) {
  const result = await db.get('SELECT * FROM grading_results WHERE id = ?', [gradingResultId]);
  if (!result) {
    return { error: { status: 404, message: 'Grading result not found' } };
  }
  const { assessment, error } = await checkAssessmentAccess(result.assessment_id, user);
  if (error) return { error };
  return { result, assessment };
}

module.exports = { checkAssessmentAccess, checkAnswerSheetAccess, checkGradingResultAccess };
