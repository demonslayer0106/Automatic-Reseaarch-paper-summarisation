const { db } = require('../db');
const { newId } = require('./ids');

/**
 * Records one audit entry. Called at the key action points listed in
 * README's audit trail section — grading runs, review decisions, rubric
 * and reference-material changes. Never throws: a logging failure should
 * never break the action it's logging. Callers deliberately don't await
 * this (fire-and-forget), same as before the Postgres migration — it's
 * safe not to await because every failure is caught right here.
 */
async function logAudit(actorUserId, action, entityType, entityId, metadata = {}) {
  try {
    await db.run(
      'INSERT INTO audit_log (id, actor_user_id, action, entity_type, entity_id, metadata) VALUES (?, ?, ?, ?, ?, ?)',
      [newId('audit'), actorUserId ?? null, action, entityType, entityId, JSON.stringify(metadata)]
    );
  } catch (err) {
    console.error('Audit log write failed (non-fatal):', err.message);
  }
}

module.exports = { logAudit };
