/**
 * Wraps an async Express route handler so a rejected promise (e.g. a
 * Postgres query failing) is forwarded to next(err) instead of being
 * silently dropped — Express 4 does not do this automatically for async
 * handlers, and every controller became async as part of the Postgres
 * migration (the old synchronous better-sqlite3 calls couldn't reject).
 * The existing global error handler in server.js turns whatever reaches
 * it into a JSON error response.
 */
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = { asyncHandler };
