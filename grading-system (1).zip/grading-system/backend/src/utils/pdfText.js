const pdfjsLib = require('pdfjs-dist/legacy/build/pdf.mjs');

/**
 * Extracts embedded text from a digitally-typed PDF (lecture notes, slides
 * exported to PDF, typed answer keys). This does NOT do OCR — there's no
 * text layer to read in a scanned/handwritten PDF, which is exactly why
 * answer sheets (pipeline/ocrSegmentation.js) use Gemini's vision instead.
 */
async function extractPdfText(pdfBuffer) {
  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(pdfBuffer),
    isEvalSupported: false,
  });
  const doc = await loadingTask.promise;

  const pageTexts = [];
  for (let pageNum = 1; pageNum <= doc.numPages; pageNum++) {
    const page = await doc.getPage(pageNum);
    const content = await page.getTextContent();
    let pageText = '';
    for (const item of content.items) {
      pageText += item.str;
      pageText += item.hasEOL ? '\n' : ' ';
    }
    pageTexts.push(pageText);
  }
  // destroy() lives on the loading task in this pdfjs-dist version, not on
  // the resolved document proxy (doc.destroy() doesn't exist and used to
  // throw here — this code path was never actually exercised before, since
  // nothing that called extractPdfText had a working route in front of it).
  await loadingTask.destroy();

  return pageTexts.join('\n\n');
}

module.exports = { extractPdfText };
