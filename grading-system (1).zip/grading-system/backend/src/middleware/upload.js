const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { newId } = require('../utils/ids');

const UPLOAD_DIR = path.join(__dirname, '..', '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.pdf';
    cb(null, `${newId('sheet')}${ext}`);
  },
});

function fileFilter(req, file, cb) {
  if (file.mimetype !== 'application/pdf') {
    return cb(new Error('Only PDF files are accepted'));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
});

// For reference-document (RAG) uploads and rubric/question extraction:
// unlike answer sheets, these files are only ever read once (text
// extracted, then embedded or sent to Gemini) and never need to be
// re-opened later, so there's no reason to persist them to disk —
// memoryStorage keeps req.file(s)[].buffer in memory and nothing touches
// the filesystem at all.
const DOC_MIME_TYPES = new Set([
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
  'application/vnd.openxmlformats-officedocument.presentationml.presentation', // .pptx
  'text/plain',
  'text/markdown',
]);

function docFileFilter(req, file, cb) {
  if (!DOC_MIME_TYPES.has(file.mimetype)) {
    return cb(new Error('Only PDF, DOCX, PPTX, TXT, or MD files are accepted'));
  }
  cb(null, true);
}

const uploadDocs = multer({
  storage: multer.memoryStorage(),
  fileFilter: docFileFilter,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
});

module.exports = { upload, uploadDocs, UPLOAD_DIR };
