const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { asyncHandler } = require('../utils/asyncHandler');
const { recordEvaluation, getMetrics } = require('../controllers/evaluationController');

router.use(authenticate);

router.post('/:id', requireRole('admin', 'faculty'), asyncHandler(recordEvaluation));
router.get('/metrics', requireRole('admin', 'faculty'), asyncHandler(getMetrics));

module.exports = router;
