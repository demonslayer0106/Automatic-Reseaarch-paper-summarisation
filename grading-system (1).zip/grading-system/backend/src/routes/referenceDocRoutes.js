const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { uploadDocs } = require('../middleware/upload');
const { asyncHandler } = require('../utils/asyncHandler');
const { ingestPath, addPastedText, uploadFile, listSources } = require('../controllers/referenceDocController');

router.use(authenticate);

router.post('/ingest-path', requireRole('admin'), asyncHandler(ingestPath)); // folder/file on the server's disk
router.post('/', requireRole('admin'), asyncHandler(addPastedText));         // pasted text
router.post('/upload', requireRole('admin'), uploadDocs.single('file'), asyncHandler(uploadFile)); // browser file upload (PDF/DOCX/PPTX)
router.get('/', asyncHandler(listSources));

module.exports = router;
