const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { asyncHandler } = require('../utils/asyncHandler');
const { startGrading, getJobStatus, listResults } = require('../controllers/gradingController');

router.use(authenticate);

router.post('/run', requireRole('admin', 'faculty'), asyncHandler(startGrading)); // returns a jobId immediately, grades in the background
router.get('/jobs/:id', requireRole('admin', 'faculty'), asyncHandler(getJobStatus)); // poll for progress
router.get('/results', asyncHandler(listResults)); // ownership-checked inside the controller

module.exports = router;
