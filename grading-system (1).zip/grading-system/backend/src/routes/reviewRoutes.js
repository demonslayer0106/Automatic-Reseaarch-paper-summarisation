const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { asyncHandler } = require('../utils/asyncHandler');
const { getReviewQueue, submitDecision } = require('../controllers/reviewController');

router.use(authenticate);

router.get('/queue', requireRole('admin', 'faculty'), asyncHandler(getReviewQueue));
router.post('/:id/decide', requireRole('admin', 'faculty'), asyncHandler(submitDecision));

module.exports = router;
