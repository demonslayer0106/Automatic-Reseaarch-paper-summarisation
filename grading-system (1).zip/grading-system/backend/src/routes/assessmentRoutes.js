const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { uploadDocs } = require('../middleware/upload');
const { asyncHandler } = require('../utils/asyncHandler');
const {
  createAssessment,
  listAssessments,
  getAssessment,
  extractRubric,
} = require('../controllers/assessmentController');

router.use(authenticate);

router.post('/', requireRole('admin', 'faculty'), asyncHandler(createAssessment)); // faculty create their own; ownership tracked via created_by
router.get('/', asyncHandler(listAssessments)); // scoped by ownership inside the controller — admin sees all, faculty see their own
router.get('/:id', asyncHandler(getAssessment)); // ownership-checked inside the controller

// Draft-only: extracts questions[] from an uploaded rubric (+ optional
// separate questions) file via Gemini — nothing is saved here, see
// extractRubric's docstring. The frontend feeds the result into the
// same manual form used by POST '/' above.
router.post(
  '/extract-rubric',
  requireRole('admin', 'faculty'),
  uploadDocs.fields([
    { name: 'rubricFile', maxCount: 1 },
    { name: 'questionsFile', maxCount: 1 },
  ]),
  asyncHandler(extractRubric)
);

module.exports = router;
