const express = require('express');
const router = express.Router();
const { register, login, me } = require('../controllers/authController');
const { asyncHandler } = require('../utils/asyncHandler');
const { authenticate } = require('../middleware/auth');

router.post('/register', asyncHandler(register));
router.post('/login', asyncHandler(login));
router.get('/me', authenticate, me); // synchronous — just reads req.user set by authenticate

module.exports = router;
