const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../db');

const SALT_ROUNDS = 10;

function signToken(user) {
  return jwt.sign(
    { id: user.id, name: user.name, email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );
}

async function register(req, res) {
  const { name, email, password, role, adminInviteCode } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'name, email, and password are required' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'password must be at least 8 characters' });
  }

  // SECURITY: the public registration endpoint must never let a caller grant
  // themselves admin just by putting "admin" in the request body. Faculty
  // self-registration stays open; admin accounts require a shared secret
  // (ADMIN_INVITE_CODE in .env) that only someone who already has server
  // access would know. This is a deliberately simple prototype-grade gate —
  // see README for the production-grade alternative (an existing admin
  // creates other admins through an authenticated endpoint).
  let finalRole = 'faculty';
  if (role === 'admin') {
    const expectedCode = process.env.ADMIN_INVITE_CODE;
    if (!expectedCode) {
      return res.status(403).json({ error: 'Admin registration is not enabled on this server' });
    }
    if (adminInviteCode !== expectedCode) {
      return res.status(403).json({ error: 'Invalid admin invite code' });
    }
    finalRole = 'admin';
  } else if (role && role !== 'faculty') {
    return res.status(400).json({ error: 'role must be "faculty" (or "admin" with a valid invite code)' });
  }

  const existing = await db.get('SELECT id FROM users WHERE email = ?', [email]);
  if (existing) {
    return res.status(409).json({ error: 'An account with this email already exists' });
  }

  const password_hash = await bcrypt.hash(password, SALT_ROUNDS);
  const inserted = await db.get(
    'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?) RETURNING id',
    [name, email, password_hash, finalRole]
  );

  const user = { id: inserted.id, name, email, role: finalRole };
  const token = signToken(user);
  res.status(201).json({ token, user });
}

async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required' });
  }

  const row = await db.get('SELECT * FROM users WHERE email = ?', [email]);
  // Deliberately identical error for "no such user" and "wrong password" —
  // don't leak which one it was, that's an account-enumeration risk.
  if (!row) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const valid = await bcrypt.compare(password, row.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const user = { id: row.id, name: row.name, email: row.email, role: row.role };
  const token = signToken(user);
  res.json({ token, user });
}

function me(req, res) {
  // req.user is set by the authenticate middleware after verifying the JWT
  res.json({ user: req.user });
}

module.exports = { register, login, me };
