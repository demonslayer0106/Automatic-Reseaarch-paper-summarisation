const { db } = require('../db');
const { newId } = require('../utils/ids');
const { logAudit } = require('../utils/audit');
const { checkAssessmentAccess } = require('../utils/ownership');
const { extractRubricFromFiles } = require('../pipeline/rubricExtraction');

/**
 * Validates the whole questions[] payload BEFORE touching the database:
 *  - every question has a number, text, and a positive max marks
 *  - every criterion has non-negative marks
 *  - a question's criteria marks sum to exactly its max marks (the old
 *    version only checked this in the frontend form — a direct API call
 *    could skip it entirely and save an internally-inconsistent rubric)
 *  - no duplicate question numbers within the same assessment (belt-and-
 *    suspenders alongside the DB UNIQUE constraint — this gives a much
 *    friendlier error message than a raw SQLite constraint failure)
 * Returns an error string, or null if everything is valid.
 */
function validateQuestions(questions) {
  if (!Array.isArray(questions) || questions.length === 0) {
    return 'At least one question is required';
  }

  const seenNumbers = new Set();
  for (const q of questions) {
    if (!q.questionNumber || typeof q.questionNumber !== 'string') {
      return 'Every question needs a questionNumber';
    }
    const normalized = q.questionNumber.trim().toUpperCase();
    if (seenNumbers.has(normalized)) {
      return `Duplicate question number "${q.questionNumber}" — each question in an assessment needs a unique number`;
    }
    seenNumbers.add(normalized);

    if (!q.questionText || typeof q.questionText !== 'string') {
      return `${q.questionNumber}: questionText is required`;
    }
    if (typeof q.maxMarks !== 'number' || !Number.isFinite(q.maxMarks) || q.maxMarks <= 0) {
      return `${q.questionNumber}: maxMarks must be a positive number`;
    }
    if (!Array.isArray(q.criteria) || q.criteria.length === 0) {
      return `${q.questionNumber}: at least one rubric criterion is required`;
    }
    let criteriaSum = 0;
    for (const c of q.criteria) {
      if (typeof c.marks !== 'number' || !Number.isFinite(c.marks) || c.marks < 0) {
        return `${q.questionNumber}: every criterion needs non-negative numeric marks`;
      }
      if (!c.description || typeof c.description !== 'string') {
        return `${q.questionNumber}: every criterion needs a description`;
      }
      criteriaSum += c.marks;
    }
    if (Math.abs(criteriaSum - q.maxMarks) > 0.01) {
      return `${q.questionNumber}: criteria marks sum to ${criteriaSum}, but maxMarks is ${q.maxMarks} — they must match`;
    }
  }
  return null;
}

async function createAssessment(req, res) {
  const { title, questions } = req.body;

  if (!title || typeof title !== 'string' || !title.trim()) {
    return res.status(400).json({ error: 'title is required' });
  }
  const validationError = validateQuestions(questions);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  const assessmentId = newId('assess');

  const runTransaction = db.transaction(async (tx) => {
    await tx.run('INSERT INTO assessments (id, title, created_by) VALUES (?, ?, ?)', [
      assessmentId,
      title.trim(),
      req.user.id,
    ]);
    for (const [index, q] of questions.entries()) {
      const rubricItemId = newId('rubric');
      await tx.run(
        `INSERT INTO rubric_items (id, assessment_id, question_number, question_text, max_marks, sort_order)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [rubricItemId, assessmentId, q.questionNumber.trim(), q.questionText.trim(), q.maxMarks, index]
      );
      for (const c of q.criteria) {
        await tx.run('INSERT INTO rubric_criteria (id, rubric_item_id, description, marks) VALUES (?, ?, ?, ?)', [
          newId('crit'),
          rubricItemId,
          c.description.trim(),
          c.marks,
        ]);
      }
    }
  });

  try {
    await runTransaction();
  } catch (err) {
    // Catches the DB-level UNIQUE/CHECK constraints as a fallback in case
    // something slipped past validateQuestions above (e.g. a race, or a
    // future code path that calls this without going through it).
    return res.status(400).json({ error: `Could not save assessment: ${err.message}` });
  }

  logAudit(req.user.id, 'assessment.created', 'assessment', assessmentId, { title: title.trim(), questionCount: questions.length });

  res.status(201).json(await getAssessmentById(assessmentId));
}

async function getAssessmentById(assessmentId) {
  const assessment = await db.get('SELECT * FROM assessments WHERE id = ?', [assessmentId]);
  if (!assessment) return null;

  const rubricItems = await db.all('SELECT * FROM rubric_items WHERE assessment_id = ? ORDER BY sort_order', [
    assessmentId,
  ]);

  const questions = [];
  for (const item of rubricItems) {
    const criteria = await db.all('SELECT * FROM rubric_criteria WHERE rubric_item_id = ?', [item.id]);
    questions.push({
      id: item.id,
      questionNumber: item.question_number,
      questionText: item.question_text,
      maxMarks: item.max_marks,
      criteria: criteria.map((c) => ({ id: c.id, description: c.description, marks: c.marks })),
    });
  }

  return {
    id: assessment.id,
    title: assessment.title,
    createdBy: assessment.created_by,
    createdAt: assessment.created_at,
    questions,
  };
}

/**
 * SECURITY: scoped by ownership. Admin sees every assessment; faculty only
 * see assessments they personally created — this was previously
 * unfiltered, meaning any faculty account could see every assessment on
 * the server just by opening the dropdown.
 */
async function listAssessments(req, res) {
  const rows =
    req.user.role === 'admin'
      ? await db.all('SELECT id, title, created_at FROM assessments ORDER BY created_at DESC')
      : await db.all('SELECT id, title, created_at FROM assessments WHERE created_by = ? ORDER BY created_at DESC', [
          req.user.id,
        ]);
  res.json({ assessments: rows.map((r) => ({ id: r.id, title: r.title, createdAt: r.created_at })) });
}

async function getAssessment(req, res) {
  const { error } = await checkAssessmentAccess(req.params.id, req.user);
  if (error) return res.status(error.status).json({ error: error.message });
  res.json({ assessment: await getAssessmentById(req.params.id) });
}

/**
 * Extracts a draft questions[] array from an uploaded rubric document
 * (req.files.rubricFile) and, optionally, a separate question paper
 * (req.files.questionsFile) — for when the rubric doesn't restate the
 * question text and grading criteria are given only by question number.
 * This does NOT save anything: it returns the same shape the manual
 * AssessmentForm already builds, so the frontend can drop it straight
 * into that form for the person to review/edit before calling the
 * existing POST /api/assessments to actually create it.
 */
async function extractRubric(req, res) {
  const rubricFile = req.files?.rubricFile?.[0];
  const questionsFile = req.files?.questionsFile?.[0];

  if (!rubricFile) {
    return res.status(400).json({ error: 'A rubric file is required (field name: rubricFile)' });
  }

  try {
    const questions = await extractRubricFromFiles({
      rubricBuffer: rubricFile.buffer,
      rubricFileName: rubricFile.originalname,
      questionsBuffer: questionsFile ? questionsFile.buffer : null,
      questionsFileName: questionsFile ? questionsFile.originalname : null,
    });

    logAudit(req.user.id, 'assessment.rubric_extracted', 'assessment', 'draft', {
      rubricFileName: rubricFile.originalname,
      questionsFileName: questionsFile ? questionsFile.originalname : null,
      questionCount: questions.length,
    });

    res.json({ questions });
  } catch (err) {
    res.status(422).json({ error: `Could not extract a rubric from the uploaded file(s): ${err.message}` });
  }
}

module.exports = { createAssessment, listAssessments, getAssessment, getAssessmentById, extractRubric };
