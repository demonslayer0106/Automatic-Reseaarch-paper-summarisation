const fs = require('fs');
const { db } = require('../db');
const { newId } = require('../utils/ids');
const { processAnswerSheet } = require('../pipeline/ocrSegmentation');
const { logAudit } = require('../utils/audit');
const { checkAnswerSheetAccess } = require('../utils/ownership');

async function triggerProcessing(req, res) {
  const sheetId = req.params.id;

  const { sheet, error } = await checkAnswerSheetAccess(sheetId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  await db.run('UPDATE answer_sheets SET status = ? WHERE id = ?', ['processing', sheetId]);

  try {
    const pdfBuffer = fs.readFileSync(sheet.file_path);
    const structuredAnswers = await processAnswerSheet(pdfBuffer);

    // The UNIQUE(answer_sheet_id, question_number) constraint added to
    // structured_answers means a duplicate question number from Gemini's
    // response would fail this insert — parseOcrResponse() in
    // ocrSegmentation.js already merges duplicates before we get here, so
    // this is a real guarantee, not just an assumption.
    const runTransaction = db.transaction(async (tx) => {
      await tx.run('DELETE FROM structured_answers WHERE answer_sheet_id = ?', [sheetId]);
      for (const ans of structuredAnswers) {
        await tx.run(
          `INSERT INTO structured_answers (id, answer_sheet_id, question_number, answer_text, ocr_confidence)
           VALUES (?, ?, ?, ?, ?)`,
          [newId('sa'), sheetId, ans.questionNumber, ans.answerText, ans.confidence]
        );
      }
      await tx.run('UPDATE answer_sheets SET status = ? WHERE id = ?', ['processed', sheetId]);
    });
    await runTransaction();

    logAudit(req.user.id, 'answer_sheet.processed', 'answer_sheet', sheetId, {
      questionsDetected: structuredAnswers.length,
      ocrModel: process.env.OCR_MODEL || 'gemini-2.5-flash',
    });

    res.json({ structuredAnswers: await getStructuredAnswers(sheetId) });
  } catch (err) {
    await db.run('UPDATE answer_sheets SET status = ? WHERE id = ?', ['failed', sheetId]);
    logAudit(req.user.id, 'answer_sheet.processing_failed', 'answer_sheet', sheetId, { error: err.message });
    res.status(422).json({ error: `Processing failed: ${err.message}` });
  }
}

async function getStructuredAnswers(sheetId) {
  const rows = await db.all('SELECT * FROM structured_answers WHERE answer_sheet_id = ?', [sheetId]);
  return rows.map((r) => ({
    id: r.id,
    answerSheetId: r.answer_sheet_id,
    questionNumber: r.question_number,
    answerText: r.answer_text,
    confidence: r.ocr_confidence,
  }));
}

async function listStructuredAnswers(req, res) {
  const { error } = await checkAnswerSheetAccess(req.params.id, req.user);
  if (error) return res.status(error.status).json({ error: error.message });
  res.json({ structuredAnswers: await getStructuredAnswers(req.params.id) });
}

module.exports = { triggerProcessing, listStructuredAnswers, getStructuredAnswers };
