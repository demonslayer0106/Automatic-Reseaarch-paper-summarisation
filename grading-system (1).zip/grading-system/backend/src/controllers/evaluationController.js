const { db } = require('../db');
const { newId } = require('../utils/ids');
const { logAudit } = require('../utils/audit');
const { checkGradingResultAccess, checkAssessmentAccess } = require('../utils/ownership');

/**
 * Records one human grade against one AI-graded result, for the
 * evaluation dataset described in the project README. This is
 * deliberately separate from review_decisions: a review decision CHANGES
 * the official mark a student receives, while a human evaluation is a
 * side channel purely for measuring AI grading accuracy later — it never
 * touches grading_results.marks_awarded.
 */
async function recordEvaluation(req, res) {
  const { id } = req.params; // grading_result id
  const { humanMarksAwarded, notes } = req.body;

  if (typeof humanMarksAwarded !== 'number' || !Number.isFinite(humanMarksAwarded)) {
    return res.status(400).json({ error: 'humanMarksAwarded (number) is required' });
  }

  const { result: gradingResult, error } = await checkGradingResultAccess(id, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  if (humanMarksAwarded < 0 || humanMarksAwarded > gradingResult.max_marks) {
    return res.status(400).json({ error: `humanMarksAwarded must be between 0 and ${gradingResult.max_marks}` });
  }

  const evalId = newId('eval');
  await db.run(
    'INSERT INTO human_evaluations (id, grading_result_id, evaluator_id, human_marks_awarded, notes) VALUES (?, ?, ?, ?, ?)',
    [evalId, id, req.user.id, humanMarksAwarded, notes || '']
  );

  logAudit(req.user.id, 'evaluation.recorded', 'grading_result', id, { humanMarksAwarded });

  res.status(201).json({ id: evalId, gradingResultId: id, humanMarksAwarded, notes: notes || '' });
}

function mean(arr) {
  return arr.reduce((s, v) => s + v, 0) / arr.length;
}

function pearsonCorrelation(xs, ys) {
  const n = xs.length;
  const mx = mean(xs);
  const my = mean(ys);
  let num = 0, dx2 = 0, dy2 = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - mx;
    const dy = ys[i] - my;
    num += dx * dy;
    dx2 += dx * dx;
    dy2 += dy * dy;
  }
  const denom = Math.sqrt(dx2 * dy2);
  return denom === 0 ? null : num / denom; // null when there's no variance to correlate
}

/**
 * Computes real accuracy metrics (MAE, RMSE, agreement-within-tolerance,
 * Pearson correlation) between AI marks and human marks — ONLY over
 * grading_results that actually have a recorded human_evaluations row.
 * Returns hasData: false with no numbers if none exist yet, rather than
 * fabricating a result — this project ships with zero evaluation data;
 * the numbers only mean something once a real person has graded a sample.
 */
async function getMetrics(req, res) {
  const { assessmentId, tolerance } = req.query;
  if (!assessmentId) return res.status(400).json({ error: 'assessmentId query param is required' });

  const { error } = await checkAssessmentAccess(assessmentId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  const tol = tolerance ? Number(tolerance) : 1;

  const rows = await db.all(
    `SELECT gr.marks_awarded as ai_marks, he.human_marks_awarded as human_marks
     FROM human_evaluations he
     JOIN grading_results gr ON gr.id = he.grading_result_id
     WHERE gr.assessment_id = ?`,
    [assessmentId]
  );

  if (rows.length === 0) {
    return res.json({
      hasData: false,
      sampleSize: 0,
      message: 'No human evaluations recorded yet for this assessment. Record some via POST /api/evaluation/:gradingResultId before metrics are meaningful.',
    });
  }

  const diffs = rows.map((r) => r.ai_marks - r.human_marks);
  const mae = mean(diffs.map(Math.abs));
  const rmse = Math.sqrt(mean(diffs.map((d) => d * d)));
  const agreementWithinTolerance = diffs.filter((d) => Math.abs(d) <= tol).length / diffs.length;
  const correlation = rows.length >= 2 ? pearsonCorrelation(rows.map((r) => r.ai_marks), rows.map((r) => r.human_marks)) : null;

  res.json({
    hasData: true,
    sampleSize: rows.length,
    tolerance: tol,
    metrics: {
      meanAbsoluteError: Math.round(mae * 1000) / 1000,
      rootMeanSquareError: Math.round(rmse * 1000) / 1000,
      agreementWithinTolerance: Math.round(agreementWithinTolerance * 1000) / 1000,
      pearsonCorrelation: correlation === null ? null : Math.round(correlation * 1000) / 1000,
    },
  });
}

module.exports = { recordEvaluation, getMetrics };
