/**
 * RUBRIC / QUESTION EXTRACTION
 * ------------------------------------------------------------------
 * Turns an uploaded rubric document (and, optionally, a separate
 * questions document) into the same questions[] shape the manual
 * assessment form already produces — see validateQuestions() in
 * assessmentController.js, which this output is fed straight into.
 * This is a *draft*: nothing is saved to the database here. The
 * frontend shows the extracted questions in the normal editable form
 * so a person reviews/corrects them before the existing createAssessment
 * flow runs — manual entry is unchanged and still works exactly as before.
 *
 * Two files are supported because a rubric document doesn't always
 * repeat the question text (e.g. a grader's mark scheme that just says
 * "Q3: ..." without restating the question) — in that case the caller
 * uploads a separate question paper and this module merges the two by
 * question number.
 */

const path = require('path');
const { extractPdfText } = require('../utils/pdfText');
const { extractDocxText, extractPptxText } = require('../utils/ooxmlText');

const MODEL = process.env.RUBRIC_EXTRACTION_MODEL || 'gemini-2.5-flash';
const MAX_DOC_CHARS = 60000; // keep prompts well under the model's context window

function truncate(text) {
  return text.length > MAX_DOC_CHARS ? `${text.slice(0, MAX_DOC_CHARS)}\n[...truncated...]` : text;
}

function buildPrompt({ rubricText, questionsText }) {
  const sections = [];
  if (questionsText) {
    sections.push(`QUESTION PAPER:\n"""\n${truncate(questionsText)}\n"""`);
    sections.push(
      `RUBRIC / MARK SCHEME (may reference questions only by number, without restating them):\n"""\n${truncate(rubricText)}\n"""`
    );
  } else {
    sections.push(`RUBRIC / QUESTION DOCUMENT (may contain both the questions and the mark scheme together):\n"""\n${truncate(rubricText)}\n"""`);
  }

  return `You are extracting a structured grading rubric from the document(s) below for an exam-grading tool.

${sections.join('\n\n')}

Instructions:
- Identify every question. Use the question number as written (e.g. "Q1", "2", "3a") normalized to a short form like "Q1", "Q2", "Q3A".
- For each question, give its full question text. If a separate question paper was provided, pull the question text from there and match it to the rubric by question number; if a question's text isn't available anywhere, write your best short paraphrase of what it's asking based on the rubric criteria and note it starts with "[inferred]".
- For each question, list every distinct rubric criterion with the marks it's worth. Marks for a question's criteria MUST sum to exactly that question's max marks — if the source document only gives a max mark with no criteria breakdown, create a single criterion "Full credit for a complete, correct answer" worth all the marks.
- Preserve the original ordering of questions.
- Do not invent questions that aren't in the document(s).

Respond with ONLY valid JSON, no markdown code fences, no commentary, matching exactly this shape:
{
  "questions": [
    {
      "questionNumber": "string, e.g. 'Q1'",
      "questionText": "string",
      "maxMarks": number,
      "criteria": [
        { "description": "string", "marks": number }
      ]
    }
  ]
}`;
}

async function callGeminiText(prompt) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error('GEMINI_API_KEY is not set in backend/.env');

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Gemini API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('No text content in Gemini response');
  return text;
}

function normalizeQuestionNumber(raw) {
  const match = String(raw).match(/(\d+[a-zA-Z]?)/);
  return match ? `Q${match[1].toUpperCase()}` : String(raw).toUpperCase().trim();
}

/**
 * Validates and clamps Gemini's extraction the same way the OCR pipeline
 * clamps its output — never trust the model's arithmetic. If a question's
 * criteria don't sum to its stated maxMarks, the maxMarks is corrected to
 * match the criteria sum (criteria are the ground truth for what actually
 * earns marks; a wrong header number shouldn't silently override them).
 */
function parseExtractionResponse(rawText) {
  const cleaned = rawText.replace(/```json|```/g, '').trim();
  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (err) {
    throw new Error(`Could not parse extraction response as JSON: ${err.message}`);
  }
  if (!Array.isArray(parsed.questions)) {
    throw new Error('Extraction response missing "questions" array');
  }

  const seen = new Set();
  const questions = [];
  for (const q of parsed.questions) {
    if (!q.questionNumber || !q.questionText || !Array.isArray(q.criteria) || q.criteria.length === 0) continue;

    const questionNumber = normalizeQuestionNumber(q.questionNumber);
    if (seen.has(questionNumber)) continue; // drop duplicates rather than fail the whole batch
    seen.add(questionNumber);

    const criteria = q.criteria
      .filter((c) => c.description && Number.isFinite(Number(c.marks)) && Number(c.marks) >= 0)
      .map((c) => ({ description: String(c.description).trim(), marks: Math.round(Number(c.marks) * 100) / 100 }));
    if (criteria.length === 0) continue;

    const criteriaSum = Math.round(criteria.reduce((s, c) => s + c.marks, 0) * 100) / 100;

    questions.push({
      questionNumber,
      questionText: String(q.questionText).trim(),
      maxMarks: criteriaSum,
      criteria,
    });
  }

  if (questions.length === 0) {
    throw new Error('No usable questions could be extracted — check the document(s) contain a legible rubric');
  }
  return questions;
}

/**
 * Entry point used by assessmentController.js's extractRubric route.
 * `rubricBuffer`/`rubricFileName` are required (the rubric or combined
 * document). `questionsBuffer`/`questionsFileName` are optional — pass
 * them when the questions live in a separate file from the rubric.
 */
async function extractRubricFromFiles({ rubricBuffer, rubricFileName, questionsBuffer, questionsFileName }) {
  const rubricText = await extractTextFromBuffer(rubricBuffer, rubricFileName);
  if (!rubricText.trim()) {
    throw new Error(`No extractable text found in ${rubricFileName}`);
  }

  let questionsText = null;
  if (questionsBuffer) {
    questionsText = await extractTextFromBuffer(questionsBuffer, questionsFileName);
    if (!questionsText.trim()) {
      throw new Error(`No extractable text found in ${questionsFileName}`);
    }
  }

  const prompt = buildPrompt({ rubricText, questionsText });
  const rawText = await callGeminiText(prompt);
  return parseExtractionResponse(rawText);
}

// Same per-extension dispatch as documentIngestion.js's extractTextFromFile,
// but from an in-memory upload buffer (multer memoryStorage) rather than a
// path on disk — the rubric/questions files here are never written to disk.
async function extractTextFromBuffer(buffer, fileName) {
  const ext = path.extname(fileName).toLowerCase();
  switch (ext) {
    case '.pdf':
      return extractPdfText(buffer);
    case '.docx':
      return extractDocxText(buffer);
    case '.pptx':
      return extractPptxText(buffer);
    case '.txt':
    case '.md':
      return buffer.toString('utf-8');
    default:
      throw new Error(`Unsupported file type: ${ext}`);
  }
}

module.exports = { extractRubricFromFiles, parseExtractionResponse };
