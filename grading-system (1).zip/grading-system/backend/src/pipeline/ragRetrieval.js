const { db } = require('../db');
const { embedText } = require('./embeddings');

function toPgVectorLiteral(float32Array) {
  return `[${Array.from(float32Array).join(',')}]`;
}

/**
 * Retrieves the top-N most relevant chunks from an assessment's reference
 * corpus for a given query (question + rubric — see gradingController.js,
 * which deliberately never passes the student's answer here).
 *
 * How it works:
 *   1. Embed the query text with the same Gemini embedding model used for
 *      ingestion.
 *   2. Ask Postgres/pgvector for the K nearest chunks BY COSINE DISTANCE
 *      (the `<=>` operator), filtered to this assessment directly in the
 *      WHERE clause — pgvector's `vector` column lives on document_chunks
 *      itself, so unlike the old sqlite-vec version there's no separate
 *      "search the whole table, then filter down to this assessment in
 *      JS" step needed; Postgres does both in one indexed query.
 *
 * Same function signature and return shape (EvidenceSnippet[] from
 * shared/types.ts) as before, so nothing in gradingController.js changed
 * to use it.
 */
async function retrieveEvidence(assessmentId, queryText, topN = 3, minRelevance = 0.15) {
  const totalRow = await db.get('SELECT COUNT(*) as n FROM document_chunks WHERE assessment_id = ?', [assessmentId]);
  if (Number(totalRow.n) === 0) return [];

  const queryVector = await embedText(queryText, 'RETRIEVAL_QUERY');
  const queryLiteral = toPgVectorLiteral(queryVector);

  const rows = await db.all(
    `SELECT source_title, chunk_text, embedding <=> ?::vector AS distance
     FROM document_chunks
     WHERE assessment_id = ?
     ORDER BY embedding <=> ?::vector
     LIMIT ?`,
    [queryLiteral, assessmentId, queryLiteral, topN]
  );

  // Convert cosine distance (0 = identical, 2 = opposite) to a 0-1
  // "relevance score" that's intuitive to display: 1 = very relevant.
  // Chunks below minRelevance are dropped rather than force-included —
  // handing the grading agent a "closest available" chunk that isn't
  // actually relevant is worse than giving it no evidence at all, since
  // it can mistake weak evidence for a real signal.
  return rows
    .map((row) => ({
      source: row.source_title,
      excerpt: row.chunk_text.slice(0, 500),
      relevanceScore: Math.round(Math.max(0, 1 - Number(row.distance) / 2) * 100) / 100,
    }))
    .filter((e) => e.relevanceScore >= minRelevance);
}

module.exports = { retrieveEvidence };
