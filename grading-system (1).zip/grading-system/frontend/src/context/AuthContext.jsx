import { createContext, useContext, useEffect, useState } from 'react';
import { authApi } from '../services/api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);

  // On load (or token change), verify the stored token against the backend
  // rather than trusting whatever's in localStorage.
  useEffect(() => {
    let cancelled = false;
    async function restoreSession() {
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const { user } = await authApi.me(token);
        if (!cancelled) setUser(user);
      } catch {
        localStorage.removeItem('token');
        if (!cancelled) {
          setToken(null);
          setUser(null);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    restoreSession();
    return () => {
      cancelled = true;
    };
  }, [token]);

  async function login(email, password) {
    const { token, user } = await authApi.login({ email, password });
    localStorage.setItem('token', token);
    setToken(token);
    setUser(user);
  }

  async function register({ name, email, password, role, adminInviteCode }) {
    const { token, user } = await authApi.register({ name, email, password, role, adminInviteCode });
    localStorage.setItem('token', token);
    setToken(token);
    setUser(user);
  }

  function logout() {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
