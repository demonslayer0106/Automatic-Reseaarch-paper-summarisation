const BASE_URL = '/api';

async function request(path, { method = 'GET', body, token, isFormData = false } = {}) {
  const headers = {};
  if (!isFormData) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: isFormData ? body : body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data;
}

export const authApi = {
  register: (payload) => request('/auth/register', { method: 'POST', body: payload }),
  login: (payload) => request('/auth/login', { method: 'POST', body: payload }),
  me: (token) => request('/auth/me', { token }),
};

export const assessmentsApi = {
  create: (payload, token) => request('/assessments', { method: 'POST', body: payload, token }),
  list: (token) => request('/assessments', { token }),
  get: (id, token) => request(`/assessments/${id}`, { token }),
  extractRubric: (formData, token) =>
    request('/assessments/extract-rubric', { method: 'POST', body: formData, token, isFormData: true }),
};

export const answerSheetsApi = {
  upload: (formData, token) =>
    request('/answer-sheets', { method: 'POST', body: formData, token, isFormData: true }),
  list: (assessmentId, token) => request(`/answer-sheets?assessmentId=${assessmentId}`, { token }),
  process: (sheetId, token) => request(`/answer-sheets/${sheetId}/process`, { method: 'POST', token }),
  structuredAnswers: (sheetId, token) =>
    request(`/answer-sheets/${sheetId}/structured-answers`, { token }),
};

export const referenceDocsApi = {
  add: (payload, token) => request('/reference-documents', { method: 'POST', body: payload, token }),
  ingestPath: (payload, token) => request('/reference-documents/ingest-path', { method: 'POST', body: payload, token }),
  uploadFile: (formData, token) =>
    request('/reference-documents/upload', { method: 'POST', body: formData, token, isFormData: true }),
  list: (assessmentId, token) => request(`/reference-documents?assessmentId=${assessmentId}`, { token }),
};

export const gradingApi = {
  // Starts a background grading job and returns { jobId, total } immediately —
  // grading no longer blocks the HTTP request (see gradingController.js).
  start: (answerSheetId, token) => request('/grading/run', { method: 'POST', body: { answerSheetId }, token }),
  jobStatus: (jobId, token) => request(`/grading/jobs/${jobId}`, { token }),
  results: (assessmentId, token, reviewStatus) =>
    request(
      `/grading/results?assessmentId=${assessmentId}${reviewStatus ? `&reviewStatus=${reviewStatus}` : ''}`,
      { token }
    ),
};

export const reviewApi = {
  queue: (assessmentId, token) => request(`/review/queue?assessmentId=${assessmentId}`, { token }),
  decide: (gradingResultId, payload, token) =>
    request(`/review/${gradingResultId}/decide`, { method: 'POST', body: payload, token }),
};
