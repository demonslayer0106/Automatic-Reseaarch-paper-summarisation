import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { referenceDocsApi } from '../services/api.js';

export default function ReferenceDocsPanel({ assessmentId, docs, onRefresh }) {
  const { token } = useAuth();
  const [mode, setMode] = useState('paste'); // 'paste' | 'upload' | 'folder'
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [sourcePath, setSourcePath] = useState('');
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handlePasteSubmit(e) {
    e.preventDefault();
    setError('');
    setInfo('');
    if (!title.trim() || !content.trim()) {
      setError('Title and content are both required.');
      return;
    }
    setSubmitting(true);
    try {
      const result = await referenceDocsApi.add({ assessmentId, title: title.trim(), content: content.trim() }, token);
      setTitle('');
      setContent('');
      if (result.skipped) {
        setInfo(`Nothing new to add: ${result.reason}`);
      } else {
        setOpen(false);
        onRefresh();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleFileSubmit(e) {
    e.preventDefault();
    setError('');
    setInfo('');
    if (!file) {
      setError('Choose a PDF, DOCX, or PPTX file first.');
      return;
    }
    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('assessmentId', assessmentId);
      formData.append('file', file);
      const result = await referenceDocsApi.uploadFile(formData, token);
      setFile(null);
      if (result.skipped) {
        setInfo(`Nothing new to add: ${result.reason}`);
      } else {
        setInfo(`Added "${result.title}" — ${result.chunkCount} chunk(s) embedded.`);
        onRefresh();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleFolderSubmit(e) {
    e.preventDefault();
    setError('');
    setInfo('');
    if (!sourcePath.trim()) {
      setError('A folder or file path is required.');
      return;
    }
    setSubmitting(true);
    try {
      const { ingested, errors } = await referenceDocsApi.ingestPath({ assessmentId, sourcePath: sourcePath.trim() }, token);
      const added = ingested.filter((r) => !r.skipped);
      const skipped = ingested.filter((r) => r.skipped);
      const totalChunks = added.reduce((s, r) => s + r.chunkCount, 0);
      const totalDupes = ingested.reduce((s, r) => s + (r.duplicatesSkipped || 0), 0);

      let summary = `Ingested ${added.length} document(s), ${totalChunks} chunk(s) embedded.`;
      if (totalDupes > 0) summary += ` ${totalDupes} duplicate chunk(s) skipped.`;
      if (skipped.length > 0) summary += ` ${skipped.length} file(s) had nothing new to add.`;
      if (errors && errors.length > 0) summary += ` ${errors.length} file(s) failed: ${errors.map((e) => `${e.filePath || e.title} (${e.error})`).join('; ')}`;
      setInfo(summary);

      if (added.length > 0) {
        setSourcePath('');
        onRefresh();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="bg-white border border-ink/10 rounded-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-serif text-lg text-ink">Reference materials (RAG)</h2>
        {!open && (
          <button onClick={() => setOpen(true)} className="text-xs text-gold hover:underline">
            + Add material
          </button>
        )}
      </div>
      <p className="text-xs text-slate mb-4">
        Notes, slides, or answer keys the AI grading agent retrieves evidence from. Real vector search
        (Gemini embeddings + Postgres/pgvector), not keyword matching.
      </p>

      {open && (
        <div className="mb-5 pb-5 border-b border-ink/10">
          <div className="flex mb-4 border-b border-ink/10">
            <button
              type="button"
              onClick={() => setMode('paste')}
              className={`px-3 pb-2 text-sm font-medium transition-colors ${mode === 'paste' ? 'text-ink border-b-2 border-gold' : 'text-slate'}`}
            >
              Paste text
            </button>
            <button
              type="button"
              onClick={() => setMode('upload')}
              className={`px-3 pb-2 text-sm font-medium transition-colors ${mode === 'upload' ? 'text-ink border-b-2 border-gold' : 'text-slate'}`}
            >
              Upload file
            </button>
            <button
              type="button"
              onClick={() => setMode('folder')}
              className={`px-3 pb-2 text-sm font-medium transition-colors ${mode === 'folder' ? 'text-ink border-b-2 border-gold' : 'text-slate'}`}
            >
              Ingest a folder
            </button>
          </div>

          {mode === 'upload' && (
            <form onSubmit={handleFileSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate mb-1">PDF, DOCX, or PPTX file</label>
                <input
                  type="file"
                  accept=".pdf,.docx,.pptx"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  className="w-full text-sm"
                />
                <p className="text-xs text-slate mt-1">
                  Text is extracted, chunked, and embedded for retrieval — the file itself is not stored.
                </p>
              </div>
              {error && <p className="text-sm text-flag">{error}</p>}
              {info && <p className="text-sm text-slate">{info}</p>}
              <div className="flex gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-ink text-paper text-sm font-medium px-4 py-2 rounded-sm hover:bg-ink/90 disabled:opacity-50"
                >
                  {submitting ? 'Uploading…' : 'Upload & embed'}
                </button>
                <button type="button" onClick={() => setOpen(false)} className="text-sm text-slate hover:text-ink">
                  Cancel
                </button>
              </div>
            </form>
          )}

          {mode === 'paste' && (
            <form onSubmit={handlePasteSubmit} className="space-y-3">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Title, e.g. 'Lecture 4 — Photosynthesis'"
                className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm"
              />
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Paste the reference text here (notes, slide content, model answer)…"
                rows={5}
                className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm"
              />
              {error && <p className="text-sm text-flag">{error}</p>}
              {info && <p className="text-sm text-slate">{info}</p>}
              <div className="flex gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-ink text-paper text-sm font-medium px-4 py-2 rounded-sm hover:bg-ink/90 disabled:opacity-50"
                >
                  {submitting ? 'Saving…' : 'Save material'}
                </button>
                <button type="button" onClick={() => setOpen(false)} className="text-sm text-slate hover:text-ink">
                  Cancel
                </button>
              </div>
            </form>
          )}

          {mode === 'folder' && (
            <form onSubmit={handleFolderSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate mb-1">Folder or file path (on the server)</label>
                <input
                  type="text"
                  value={sourcePath}
                  onChange={(e) => setSourcePath(e.target.value)}
                  placeholder="/path/to/course-materials"
                  className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm font-mono"
                />
                <p className="text-xs text-slate mt-1">
                  Reads every PDF, DOCX, PPTX, TXT, and MD file under this path (subfolders included), regardless of how
                  they're mixed together. The path must be reachable from the machine running the backend — this is
                  not a browser file picker.
                </p>
              </div>
              {error && <p className="text-sm text-flag">{error}</p>}
              {info && <p className="text-sm text-slate">{info}</p>}
              <div className="flex gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-ink text-paper text-sm font-medium px-4 py-2 rounded-sm hover:bg-ink/90 disabled:opacity-50"
                >
                  {submitting ? 'Ingesting…' : 'Ingest folder'}
                </button>
                <button type="button" onClick={() => setOpen(false)} className="text-sm text-slate hover:text-ink">
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {docs.length === 0 ? (
        <p className="text-sm text-slate">No reference material added yet — grading will run without RAG evidence.</p>
      ) : (
        <ul className="space-y-1.5">
          {docs.map((d) => (
            <li key={d.id} className="text-sm text-ink flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-gold" />
              {d.title}
              <span className="text-xs text-slate">({d.chunkCount} chunk{d.chunkCount === 1 ? '' : 's'})</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
