"""Research RAG — Streamlit UI.   Run:  streamlit run app.py"""

import os

import streamlit as st
from dotenv import load_dotenv

from rag.evaluator import benchmark_retrieval
from rag.gemini import GeminiClient
from rag.pipeline import RAGPipeline

load_dotenv()
st.set_page_config(page_title="Research RAG", page_icon="🔬", layout="wide")

VERDICT_ICON = {"Working": "🟢", "Partially working": "🟠", "Not working": "🔴"}


def band(x: float) -> str:
    return "🟢" if x >= 0.75 else "🟠" if x >= 0.5 else "🔴"


@st.cache_resource(show_spinner="Starting up...")
def load_pipeline(api_key: str, gen_model: str, embed_model: str, embed_dim: int) -> RAGPipeline:
    gem = GeminiClient(api_key, gen_model=gen_model, embed_model=embed_model, embed_dim=embed_dim)
    return RAGPipeline(gem, data_dir="data")


# ── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Settings")
    api_key = st.text_input("Gemini API key", type="password",
                            value=os.getenv("GEMINI_API_KEY", ""),
                            help="Get one at aistudio.google.com/apikey, or set GEMINI_API_KEY in .env")
    gen_model = st.selectbox("Answer model", ["gemini-3.5-flash", "gemini-3.5-flash-lite"])
    embed_model = st.selectbox("Embedding model", ["gemini-embedding-001", "gemini-embedding-2"],
                               help="Changing this creates a separate index; papers must be re-ingested.")
    embed_dim = st.selectbox("Embedding size", [768, 1536, 3072], index=0)
    run_eval = st.toggle("Evaluate every answer", value=True,
                         help="One extra Gemini call per question that grades retrieval, faithfulness and relevance.")

if not api_key:
    st.title("🔬 Research RAG")
    st.info("Enter your Gemini API key in the sidebar to begin.")
    st.stop()

try:
    pipe = load_pipeline(api_key, gen_model, embed_model, embed_dim)
except Exception as e:
    st.error(f"Could not start: {e}")
    st.stop()

st.title("🔬 Research RAG")
stats = pipe.store.stats()
c1, c2, c3 = st.columns(3)
c1.metric("Papers", stats["papers"])
c2.metric("Chunks", stats["chunks"])
c3.metric("Years", stats["years"])

tab_ask, tab_ingest, tab_bench = st.tabs(["💬 Ask", "📥 Ingest papers", "🧪 Retrieval benchmark"])

# ── Ingest ──────────────────────────────────────────────────────────────────
with tab_ingest:
    topic = st.text_input("Topic", placeholder="e.g. retrieval augmented generation")
    a, b, c, d = st.columns(4)
    n_papers = a.slider("Max papers", 1, 20, 5)
    category = b.selectbox("Category", ["All", "cs.AI", "cs.CL", "cs.LG", "cs.CV", "cs.IR", "stat.ML"])
    y_from = c.number_input("From year", 1990, 2026, 2020)
    y_to = d.number_input("To year", 1990, 2026, 2026)

    if st.button("Fetch & index", type="primary", disabled=not topic):
        bar, msg = st.progress(0.0), st.empty()
        try:
            res = pipe.ingest(topic, n_papers, None if category == "All" else category,
                              int(y_from), int(y_to),
                              progress=lambda p, m: (bar.progress(min(p, 1.0)), msg.text(m)))
            if not res["papers"]:
                st.warning("No papers found.")
            else:
                st.success(f"Indexed {len(res['papers'])} papers, {res['chunks_added']} new chunks. (Counts above update on your next action.)")
                for p in res["papers"]:
                    st.markdown(f"- [{p['title']}]({p['url']}) ({p['year']})")
        except Exception as e:
            st.error(f"Ingestion failed: {e}")

# ── Ask ─────────────────────────────────────────────────────────────────────
with tab_ask:
    if stats["chunks"] == 0:
        st.info("Ingest some papers first.")
    else:
        q = st.text_area("Question", height=90,
                         placeholder="e.g. How does LoRA reduce the number of trainable parameters?")
        a, b, c, d = st.columns(4)
        top_k = a.slider("Chunks", 3, 10, 5)
        yf = b.number_input("From year", 1990, 2026, 2000, key="qf")
        yt = c.number_input("To year", 1990, 2026, 2026, key="qt")
        author = d.text_input("Author contains")

        if st.button("Ask", type="primary", disabled=not q.strip()):
            with st.spinner("Retrieving, answering, evaluating..."):
                try:
                    st.session_state["result"] = pipe.ask(
                        q.strip(), top_k, int(yf), int(yt), author or None, evaluate=run_eval)
                except Exception as e:
                    st.session_state.pop("result", None)
                    st.error(f"Query failed: {e}")

        r = st.session_state.get("result")
        if r:
            # ── Confidence + RAG health, side by side ───────────────────────
            col_conf, col_eval = st.columns(2)
            with col_conf:
                st.markdown(f"#### {band(r.confidence)} Confidence: {r.confidence:.0%}")
                st.progress(r.confidence)
                st.caption(f"How strongly retrieval matched your question "
                           f"(top similarity {r.signals['top_sim']:.2f}, "
                           f"{sum('bm25_score' in c and 'dense_score' in c for c in r.chunks)}/{len(r.chunks)} "
                           f"chunks found by both search methods). No LLM judge involved.")
            with col_eval:
                ev = r.evaluation
                if ev:
                    st.markdown(f"#### {VERDICT_ICON[ev.verdict]} RAG health: {ev.overall:.0%} · {ev.verdict}")
                    st.progress(ev.overall)
                    m1, m2, m3 = st.columns(3)
                    m1.metric("Retrieval", f"{ev.context_relevance:.0%}", help="Are the fetched passages relevant to the question?")
                    m2.metric("Faithfulness", f"{ev.faithfulness:.0%}", help=f"{ev.n_claims - len(ev.unsupported_claims)}/{ev.n_claims} claims supported by the passages")
                    m3.metric("Answer", f"{ev.answer_relevance:.0%}", help="Does the answer address the question?")
                elif r.eval_error:
                    st.warning(f"Evaluation failed: {r.eval_error}")
                else:
                    st.caption("Evaluation is switched off in the sidebar.")

            if r.evaluation:
                ev = r.evaluation
                st.info(f"**Diagnosis:** {ev.diagnosis}")
                if ev.citation_issues:
                    st.warning(" ".join(ev.citation_issues))
                if ev.unsupported_claims:
                    with st.expander(f"⚠️ {len(ev.unsupported_claims)} unsupported claim(s)"):
                        for cl in ev.unsupported_claims:
                            st.markdown(f"- {cl}")

            st.markdown("### Answer")
            st.markdown(r.answer)
            st.caption(f"Model: {r.model}")

            st.markdown("### Sources")
            scores = r.evaluation.passage_scores if r.evaluation else []
            for i, ch in enumerate(r.chunks, 1):
                m = ch["metadata"]
                tag = f" · relevance {scores[i-1]}/3" if i <= len(scores) else ""
                cited = " ✅ cited" if any(cit.number == i for cit in r.citations) else ""
                with st.expander(f"[{i}] {m['title'][:80]} ({m['year']}) · p.{m['page_number']} · {m['section']}{tag}{cited}"):
                    st.markdown(f"{m['authors']} — [{m['source_url']}]({m['source_url']})")
                    st.text(ch["text"])

# ── Benchmark ───────────────────────────────────────────────────────────────
with tab_bench:
    st.markdown(
        "Objective check of **retrieval** over your whole index. Gemini writes a question for "
        "randomly sampled chunks; we then see whether search brings that exact chunk back."
    )
    a, b = st.columns(2)
    n_q = a.slider("Test questions", 5, 25, 10)
    k_b = b.slider("k", 1, 10, 5)
    if st.button("Run benchmark", disabled=stats["chunks"] == 0):
        bar, msg = st.progress(0.0), st.empty()
        try:
            res = benchmark_retrieval(pipe.gemini, pipe.store, pipe.retriever, n_q, k_b,
                                      progress=lambda p, m: (bar.progress(min(p, 1.0)), msg.text(m)))
            st.session_state["bench"] = res
        except Exception as e:
            st.error(f"Benchmark failed: {e}")
    res = st.session_state.get("bench")
    if res:
        st.markdown(f"#### {VERDICT_ICON[res.verdict]} Retrieval: {res.verdict}")
        m1, m2, m3 = st.columns(3)
        m1.metric(f"Hit@{res.k}", f"{res.hit_at_k:.0%}", help="Source chunk appeared in the top-k")
        m2.metric("Hit@1", f"{res.hit_at_1:.0%}")
        m3.metric("MRR", f"{res.mrr:.2f}", help="Mean reciprocal rank of the source chunk")
        st.dataframe(
            [{"Question": r["question"], "Rank": r["rank"] or "miss", "Paper": r["paper"]} for r in res.rows],
            use_container_width=True, hide_index=True,
        )
