"""
gemini.py
=========
The only place in the project that talks to the Gemini API.

  * embed()          -> Gemini embeddings (gemini-embedding-001 / gemini-embedding-2)
  * generate()       -> plain text answer   (default: gemini-3.5-flash)
  * generate_json()  -> schema-constrained JSON (used by the evaluator)

Notes
-----
* gemini-embedding-001 supports `task_type` (RETRIEVAL_DOCUMENT / RETRIEVAL_QUERY).
  gemini-embedding-2 does NOT accept task_type, so we simply omit it there.
* Only the full 3072-dim vectors come pre-normalised from the API. We shrink to
  `embed_dim` (default 768) via `output_dimensionality`, so we normalise ourselves.
* Free-tier keys hit 429s quickly when indexing many chunks, so every call is
  wrapped in an exponential-backoff retry.
"""

import os
import time
from typing import List, Optional, Type, TypeVar

import numpy as np
from google import genai
from google.genai import types
from loguru import logger
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)

DEFAULT_GEN_MODEL = "gemini-3.5-flash"
DEFAULT_EMBED_MODEL = "gemini-embedding-001"
DEFAULT_EMBED_DIM = 768

_RETRYABLE = {429, 500, 502, 503, 504}
_EMBED_BATCH = 32


class GeminiClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        gen_model: str = DEFAULT_GEN_MODEL,
        embed_model: str = DEFAULT_EMBED_MODEL,
        embed_dim: int = DEFAULT_EMBED_DIM,
    ):
        api_key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError(
                "No Gemini API key found. Set GEMINI_API_KEY in .env or paste it in the sidebar."
            )
        self.client = genai.Client(api_key=api_key)
        self.gen_model = gen_model
        self.embed_model = embed_model
        self.embed_dim = embed_dim

    # ── internal ────────────────────────────────────────────────────────────
    def _retry(self, fn, *args, **kwargs):
        delay = 3.0
        for attempt in range(6):
            try:
                return fn(*args, **kwargs)
            except Exception as e:  # google.genai.errors.APIError exposes .code
                code = getattr(e, "code", None)
                if code in _RETRYABLE and attempt < 5:
                    logger.warning(f"Gemini {code}; retrying in {delay:.0f}s (attempt {attempt + 1}/5)")
                    time.sleep(delay)
                    delay = min(delay * 2, 60)
                    continue
                raise

    # ── embeddings ──────────────────────────────────────────────────────────
    def embed(self, texts: List[str], kind: str = "document") -> List[List[float]]:
        """Embed texts. kind = 'document' (indexing) or 'query' (searching)."""
        if not texts:
            return []
        cfg = {"output_dimensionality": self.embed_dim}
        if "embedding-2" not in self.embed_model:
            cfg["task_type"] = "RETRIEVAL_DOCUMENT" if kind == "document" else "RETRIEVAL_QUERY"
        config = types.EmbedContentConfig(**cfg)

        vectors: List[List[float]] = []
        for i in range(0, len(texts), _EMBED_BATCH):
            batch = [t if t.strip() else " " for t in texts[i:i + _EMBED_BATCH]]
            res = self._retry(
                self.client.models.embed_content,
                model=self.embed_model,
                contents=batch,
                config=config,
            )
            vectors.extend(e.values for e in res.embeddings)

        arr = np.asarray(vectors, dtype=np.float32)
        arr /= np.clip(np.linalg.norm(arr, axis=1, keepdims=True), 1e-12, None)
        return arr.tolist()

    # ── generation ──────────────────────────────────────────────────────────
    def generate(self, prompt: str, system: Optional[str] = None) -> str:
        config = types.GenerateContentConfig(system_instruction=system) if system else None
        res = self._retry(
            self.client.models.generate_content,
            model=self.gen_model, contents=prompt, config=config,
        )
        return self._text(res)

    def generate_json(self, prompt: str, schema: Type[T], system: Optional[str] = None) -> T:
        """Generate output constrained to a pydantic schema and return the parsed object."""
        config = types.GenerateContentConfig(
            system_instruction=system,
            response_mime_type="application/json",
            response_schema=schema,
        )
        res = self._retry(
            self.client.models.generate_content,
            model=self.gen_model, contents=prompt, config=config,
        )
        if isinstance(getattr(res, "parsed", None), schema):
            return res.parsed
        return schema.model_validate_json(self._text(res))

    @staticmethod
    def _text(res) -> str:
        text = getattr(res, "text", None)
        if not text:
            reason = None
            try:
                reason = res.candidates[0].finish_reason
            except Exception:
                pass
            raise RuntimeError(f"Gemini returned no text (finish_reason={reason}).")
        return text
