"""
evaluator.py
============
Answers one question: "is the RAG actually working?"

Two complementary tools:

1. evaluate_answer()  -- per-query, reference-free "RAG triad" (judge = Gemini)
     Context relevance : did retrieval fetch passages that are relevant to the question?
     Faithfulness      : is every claim in the answer supported by those passages?
     Answer relevance  : does the answer actually address the question?
   A failure in exactly one link tells you *where* the pipeline is broken
   (retrieval vs. generation), which a single confidence number cannot.

2. benchmark_retrieval() -- corpus-level, objective
   Samples chunks, has Gemini write a question each chunk answers, then checks whether
   retrieval brings that chunk back. Reports Hit@k and MRR. No LLM judging involved in
   the score itself, so it is the most trustworthy signal that retrieval works.

Also here: compute_confidence() -- a cheap, judge-free retrieval confidence shown next
to the eval score.
"""

import re
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from loguru import logger
from pydantic import BaseModel, Field

# ── Judge schemas ───────────────────────────────────────────────────────────


class _PassageGrade(BaseModel):
    passage: int
    score: int = Field(description="0 irrelevant, 1 tangential, 2 partly answers, 3 directly answers")


class _ClaimCheck(BaseModel):
    claim: str
    supported: bool = Field(description="True only if the passages explicitly support the claim")


class _Judgement(BaseModel):
    passage_grades: List[_PassageGrade]
    claims: List[_ClaimCheck]
    answer_relevance: int = Field(description="0 off-topic, 1 weak, 2 mostly, 3 fully addresses the question")
    declined: bool = Field(description="True if the answer says the sources do not contain enough information")
    comment: str = Field(description="One sentence on the biggest weakness, or 'none'")


class _GeneratedQ(BaseModel):
    chunk: int
    question: str


class _GeneratedQs(BaseModel):
    questions: List[_GeneratedQ]


_JUDGE_SYSTEM = (
    "You are a strict, impartial evaluator of retrieval-augmented answers. "
    "Judge ONLY from the passages provided; never use outside knowledge."
)

# ── Result object ───────────────────────────────────────────────────────────


@dataclass
class Evaluation:
    context_relevance: float          # 0-1
    faithfulness: float               # 0-1
    answer_relevance: float           # 0-1
    overall: float                    # 0-1 (geometric mean of the three)
    verdict: str                      # "Working" | "Partially working" | "Not working"
    diagnosis: str
    declined: bool
    unsupported_claims: List[str] = field(default_factory=list)
    n_claims: int = 0
    citation_issues: List[str] = field(default_factory=list)
    passage_scores: List[int] = field(default_factory=list)


def _verdict(overall: float) -> str:
    return "Working" if overall >= 0.75 else "Partially working" if overall >= 0.5 else "Not working"


def _diagnose(ctx: float, faith: float, ans: float, declined: bool, comment: str) -> str:
    if declined and ctx < 0.5:
        return ("Retrieval found nothing relevant and the model correctly declined. "
                "The corpus probably lacks this topic -- ingest more papers.")
    if ctx < 0.5:
        return "Retrieval is the weak link: the fetched passages don't match the question. Try ingesting more relevant papers or rephrasing."
    if faith < 0.6:
        return "Generation is the weak link: the answer contains claims the passages don't support (possible hallucination)."
    if ans < 0.5:
        return "The answer doesn't really address the question even though the sources are relevant."
    if comment and comment.lower().strip(". ") != "none":
        return f"Healthy overall. Note: {comment}"
    return "All three links look healthy: relevant retrieval, grounded claims, on-topic answer."


# ── Check citation hygiene without an LLM ───────────────────────────────────


def check_citations(answer: str, n_chunks: int) -> List[str]:
    issues = []
    nums = [int(n) for n in re.findall(r"\[(\d+)\]", answer)]
    bad = sorted({n for n in nums if n < 1 or n > n_chunks})
    if bad:
        issues.append(f"Cites non-existent source(s): {bad}")
    if not nums:
        issues.append("Answer contains no [N] citations.")
    return issues


# ── 1. Per-query evaluation ─────────────────────────────────────────────────


def evaluate_answer(gemini, question: str, answer: str, chunks: List[dict]) -> Evaluation:
    passages = "\n\n".join(f"[{i}] {c['text'][:1500]}" for i, c in enumerate(chunks, 1))
    prompt = (
        f"QUESTION:\n{question}\n\nPASSAGES:\n{passages}\n\nANSWER:\n{answer}\n\n"
        "Tasks:\n"
        "1. passage_grades: grade EVERY passage for relevance to the question (0-3).\n"
        "2. claims: split the ANSWER into its distinct factual claims (ignore headings and "
        "'Sources Used' lists) and mark each supported=true only if the passages explicitly "
        "support it.\n"
        "3. answer_relevance (0-3) and declined (does the answer say the sources lack the info?).\n"
        "4. comment: one sentence on the biggest weakness, or 'none'."
    )
    j = gemini.generate_json(prompt, _Judgement, system=_JUDGE_SYSTEM)

    grades = {g.passage: max(0, min(3, g.score)) for g in j.passage_grades}
    scores = [grades.get(i, 0) for i in range(1, len(chunks) + 1)]
    ctx = (sum(scores) / (3 * len(scores))) if scores else 0.0

    unsupported = [c.claim for c in j.claims if not c.supported]
    n_claims = len(j.claims)
    faith = 1.0 if n_claims == 0 else (n_claims - len(unsupported)) / n_claims
    ans = max(0, min(3, j.answer_relevance)) / 3

    overall = (max(ctx, 1e-3) * max(faith, 1e-3) * max(ans, 1e-3)) ** (1 / 3)
    # A correct refusal on an off-corpus question is not a pipeline failure.
    if j.declined and ctx < 0.5 and faith >= 0.8:
        overall = max(overall, 0.5)

    return Evaluation(
        context_relevance=ctx,
        faithfulness=faith,
        answer_relevance=ans,
        overall=overall,
        verdict=_verdict(overall),
        diagnosis=_diagnose(ctx, faith, ans, j.declined, j.comment),
        declined=j.declined,
        unsupported_claims=unsupported,
        n_claims=n_claims,
        citation_issues=check_citations(answer, len(chunks)),
        passage_scores=scores,
    )


# ── Confidence (no LLM call) ────────────────────────────────────────────────


def compute_confidence(signals: dict, chunks: List[dict]) -> float:
    """
    Retrieval confidence in [0,1], computed from the raw signals:
      * top dense cosine similarity (rescaled: <=0.45 is noise, >=0.80 is a strong match)
      * mean similarity of the top-k
      * agreement: share of final chunks found by BOTH dense and BM25 search
    """
    if not chunks:
        return 0.0
    scale = lambda x: max(0.0, min(1.0, (x - 0.45) / 0.35))
    both = sum(1 for c in chunks if "dense_score" in c and "bm25_score" in c) / len(chunks)
    return round(0.5 * scale(signals["top_sim"]) + 0.3 * scale(signals["mean_sim"]) + 0.2 * both, 3)


# ── 2. Corpus-level retrieval benchmark ─────────────────────────────────────


@dataclass
class BenchmarkResult:
    n: int
    hit_at_1: float
    hit_at_k: float
    mrr: float
    k: int
    rows: List[dict]

    @property
    def verdict(self) -> str:
        return ("Working" if self.hit_at_k >= 0.85 else
                "Partially working" if self.hit_at_k >= 0.6 else "Not working")


def benchmark_retrieval(
    gemini, store, retriever, n: int = 10, k: int = 5,
    progress: Optional[Callable[[float, str], None]] = None,
) -> Optional[BenchmarkResult]:
    sample = store.sample(n, seed=None)
    if not sample:
        return None
    if progress:
        progress(0.1, "Generating test questions...")

    listing = "\n\n".join(f"[{i}] {c['text'][:1200]}" for i, c in enumerate(sample, 1))
    prompt = (
        "For each numbered passage, write ONE specific question that this passage answers and "
        "that someone could ask WITHOUT having seen the passage. Do not copy distinctive phrases "
        "from the passage; paraphrase. The question must not be answerable by a generic textbook "
        f"answer; it should need this passage.\n\n{listing}"
    )
    qs = gemini.generate_json(prompt, _GeneratedQs).questions
    qmap = {q.chunk: q.question for q in qs if 1 <= q.chunk <= len(sample)}

    rows, rr = [], []
    for step, (idx, question) in enumerate(qmap.items(), 1):
        if progress:
            progress(0.15 + 0.85 * step / len(qmap), f"Testing retrieval {step}/{len(qmap)}")
        target = sample[idx - 1]["id"]
        got, _ = retriever.retrieve(question, top_k=k)
        ids = [c["id"] for c in got]
        rank = ids.index(target) + 1 if target in ids else None
        rr.append(1.0 / rank if rank else 0.0)
        rows.append({"question": question, "rank": rank,
                     "paper": sample[idx - 1]["metadata"]["title"][:70]})

    if not rows:
        return None
    return BenchmarkResult(
        n=len(rows),
        hit_at_1=sum(1 for r in rows if r["rank"] == 1) / len(rows),
        hit_at_k=sum(1 for r in rows if r["rank"]) / len(rows),
        mrr=sum(rr) / len(rr),
        k=k,
        rows=rows,
    )
