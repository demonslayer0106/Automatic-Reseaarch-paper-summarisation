"""
pipeline.py
===========
Single entry point used by the UI:  ingest -> retrieve -> generate -> confidence -> evaluate.
"""

import re
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from loguru import logger

from .evaluator import Evaluation, compute_confidence, evaluate_answer
from .fetcher import ArxivFetcher
from .gemini import GeminiClient
from .processor import PDFProcessor
from .retriever import Retriever
from .store import VectorStore

SYSTEM_PROMPT = """You are a research assistant answering strictly from the numbered SOURCES provided.

Rules:
1. Use ONLY the sources. Do not add outside knowledge.
2. Cite every factual sentence with its source number, e.g. "LoRA freezes the base weights [2]." Use [1][3] for several.
3. If the sources do not contain enough information, say so plainly instead of guessing.
4. Be concise: a direct answer first, then supporting detail. Markdown is fine. No bibliography at the end."""


@dataclass
class Citation:
    number: int
    title: str
    authors: str
    year: int
    url: str
    page: int
    section: str
    excerpt: str


@dataclass
class QueryResult:
    question: str
    answer: str
    citations: List[Citation]
    chunks: List[dict]
    confidence: float
    signals: dict
    model: str
    evaluation: Optional[Evaluation] = None
    eval_error: Optional[str] = None


def _build_context(chunks: List[dict]) -> str:
    parts = []
    for i, c in enumerate(chunks, 1):
        m = c["metadata"]
        parts.append(f"[{i}] {m['title']} ({m['year']}), section: {m['section']}, p.{m['page_number']}\n{c['text']}")
    return "\n\n---\n\n".join(parts)


def _citations(answer: str, chunks: List[dict]) -> List[Citation]:
    out = []
    for n in sorted({int(x) for x in re.findall(r"\[(\d+)\]", answer)}):
        if 1 <= n <= len(chunks):
            c, m = chunks[n - 1], chunks[n - 1]["metadata"]
            out.append(Citation(n, m["title"], m["authors"], m["year"], m["source_url"],
                                m["page_number"], m["section"], c["text"][:400]))
    return out


class RAGPipeline:
    def __init__(self, gemini: GeminiClient, data_dir: str = "data"):
        self.gemini = gemini
        self.fetcher = ArxivFetcher(download_dir=f"{data_dir}/pdfs")
        self.processor = PDFProcessor()
        self.store = VectorStore(gemini, persist_dir=f"{data_dir}/chromadb")
        self.retriever = Retriever(self.store, gemini)

    # ── ingestion ───────────────────────────────────────────────────────────
    def ingest(
        self, query: str, max_papers: int = 5, category: Optional[str] = None,
        year_from: Optional[int] = None, year_to: Optional[int] = None,
        progress: Optional[Callable[[float, str], None]] = None,
    ) -> dict:
        say = progress or (lambda p, m: None)
        say(0.05, "Searching arXiv...")
        papers = self.fetcher.search(query, max_papers, category=category,
                                     year_from=year_from, year_to=year_to)
        if not papers:
            return {"papers": [], "chunks_added": 0}

        downloaded = []
        for i, p in enumerate(papers, 1):
            say(0.1 + 0.3 * i / len(papers), f"Downloading {i}/{len(papers)}: {p.title[:50]}")
            p = self.fetcher.download_pdf(p)
            if p.local_pdf_path:
                downloaded.append(p)

        say(0.5, "Parsing and chunking PDFs...")
        chunks = self.processor.process_papers(downloaded)

        say(0.6, f"Embedding {len(chunks)} chunks with Gemini...")
        added = self.store.add_chunks(chunks)
        self.retriever.rebuild()
        say(1.0, "Done")
        return {
            "papers": [{"title": p.title, "authors": p.authors[:2], "year": p.year, "url": p.url}
                       for p in downloaded],
            "chunks_added": added,
        }

    # ── querying ────────────────────────────────────────────────────────────
    def ask(
        self, question: str, top_k: int = 5, year_from: Optional[int] = None,
        year_to: Optional[int] = None, author: Optional[str] = None, evaluate: bool = True,
    ) -> QueryResult:
        chunks, signals = self.retriever.retrieve(
            question, top_k=top_k, year_from=year_from, year_to=year_to, author=author
        )
        if not chunks:
            return QueryResult(question, "No relevant passages were found. Ingest papers or loosen the filters.",
                               [], [], 0.0, signals, self.gemini.gen_model)

        prompt = f"QUESTION: {question}\n\nSOURCES:\n{_build_context(chunks)}"
        answer = self.gemini.generate(prompt, system=SYSTEM_PROMPT)

        result = QueryResult(
            question=question, answer=answer, citations=_citations(answer, chunks),
            chunks=chunks, confidence=compute_confidence(signals, chunks),
            signals=signals, model=self.gemini.gen_model,
        )
        if evaluate:
            try:
                result.evaluation = evaluate_answer(self.gemini, question, answer, chunks)
            except Exception as e:                       # never lose the answer over a judge failure
                logger.error(f"Evaluation failed: {e}")
                result.eval_error = str(e)
        return result
