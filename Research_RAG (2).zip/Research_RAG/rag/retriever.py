"""
retriever.py
============
Dense (Gemini embeddings) + BM25 keyword search, fused with Reciprocal Rank Fusion.

Removed vs. the original: the local cross-encoder reranker. It pulled in torch +
transformers (~2 GB) for a small gain on a corpus this size; RRF over two strong
signals is enough, and the evaluator now tells you objectively whether retrieval
is good enough.

Fixed vs. the original: the author filter used Chroma's `$contains`, which is not a
valid operator for metadata (`where`) filters. Year filtering still runs inside
Chroma; author filtering is applied in Python for both retrievers.
"""

import re
from typing import List, Optional, Tuple

from rank_bm25 import BM25Okapi

from .gemini import GeminiClient
from .store import VectorStore

_STOP = set(
    "a an and are as at be by for from how in is it of on or that the this to was "
    "what when where which who why with does do did can could should would about "
    "between versus vs into than then their there these those using use used".split()
)


def tokenize(text: str) -> List[str]:
    return [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOP]


class Retriever:
    def __init__(self, store: VectorStore, gemini: GeminiClient, candidates: int = 20):
        self.store = store
        self.gemini = gemini
        self.candidates = candidates
        self.rebuild()

    def rebuild(self):
        """(Re)build the BM25 index. Call after ingesting new papers."""
        self._docs = self.store.all_chunks()
        self._bm25 = (
            BM25Okapi([tokenize(d["text"]) or ["_"] for d in self._docs]) if self._docs else None
        )

    # ── filters ─────────────────────────────────────────────────────────────
    @staticmethod
    def _year_where(year_from: Optional[int], year_to: Optional[int]) -> Optional[dict]:
        conds = []
        if year_from:
            conds.append({"year": {"$gte": year_from}})
        if year_to:
            conds.append({"year": {"$lte": year_to}})
        if not conds:
            return None
        return conds[0] if len(conds) == 1 else {"$and": conds}

    @staticmethod
    def _ok(meta: dict, year_from, year_to, author) -> bool:
        if year_from and meta["year"] < year_from:
            return False
        if year_to and meta["year"] > year_to:
            return False
        if author and author.lower() not in meta["authors"].lower():
            return False
        return True

    # ── searches ────────────────────────────────────────────────────────────
    def _dense(self, vec, year_from, year_to, author) -> List[dict]:
        n = self.candidates * (5 if author else 1)      # over-fetch when post-filtering
        hits = self.store.query(vec, n, where=self._year_where(year_from, year_to))
        if author:
            hits = [h for h in hits if self._ok(h["metadata"], None, None, author)]
        return hits[: self.candidates]

    def _bm25_search(self, query, year_from, year_to, author) -> List[dict]:
        tokens = tokenize(query)
        if not self._bm25 or not tokens:
            return []
        scores = self._bm25.get_scores(tokens)
        order = sorted(range(len(scores)), key=scores.__getitem__, reverse=True)
        out = []
        for i in order:
            if scores[i] <= 0:
                break
            d = self._docs[i]
            if self._ok(d["metadata"], year_from, year_to, author):
                out.append({**d, "bm25_score": float(scores[i])})
                if len(out) >= self.candidates:
                    break
        return out

    @staticmethod
    def _rrf(dense: List[dict], sparse: List[dict], k: int = 60) -> List[dict]:
        merged, scores = {}, {}
        for ranking in (dense, sparse):
            for rank, doc in enumerate(ranking):
                scores[doc["id"]] = scores.get(doc["id"], 0.0) + 1.0 / (k + rank + 1)
                merged.setdefault(doc["id"], {}).update(doc)
        return [{**merged[i], "rrf_score": s}
                for i, s in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)]

    # ── public ──────────────────────────────────────────────────────────────
    def retrieve(
        self,
        query: str,
        top_k: int = 5,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
        query_vec: Optional[List[float]] = None,
    ) -> Tuple[List[dict], dict]:
        """
        Returns (chunks, signals).
        signals = raw dense-similarity stats, used by the pipeline for the confidence score.
        """
        vec = query_vec or self.gemini.embed([query], kind="query")[0]
        dense = self._dense(vec, year_from, year_to, author)
        sparse = self._bm25_search(query, year_from, year_to, author)
        fused = self._rrf(dense, sparse)[:top_k]

        sims = [d["dense_score"] for d in dense[:top_k]]
        signals = {
            "top_sim": max(sims) if sims else 0.0,
            "mean_sim": sum(sims) / len(sims) if sims else 0.0,
            "n_dense": len(dense),
            "n_bm25": len(sparse),
        }
        return fused, signals
