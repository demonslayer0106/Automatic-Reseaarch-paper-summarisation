"""
store.py
========
ChromaDB persistence. Vectors come from Gemini (see gemini.py).

The collection name encodes the embedding model + dimension, because vectors
from different models live in different spaces and must never be mixed.
Switching model/dim therefore creates a fresh collection instead of silently
returning garbage similarities.
"""

import random
import re
from pathlib import Path
from typing import List, Optional

import chromadb
from chromadb.config import Settings
from loguru import logger

from .gemini import GeminiClient
from .processor import DocumentChunk


class VectorStore:
    def __init__(self, gemini: GeminiClient, persist_dir: str = "data/chromadb"):
        self.gemini = gemini
        Path(persist_dir).mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(
            path=persist_dir, settings=Settings(anonymized_telemetry=False)
        )
        model_slug = re.sub(r"[^a-zA-Z0-9]+", "_", gemini.embed_model).strip("_")
        self.collection = self.client.get_or_create_collection(
            name=f"papers_{model_slug}_{gemini.embed_dim}",
            metadata={"hnsw:space": "cosine"},
        )
        logger.info(f"Collection '{self.collection.name}': {self.collection.count()} chunks")

    def count(self) -> int:
        return self.collection.count()

    def add_chunks(self, chunks: List[DocumentChunk]) -> int:
        if not chunks:
            return 0
        existing = set(self.collection.get(include=[])["ids"])
        new = [c for c in chunks if c.chunk_id not in existing]
        if not new:
            return 0

        logger.info(f"Embedding {len(new)} chunks with {self.gemini.embed_model}...")
        vectors = self.gemini.embed([c.text for c in new], kind="document")

        metadatas = [
            {
                "paper_id": c.paper_id,
                "title": c.title,
                "authors": ", ".join(c.authors[:3]),
                "year": c.year,
                "source_url": c.source_url,
                "page_number": c.page_number,
                "chunk_index": c.chunk_index,
                "section": c.section,
            }
            for c in new
        ]
        for i in range(0, len(new), 100):
            sl = slice(i, i + 100)
            self.collection.add(
                ids=[c.chunk_id for c in new[sl]],
                embeddings=vectors[sl],
                documents=[c.text for c in new[sl]],
                metadatas=metadatas[sl],
            )
        return len(new)

    def query(self, vector: List[float], n_results: int, where: Optional[dict] = None) -> List[dict]:
        total = self.count()
        if total == 0:
            return []
        res = self.collection.query(
            query_embeddings=[vector],
            n_results=min(n_results, total),
            where=where,
            include=["documents", "metadatas", "distances"],
        )
        return [
            {
                "id": res["ids"][0][i],
                "text": res["documents"][0][i],
                "metadata": res["metadatas"][0][i],
                "dense_score": 1.0 - res["distances"][0][i],   # cosine similarity
            }
            for i in range(len(res["ids"][0]))
        ]

    def all_chunks(self) -> List[dict]:
        if self.count() == 0:
            return []
        r = self.collection.get(include=["documents", "metadatas"])
        return [{"id": i, "text": d, "metadata": m}
                for i, d, m in zip(r["ids"], r["documents"], r["metadatas"])]

    def sample(self, n: int, min_words: int = 80, seed: Optional[int] = None) -> List[dict]:
        pool = [c for c in self.all_chunks() if len(c["text"].split()) >= min_words]
        return random.Random(seed).sample(pool, min(n, len(pool)))

    def stats(self) -> dict:
        chunks = self.all_chunks()
        if not chunks:
            return {"chunks": 0, "papers": 0, "years": "N/A"}
        years = [c["metadata"]["year"] for c in chunks]
        return {
            "chunks": len(chunks),
            "papers": len({c["metadata"]["paper_id"] for c in chunks}),
            "years": f"{min(years)}–{max(years)}",
        }
