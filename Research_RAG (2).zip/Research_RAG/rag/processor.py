"""
processor.py
============
PDF -> paragraphs -> size-bounded chunks with section labels.

What changed vs. the original
-----------------------------
* Uses PyMuPDF *blocks* (real paragraphs) instead of splitting on "\\n\\n", which
  never fired after the old clean_text() had already deleted blank lines.
  Result on the old index: 32% of chunks were > 512 words (max 1,424).
* Section state now carries across pages (before: reset every page, so 97% of
  chunks were labelled "Unknown"), and headers must be a *whole short line*
  ("3.2 Methods"), not any paragraph that merely starts with "Results ...".
* Reference lists and acknowledgements are skipped: they are keyword-dense,
  contain no answers, and polluted retrieval.
* Sizes are in words (that is what we actually count).
"""

import re
import unicodedata
from dataclasses import dataclass
from typing import List, Optional, Tuple

import pymupdf as fitz  # PyMuPDF
from loguru import logger

from .fetcher import Paper


@dataclass
class DocumentChunk:
    chunk_id: str
    text: str
    paper_id: str
    title: str
    authors: List[str]
    year: int
    abstract: str
    source_url: str
    page_number: int
    chunk_index: int
    section: str = "Unknown"


_SECTION_RE = re.compile(
    r"^(?:[ivx\d]+(?:\.\d+)*\.?\s+)?"
    r"(abstract|introduction|related work|background|methodology|methods?|approach|"
    r"experiments?|results?|discussion|conclusions?|references|acknowledge?ments?|appendix)"
    r"\s*[:.]?$",
    re.IGNORECASE,
)
_CANON = {"acknowledgement": "Acknowledgments", "acknowledgment": "Acknowledgments",
          "acknowledgements": "Acknowledgments", "acknowledgments": "Acknowledgments"}
_DROP_SECTIONS = {"References", "Acknowledgments"}


def _canonical_section(raw: str) -> str:
    key = raw.strip().lower()
    key = re.sub(r"^(?:[ivx\d]+(?:\.\d+)*\.?\s+)", "", key).strip(" :.")
    if key in _CANON:
        return _CANON[key]
    if key.startswith("conclusion"):
        return "Conclusion"
    return key.title()


class PDFProcessor:
    def __init__(self, chunk_words: int = 350, overlap_words: int = 50, min_words: int = 40):
        self.chunk_words = chunk_words
        self.overlap = overlap_words
        self.min_words = min_words

    # ── extraction ──────────────────────────────────────────────────────────
    @staticmethod
    def _clean(text: str) -> str:
        text = unicodedata.normalize("NFKC", text)          # ﬁ -> fi, etc.
        text = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", text)  # un-hyphenate line breaks
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def extract_paragraphs(self, pdf_path: str) -> List[Tuple[int, str]]:
        """Return [(page_number, paragraph_text)] in reading order."""
        out: List[Tuple[int, str]] = []
        try:
            with fitz.open(pdf_path) as doc:
                for page_idx, page in enumerate(doc, start=1):
                    for block in page.get_text("blocks"):
                        if block[6] != 0:          # 0 = text block, 1 = image
                            continue
                        text = self._clean(block[4])
                        if text:
                            out.append((page_idx, text))
        except Exception as e:
            logger.error(f"PDF extraction failed for {pdf_path}: {e}")
        return out

    # ── chunking ────────────────────────────────────────────────────────────
    def chunk_paragraphs(self, paragraphs: List[Tuple[int, str]]) -> List[dict]:
        chunks: List[dict] = []
        buf: List[str] = []
        new_words = 0                       # words added since last flush (excl. overlap)
        start_page, start_section = 1, "Unknown"
        section = "Unknown"

        def flush(carry_overlap: bool):
            nonlocal buf, new_words
            if new_words > 0 and len(buf) >= self.min_words:
                chunks.append({"text": " ".join(buf), "page": start_page, "section": start_section})
            buf = buf[-self.overlap:] if (carry_overlap and new_words > 0) else []
            new_words = 0

        for page, para in paragraphs:
            # Section header? (short, single line, matches a known heading)
            if len(para) < 60 and _SECTION_RE.match(para):
                flush(carry_overlap=False)
                section = _canonical_section(para)
                continue
            if section in _DROP_SECTIONS:
                continue
            if len(para) < 25:               # page numbers, axis labels, stray fragments
                continue

            words = para.split()
            if new_words > 0 and len(buf) + len(words) > self.chunk_words:
                flush(carry_overlap=True)
            if new_words == 0:
                start_page, start_section = page, section
            buf.extend(words)
            new_words += len(words)

            # A single huge paragraph: emit fixed windows
            while len(buf) > self.chunk_words * 1.5:
                chunks.append({"text": " ".join(buf[:self.chunk_words]),
                               "page": start_page, "section": start_section})
                buf = buf[self.chunk_words - self.overlap:]
                new_words = max(len(buf) - self.overlap, 1)

        flush(carry_overlap=False)
        return chunks

    # ── public ──────────────────────────────────────────────────────────────
    def process_paper(self, paper: Paper) -> List[DocumentChunk]:
        if not paper.local_pdf_path:
            logger.warning(f"No local PDF for {paper.paper_id}")
            return []
        paragraphs = self.extract_paragraphs(paper.local_pdf_path)
        raw = self.chunk_paragraphs(paragraphs)
        chunks = [
            DocumentChunk(
                chunk_id=f"{paper.paper_id}_chunk_{i}",
                text=c["text"],
                paper_id=paper.paper_id,
                title=paper.title,
                authors=paper.authors,
                year=paper.year,
                abstract=paper.abstract,
                source_url=paper.url,
                page_number=c["page"],
                chunk_index=i,
                section=c["section"],
            )
            for i, c in enumerate(raw)
        ]
        logger.info(f"{len(chunks)} chunks from '{paper.title[:50]}'")
        return chunks

    def process_papers(self, papers: List[Paper]) -> List[DocumentChunk]:
        out: List[DocumentChunk] = []
        for p in papers:
            out.extend(self.process_paper(p))
        return out
