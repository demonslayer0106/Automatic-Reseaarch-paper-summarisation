"""Offline tests: a fake Gemini (hashed bag-of-words embeddings) stands in for the API."""
import hashlib, sys, tempfile
from pathlib import Path
import numpy as np, pymupdf, pytest

sys.path.insert(0, str(Path(__file__).parent.parent))
from rag.evaluator import (BenchmarkResult, _Judgement, _PassageGrade, _ClaimCheck, _GeneratedQs,
                           _GeneratedQ, benchmark_retrieval, check_citations, compute_confidence, evaluate_answer)
from rag.fetcher import Paper
from rag.processor import PDFProcessor
from rag.retriever import Retriever, tokenize
from rag.store import VectorStore

DIM = 256

class FakeGemini:
    embed_model, gen_model, embed_dim = "fake-embed", "fake-gen", DIM
    judgement = None
    def embed(self, texts, kind="document"):
        out = []
        for t in texts:
            v = np.zeros(DIM, dtype=np.float32)
            for w in tokenize(t):
                v[int(hashlib.md5(w.encode()).hexdigest(), 16) % DIM] += 1
            out.append((v / (np.linalg.norm(v) or 1)).tolist())
        return out
    def generate_json(self, prompt, schema, system=None):
        if schema is _Judgement: return self.judgement
        if schema is _GeneratedQs:   # question = first 8 words of each passage, paraphrase-free but fine for plumbing
            import re
            parts = re.findall(r"\[(\d+)\] (.+?)(?=\n\n\[\d+\]|\Z)", prompt, flags=re.S)
            return _GeneratedQs(questions=[_GeneratedQ(chunk=int(i), question=" ".join(t.split()[:12])) for i, t in parts])

def make_pdf(path, body_pages):
    doc = pymupdf.open()
    for text in body_pages:
        page = doc.new_page()
        y = 60
        for para in text.split("\n\n"):
            page.insert_textbox(pymupdf.Rect(50, y, 540, y + 130), para, fontsize=10)
            y += 140
    doc.save(path)

@pytest.fixture
def paper(tmp_path):
    pdf = tmp_path / "p.pdf"
    filler = " ".join(f"word{i}" for i in range(100))
    make_pdf(str(pdf), [
        f"Abstract\n\nWe study low rank adaptation of language models. {filler}\n\nIntroduction\n\nLoRA freezes pretrained weights and trains small rank matrices. {filler}",
        f"Methods\n\nThe quantum cheese protocol uses rank decomposition. {filler}\n\nReferences\n\nSmith et al. 2020 citation soup rank rank rank {filler}",
    ])
    return Paper("1234.5678", "LoRA Paper", ["A. Author"], "abs", 2022, "http://arxiv.org/abs/1234.5678", "", [], local_pdf_path=str(pdf))

def test_processor_sections_and_references(paper):
    chunks = PDFProcessor(chunk_words=120, overlap_words=10).process_paper(paper)
    assert chunks
    secs = {c.section for c in chunks}
    assert "Introduction" in secs and "Methods" in secs      # tracked across pages
    assert not any("citation soup" in c.text for c in chunks)  # references dropped
    assert max(len(c.text.split()) for c in chunks) <= 120 * 1.5 + 5

def test_processor_never_exceeds_cap_on_huge_paragraph():
    p = PDFProcessor(chunk_words=100, overlap_words=10)
    out = p.chunk_paragraphs([(1, " ".join(f"w{i}" for i in range(1000)))])
    assert out and all(len(c["text"].split()) <= 150 for c in out)

@pytest.fixture
def stack(paper, tmp_path):
    g = FakeGemini()
    store = VectorStore(g, persist_dir=str(tmp_path / "db"))
    store.add_chunks(PDFProcessor(chunk_words=120, overlap_words=10).process_paper(paper))
    return g, store, Retriever(store, g)

def test_retrieval_and_filters(stack):
    g, store, r = stack
    chunks, sig = r.retrieve("quantum cheese protocol rank decomposition", top_k=3)
    assert "quantum cheese" in chunks[0]["text"]
    assert 0 <= sig["top_sim"] <= 1
    assert r.retrieve("rank", year_from=2030)[0] == []
    assert r.retrieve("rank", author="author")[0]
    assert r.retrieve("rank", author="nobody")[0] == []
    assert store.add_chunks([]) == 0

def test_reindex_is_idempotent(stack, paper):
    g, store, _ = stack
    n = store.count()
    assert store.add_chunks(PDFProcessor(chunk_words=120, overlap_words=10).process_paper(paper)) == 0
    assert store.count() == n

def test_confidence_bounds_and_ordering():
    ch_both = [{"dense_score": .8, "bm25_score": 3.0}] * 4
    ch_dense = [{"dense_score": .5}] * 4
    strong = compute_confidence({"top_sim": .82, "mean_sim": .78}, ch_both)
    weak = compute_confidence({"top_sim": .50, "mean_sim": .47}, ch_dense)
    assert strong > 0.9 and weak < 0.25 and strong > weak
    assert compute_confidence({"top_sim": 0, "mean_sim": 0}, []) == 0.0

def judgement(grades, supported, rel, declined=False, comment="none"):
    return _Judgement(passage_grades=[_PassageGrade(passage=i + 1, score=s) for i, s in enumerate(grades)],
                      claims=[_ClaimCheck(claim=f"c{i}", supported=s) for i, s in enumerate(supported)],
                      answer_relevance=rel, declined=declined, comment=comment)

CH = [{"text": "t"}] * 3

def test_eval_healthy():
    g = FakeGemini(); g.judgement = judgement([3, 3, 2], [True] * 4, 3)
    ev = evaluate_answer(g, "q", "claim [1][2].", CH)
    assert ev.verdict == "Working" and ev.faithfulness == 1.0 and ev.overall > 0.9

def test_eval_hallucination_points_at_generation():
    g = FakeGemini(); g.judgement = judgement([3, 3, 3], [True, False, False, False], 3)
    ev = evaluate_answer(g, "q", "a [1]", CH)
    assert "Generation" in ev.diagnosis and ev.verdict != "Working" and len(ev.unsupported_claims) == 3

def test_eval_bad_retrieval_points_at_retrieval():
    g = FakeGemini(); g.judgement = judgement([0, 1, 0], [True, True], 2)
    ev = evaluate_answer(g, "q", "a [1]", CH)
    assert "Retrieval" in ev.diagnosis and ev.verdict == "Not working"

def test_eval_correct_refusal_is_not_failure():
    g = FakeGemini(); g.judgement = judgement([0, 0, 0], [], 2, declined=True)
    ev = evaluate_answer(g, "q", "The sources do not say.", CH)
    assert ev.overall >= 0.5 and "corpus" in ev.diagnosis

def test_eval_handles_missing_passage_grades():
    g = FakeGemini(); g.judgement = judgement([3], [True], 3)   # judge skipped 2 passages
    ev = evaluate_answer(g, "q", "a [1]", CH)
    assert ev.passage_scores == [3, 0, 0]

def test_citation_check():
    assert check_citations("x [1] y [2]", 2) == []
    assert "non-existent" in check_citations("x [9]", 2)[0]
    assert "no [N]" in check_citations("x", 2)[0]

def test_benchmark_runs_and_scores(stack):
    g, store, r = stack
    res = benchmark_retrieval(g, store, r, n=4, k=5)
    assert isinstance(res, BenchmarkResult) and res.n > 0
    assert res.hit_at_k >= 0.75 and 0 <= res.mrr <= 1
