# Research RAG (Gemini)

arXiv papers → chunks → Gemini embeddings → hybrid search → Gemini answer with citations → **built-in RAG evaluation**.

```
pip install -r requirements.txt
cp .env.example .env        # put your GEMINI_API_KEY in it (or paste it in the sidebar)
streamlit run app.py
pytest tests                # offline tests, no API key needed
```

## Layout
```
app.py             Streamlit UI (Ask · Ingest · Retrieval benchmark)
rag/gemini.py      the only file that calls Gemini (embeddings + generation, retry/backoff)
rag/fetcher.py     arXiv search + PDF download
rag/processor.py   PDF → paragraphs → chunks (~350 words) with section labels
rag/store.py       ChromaDB (collection name encodes embed model + dimension)
rag/retriever.py   dense + BM25 → Reciprocal Rank Fusion
rag/evaluator.py   confidence, RAG-health eval, retrieval benchmark
rag/pipeline.py    ingest() / ask()
```

## The two numbers next to each answer
**Confidence** (no LLM call): how strongly retrieval matched — top cosine similarity, mean
similarity, and how many final chunks were found by *both* dense and BM25 search.

**RAG health** (one Gemini judge call): the RAG triad, each 0–100 %
| Metric | Question it answers | If low, the problem is… |
|---|---|---|
| Retrieval (context relevance) | Are the fetched passages relevant to the question? | retrieval / corpus |
| Faithfulness | Is each claim in the answer supported by the passages? | generation (hallucination) |
| Answer relevance | Does the answer address the question? | generation |

Overall = geometric mean (one broken link drags it down). ≥75 % Working · 50–75 % Partially · <50 % Not working.
A correct "the sources don't say" on an off-topic question is not scored as a failure.
The UI also lists unsupported claims, bad citation numbers, and per-chunk relevance.

**Retrieval benchmark tab** (objective, corpus-wide): Gemini writes a question for randomly sampled chunks;
we check if search returns that chunk → Hit@k and MRR. Run it after every ingest or setting change.

## Notes
* Models: answers `gemini-3.5-flash`; embeddings `gemini-embedding-001` (default, supports task types) or `gemini-embedding-2` (no task type). Vectors are L2-normalised locally because only 3072-d vectors arrive normalised.
* Switching embedding model/dimension makes a new Chroma collection — re-ingest papers (vectors from different models are not comparable).
* LLM judges are imperfect; treat RAG health as a strong signal, and the benchmark as the ground truth for retrieval.
