import { useAuth } from '../context/AuthContext.jsx';

export default function Shell({ children }) {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-paper">
      <header className="border-b border-ink/10 bg-white">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <span className="font-serif text-xl text-ink">Gradeline</span>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-ink leading-tight">{user?.name}</p>
              <p className="text-xs text-slate capitalize leading-tight">{user?.role}</p>
            </div>
            <button
              onClick={logout}
              className="text-sm text-slate hover:text-ink border border-ink/15 rounded-sm px-3 py-1.5 transition-colors"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>
      <main className="max-w-5xl mx-auto px-6 py-10">{children}</main>
    </div>
  );
}
