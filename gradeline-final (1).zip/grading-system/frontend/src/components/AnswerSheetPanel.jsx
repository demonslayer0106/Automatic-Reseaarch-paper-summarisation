import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { answerSheetsApi, gradingApi } from '../services/api.js';
import StatusPill from './StatusPill.jsx';

export default function AnswerSheetPanel({ assessmentId, answerSheets, onRefresh }) {
  const { token } = useAuth();
  const [studentId, setStudentId] = useState('');
  const [file, setFile] = useState(null);
  const [busyId, setBusyId] = useState(null); // sheet id currently being processed/graded
  const [error, setError] = useState('');

  async function handleUpload(e) {
    e.preventDefault();
    setError('');
    if (!studentId.trim() || !file) {
      setError('Student identifier and a PDF file are both required.');
      return;
    }
    const formData = new FormData();
    formData.append('assessmentId', assessmentId);
    formData.append('studentIdentifier', studentId.trim());
    formData.append('file', file);

    try {
      await answerSheetsApi.upload(formData, token);
      setStudentId('');
      setFile(null);
      e.target.reset();
      onRefresh();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleProcess(sheetId) {
    setBusyId(sheetId);
    setError('');
    try {
      await answerSheetsApi.process(sheetId, token);
      onRefresh();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleGrade(sheetId) {
    setBusyId(sheetId);
    setError('');
    try {
      const { jobId, total } = await gradingApi.start(sheetId, token);
      // Grading now runs as a background job — poll for progress instead of
      // blocking on one long request (a slow sheet no longer freezes the UI).
      let job;
      do {
        await new Promise((r) => setTimeout(r, 1000));
        job = await gradingApi.jobStatus(jobId, token);
      } while (job.status === 'queued' || job.status === 'running');

      if (job.status === 'failed') {
        setError(`Grading failed: ${job.errors ? JSON.stringify(job.errors) : 'unknown error'}`);
      } else if (job.errors && job.errors.length > 0) {
        setError(`Graded ${job.completed}/${total} with ${job.errors.length} issue(s): ${job.errors.map((e) => `${e.questionNumber} — ${e.error}`).join('; ')}`);
      }
      onRefresh();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="bg-white border border-ink/10 rounded-sm p-6">
      <h2 className="font-serif text-lg text-ink mb-4">Answer sheets</h2>

      <form onSubmit={handleUpload} className="flex flex-wrap items-end gap-3 mb-6 pb-6 border-b border-ink/10">
        <div>
          <label className="block text-xs font-medium text-slate mb-1">Student identifier</label>
          <input
            type="text"
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            placeholder="Roll no. / name"
            className="border border-ink/15 rounded-sm px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-slate mb-1">PDF file</label>
          <input
            type="file"
            accept="application/pdf"
            onChange={(e) => setFile(e.target.files[0])}
            className="text-sm"
          />
        </div>
        <button
          type="submit"
          className="bg-ink text-paper text-sm font-medium px-4 py-2 rounded-sm hover:bg-ink/90"
        >
          Upload
        </button>
      </form>

      {error && (
        <p className="text-sm text-flag bg-flag/5 border border-flag/20 rounded-sm px-3 py-2 mb-4">{error}</p>
      )}

      {answerSheets.length === 0 ? (
        <p className="text-sm text-slate">No answer sheets uploaded yet.</p>
      ) : (
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate uppercase tracking-wide border-b border-ink/10">
              <th className="pb-2">Student</th>
              <th className="pb-2">File</th>
              <th className="pb-2">Status</th>
              <th className="pb-2"></th>
            </tr>
          </thead>
          <tbody>
            {answerSheets.map((s) => (
              <tr key={s.id} className="border-b border-ink/5">
                <td className="py-2.5">{s.studentIdentifier}</td>
                <td className="py-2.5 text-slate">{s.fileName}</td>
                <td className="py-2.5">
                  <StatusPill status={s.status} />
                </td>
                <td className="py-2.5 text-right">
                  {s.status === 'uploaded' && (
                    <button
                      onClick={() => handleProcess(s.id)}
                      disabled={busyId === s.id}
                      className="text-xs text-ink border border-ink/20 rounded-sm px-3 py-1 hover:bg-ink/5 disabled:opacity-50"
                    >
                      {busyId === s.id ? 'Processing…' : 'Run OCR'}
                    </button>
                  )}
                  {s.status === 'processed' && (
                    <button
                      onClick={() => handleGrade(s.id)}
                      disabled={busyId === s.id}
                      className="text-xs text-paper bg-gold rounded-sm px-3 py-1 hover:bg-gold/90 disabled:opacity-50"
                    >
                      {busyId === s.id ? 'Grading…' : 'Run AI grading'}
                    </button>
                  )}
                  {s.status === 'failed' && (
                    <button
                      onClick={() => handleProcess(s.id)}
                      disabled={busyId === s.id}
                      className="text-xs text-flag border border-flag/30 rounded-sm px-3 py-1 hover:bg-flag/5 disabled:opacity-50"
                    >
                      Retry OCR
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
