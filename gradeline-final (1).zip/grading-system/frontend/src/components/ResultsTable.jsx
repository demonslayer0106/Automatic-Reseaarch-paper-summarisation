import { useState, Fragment } from 'react';
import ConfidenceBadge from './ConfidenceBadge.jsx';
import StatusPill from './StatusPill.jsx';

export default function ResultsTable({ results }) {
  const [expandedId, setExpandedId] = useState(null);

  if (results.length === 0) {
    return <p className="text-sm text-slate">No graded results yet.</p>;
  }

  return (
    <table className="w-full text-sm">
      <thead>
        <tr className="text-left text-xs text-slate uppercase tracking-wide border-b border-ink/10">
          <th className="pb-2">Student</th>
          <th className="pb-2">Question</th>
          <th className="pb-2">Marks</th>
          <th className="pb-2">Confidence</th>
          <th className="pb-2">Status</th>
        </tr>
      </thead>
      <tbody>
        {results.map((r) => (
          <Fragment key={r.id}>
            <tr
              onClick={() => setExpandedId(expandedId === r.id ? null : r.id)}
              className="border-b border-ink/5 cursor-pointer hover:bg-paper/60"
            >
              <td className="py-2.5">{r.studentIdentifier}</td>
              <td className="py-2.5">{r.questionNumber}</td>
              <td className="py-2.5 font-medium">
                {r.marksAwarded} / {r.maxMarks}
              </td>
              <td className="py-2.5">
                <ConfidenceBadge score={r.confidenceScore} />
              </td>
              <td className="py-2.5">
                <StatusPill status={r.reviewStatus} />
              </td>
            </tr>
            {expandedId === r.id && (
              <tr className="bg-paper/40">
                <td colSpan={5} className="py-4 px-2">
                  <div className="space-y-3 text-sm">
                    {r.questionText && (
                      <div>
                        <p className="text-xs font-medium text-slate mb-0.5">Question</p>
                        <p className="text-ink">{r.questionText}</p>
                      </div>
                    )}
                    {r.answerText && (
                      <div>
                        <p className="text-xs font-medium text-slate mb-0.5">Student's answer</p>
                        <p className="text-ink/80">{r.answerText}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-xs font-medium text-slate mb-0.5">Explanation</p>
                      <p className="text-ink/80">{r.explanation}</p>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-slate mb-1">Criterion-wise breakdown</p>
                      <ul className="space-y-1">
                        {r.criterionResults.map((c, i) => (
                          <li key={i} className="flex justify-between text-ink/80 border-b border-ink/5 pb-1">
                            <span>{c.justification}</span>
                            <span className="font-medium ml-4 whitespace-nowrap">
                              {c.marksAwarded}/{c.maxMarks}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    {r.evidence.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-slate mb-1">Evidence used</p>
                        <ul className="space-y-1">
                          {r.evidence.map((e, i) => (
                            <li key={i} className="text-xs text-slate italic">
                              "{e.excerpt}" — {e.source}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </td>
              </tr>
            )}
          </Fragment>
        ))}
      </tbody>
    </table>
  );
}
