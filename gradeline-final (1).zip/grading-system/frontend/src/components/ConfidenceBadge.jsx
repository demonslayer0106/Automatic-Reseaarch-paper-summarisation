export default function ConfidenceBadge({ score }) {
  const pct = Math.round(score * 100);
  const tone = score >= 0.75 ? 'approve' : score >= 0.5 ? 'gold' : 'flag';
  const styles = {
    approve: 'bg-approve/10 text-approve border-approve/30',
    gold: 'bg-gold/10 text-gold border-gold/30',
    flag: 'bg-flag/10 text-flag border-flag/30',
  };
  return (
    <span className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-full border ${styles[tone]}`}>
      {pct}% confidence
    </span>
  );
}
