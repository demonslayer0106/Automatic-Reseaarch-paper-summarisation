export default function AssessmentPicker({ assessments, selectedId, onChange }) {
  if (assessments.length === 0) {
    return <p className="text-sm text-slate">No assessments yet.</p>;
  }
  return (
    <select
      value={selectedId || ''}
      onChange={(e) => onChange(e.target.value)}
      className="border border-ink/15 rounded-sm px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold"
    >
      {assessments.map((a) => (
        <option key={a.id} value={a.id}>
          {a.title}
        </option>
      ))}
    </select>
  );
}
