const STATUS_STYLES = {
  uploaded: 'bg-slate/10 text-slate border-slate/30',
  processing: 'bg-gold/10 text-gold border-gold/30',
  processed: 'bg-approve/10 text-approve border-approve/30',
  failed: 'bg-flag/10 text-flag border-flag/30',
  auto_approved: 'bg-approve/10 text-approve border-approve/30',
  pending_review: 'bg-gold/10 text-gold border-gold/30',
  reviewed: 'bg-ink/10 text-ink border-ink/30',
};

const LABELS = {
  uploaded: 'Uploaded',
  processing: 'Processing',
  processed: 'Processed',
  failed: 'Failed',
  auto_approved: 'Auto-approved',
  pending_review: 'Pending review',
  reviewed: 'Reviewed',
};

export default function StatusPill({ status }) {
  return (
    <span className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-full border ${STATUS_STYLES[status] || ''}`}>
      {LABELS[status] || status}
    </span>
  );
}
