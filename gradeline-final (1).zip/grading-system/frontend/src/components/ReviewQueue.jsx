import { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { reviewApi } from '../services/api.js';
import ConfidenceBadge from './ConfidenceBadge.jsx';

function ReviewCard({ item, onDecided }) {
  const { token } = useAuth();
  const [marks, setMarks] = useState(item.marksAwarded);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function submit() {
    setError('');
    setSubmitting(true);
    try {
      await reviewApi.decide(item.id, { finalMarksAwarded: Number(marks), reviewerNotes: notes }, token);
      onDecided(item.id);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="bg-white border border-ink/10 rounded-sm p-6">
      <div className="flex items-start justify-between mb-3">
        <div>
          <p className="text-sm font-medium text-ink">
            {item.studentIdentifier} — {item.questionNumber}
          </p>
          <p className="text-xs text-slate">AI suggested {item.marksAwarded} / {item.maxMarks}</p>
        </div>
        <ConfidenceBadge score={item.confidenceScore} />
      </div>

      {item.questionText && (
        <div className="mb-3">
          <p className="text-xs font-medium text-slate mb-0.5">Question</p>
          <p className="text-sm text-ink">{item.questionText}</p>
        </div>
      )}

      {item.answerText && (
        <div className="mb-3">
          <p className="text-xs font-medium text-slate mb-0.5">Student's answer</p>
          <p className="text-sm text-ink/80">{item.answerText}</p>
        </div>
      )}

      <div className="mb-3">
        <p className="text-xs font-medium text-slate mb-0.5">AI explanation</p>
        <p className="text-sm text-ink/80">{item.explanation}</p>
      </div>

      <div className="mb-4">
        <p className="text-xs font-medium text-slate mb-1">Criterion-wise breakdown</p>
        <ul className="space-y-1">
          {item.criterionResults.map((c, i) => (
            <li key={i} className="flex justify-between text-sm text-ink/80 border-b border-ink/5 pb-1">
              <span>{c.justification}</span>
              <span className="font-medium ml-4 whitespace-nowrap">{c.marksAwarded}/{c.maxMarks}</span>
            </li>
          ))}
        </ul>
      </div>

      {item.evidence.length > 0 && (
        <div className="mb-4">
          <p className="text-xs font-medium text-slate mb-1">Evidence used</p>
          <ul className="space-y-1">
            {item.evidence.map((e, i) => (
              <li key={i} className="text-xs text-slate italic">"{e.excerpt}" — {e.source}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="border-t border-ink/10 pt-4 flex flex-wrap items-end gap-3">
        <div>
          <label className="block text-xs font-medium text-slate mb-1">Final marks (0–{item.maxMarks})</label>
          <input
            type="number"
            min={0}
            max={item.maxMarks}
            value={marks}
            onChange={(e) => setMarks(e.target.value)}
            className="w-24 border border-ink/15 rounded-sm px-3 py-2 text-sm"
          />
        </div>
        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs font-medium text-slate mb-1">Reviewer notes (optional)</label>
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Why you adjusted the grade, if you did"
            className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm"
          />
        </div>
        <button
          onClick={submit}
          disabled={submitting}
          className="bg-approve text-paper text-sm font-medium px-5 py-2 rounded-sm hover:bg-approve/90 disabled:opacity-50"
        >
          {submitting ? 'Saving…' : 'Confirm grade'}
        </button>
      </div>
      {error && <p className="text-sm text-flag mt-2">{error}</p>}
    </div>
  );
}

export default function ReviewQueue({ queue, onDecided }) {
  if (queue.length === 0) {
    return (
      <div className="border border-dashed border-ink/20 rounded-sm p-10 text-center text-slate text-sm">
        Nothing pending review right now.
      </div>
    );
  }
  return (
    <div className="space-y-4">
      {queue.map((item) => (
        <ReviewCard key={item.id} item={item} onDecided={onDecided} />
      ))}
    </div>
  );
}
