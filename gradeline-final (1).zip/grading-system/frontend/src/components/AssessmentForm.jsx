import { useState } from 'react';

function emptyCriterion() {
  return { description: '', marks: 1 };
}
function emptyQuestion() {
  return { questionNumber: '', questionText: '', maxMarks: 10, criteria: [emptyCriterion()] };
}

export default function AssessmentForm({ onCreate }) {
  const [title, setTitle] = useState('');
  const [questions, setQuestions] = useState([emptyQuestion()]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [open, setOpen] = useState(false);

  function updateQuestion(qIndex, field, value) {
    setQuestions((qs) => qs.map((q, i) => (i === qIndex ? { ...q, [field]: value } : q)));
  }
  function updateCriterion(qIndex, cIndex, field, value) {
    setQuestions((qs) =>
      qs.map((q, i) =>
        i === qIndex
          ? { ...q, criteria: q.criteria.map((c, j) => (j === cIndex ? { ...c, [field]: value } : c)) }
          : q
      )
    );
  }
  function addQuestion() {
    setQuestions((qs) => [...qs, emptyQuestion()]);
  }
  function removeQuestion(qIndex) {
    setQuestions((qs) => qs.filter((_, i) => i !== qIndex));
  }
  function addCriterion(qIndex) {
    setQuestions((qs) => qs.map((q, i) => (i === qIndex ? { ...q, criteria: [...q.criteria, emptyCriterion()] } : q)));
  }
  function removeCriterion(qIndex, cIndex) {
    setQuestions((qs) =>
      qs.map((q, i) => (i === qIndex ? { ...q, criteria: q.criteria.filter((_, j) => j !== cIndex) } : q))
    );
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (!title.trim()) return setError('Title is required.');
    for (const q of questions) {
      if (!q.questionNumber.trim() || !q.questionText.trim()) {
        return setError('Every question needs a number (e.g. Q1) and question text.');
      }
      const criteriaSum = q.criteria.reduce((s, c) => s + Number(c.marks || 0), 0);
      if (Math.abs(criteriaSum - Number(q.maxMarks)) > 0.01) {
        return setError(
          `${q.questionNumber}: criteria marks (${criteriaSum}) must add up to the question's max marks (${q.maxMarks}).`
        );
      }
    }

    setSubmitting(true);
    try {
      await onCreate({
        title: title.trim(),
        questions: questions.map((q) => ({
          questionNumber: q.questionNumber.trim(),
          questionText: q.questionText.trim(),
          maxMarks: Number(q.maxMarks),
          criteria: q.criteria.map((c) => ({ description: c.description.trim(), marks: Number(c.marks) })),
        })),
      });
      setTitle('');
      setQuestions([emptyQuestion()]);
      setOpen(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="text-sm font-medium text-ink border border-ink/20 rounded-sm px-4 py-2 hover:bg-ink/5 transition-colors"
      >
        + New assessment
      </button>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white border border-ink/10 rounded-sm p-6 space-y-6">
      <div>
        <label className="block text-xs font-medium text-slate mb-1">Assessment title</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. Biology Midterm"
          className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold"
        />
      </div>

      <div className="space-y-5">
        {questions.map((q, qIndex) => (
          <div key={qIndex} className="border border-ink/10 rounded-sm p-4 bg-paper/40">
            <div className="flex items-start gap-3 mb-3">
              <input
                type="text"
                value={q.questionNumber}
                onChange={(e) => updateQuestion(qIndex, 'questionNumber', e.target.value)}
                placeholder="Q1"
                className="w-20 border border-ink/15 rounded-sm px-2 py-1.5 text-sm"
              />
              <input
                type="text"
                value={q.questionText}
                onChange={(e) => updateQuestion(qIndex, 'questionText', e.target.value)}
                placeholder="Question text"
                className="flex-1 border border-ink/15 rounded-sm px-2 py-1.5 text-sm"
              />
              <input
                type="number"
                value={q.maxMarks}
                onChange={(e) => updateQuestion(qIndex, 'maxMarks', e.target.value)}
                className="w-20 border border-ink/15 rounded-sm px-2 py-1.5 text-sm"
                title="Max marks"
              />
              {questions.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeQuestion(qIndex)}
                  className="text-flag text-xs px-2 py-1.5 hover:underline"
                >
                  Remove
                </button>
              )}
            </div>

            <div className="pl-4 space-y-2">
              <p className="text-xs font-medium text-slate">Rubric criteria (marks must sum to max marks)</p>
              {q.criteria.map((c, cIndex) => (
                <div key={cIndex} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={c.description}
                    onChange={(e) => updateCriterion(qIndex, cIndex, 'description', e.target.value)}
                    placeholder="Criterion description"
                    className="flex-1 border border-ink/15 rounded-sm px-2 py-1.5 text-sm"
                  />
                  <input
                    type="number"
                    value={c.marks}
                    onChange={(e) => updateCriterion(qIndex, cIndex, 'marks', e.target.value)}
                    className="w-16 border border-ink/15 rounded-sm px-2 py-1.5 text-sm"
                  />
                  {q.criteria.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeCriterion(qIndex, cIndex)}
                      className="text-flag text-xs hover:underline"
                    >
                      ✕
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => addCriterion(qIndex)}
                className="text-xs text-gold hover:underline"
              >
                + Add criterion
              </button>
            </div>
          </div>
        ))}
      </div>

      <button type="button" onClick={addQuestion} className="text-sm text-ink border border-ink/20 rounded-sm px-3 py-1.5 hover:bg-ink/5">
        + Add question
      </button>

      {error && <p className="text-sm text-flag bg-flag/5 border border-flag/20 rounded-sm px-3 py-2">{error}</p>}

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={submitting}
          className="bg-ink text-paper font-medium text-sm px-5 py-2 rounded-sm hover:bg-ink/90 disabled:opacity-50"
        >
          {submitting ? 'Creating…' : 'Create assessment'}
        </button>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="text-sm text-slate px-3 py-2 hover:text-ink"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
