import { useState, useEffect, useCallback } from 'react';
import Shell from '../components/Shell.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { assessmentsApi, gradingApi, reviewApi } from '../services/api.js';
import AssessmentPicker from '../components/AssessmentPicker.jsx';
import ReviewQueue from '../components/ReviewQueue.jsx';
import ResultsTable from '../components/ResultsTable.jsx';

const TABS = [
  { id: 'review', label: 'Review queue' },
  { id: 'results', label: 'All results' },
];

export default function FacultyDashboard() {
  const { token } = useAuth();
  const [assessments, setAssessments] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [tab, setTab] = useState('review');
  const [queue, setQueue] = useState([]);
  const [results, setResults] = useState([]);
  const [error, setError] = useState('');

  const loadAssessments = useCallback(async () => {
    try {
      const { assessments } = await assessmentsApi.list(token);
      setAssessments(assessments);
      setSelectedId((prev) => prev || (assessments.length > 0 ? assessments[0].id : null));
    } catch (err) {
      setError(err.message);
    }
  }, [token]);

  const loadData = useCallback(async () => {
    if (!selectedId) return;
    try {
      const [queueRes, resultsRes] = await Promise.all([
        reviewApi.queue(selectedId, token),
        gradingApi.results(selectedId, token),
      ]);
      setQueue(queueRes.queue);
      setResults(resultsRes.results);
    } catch (err) {
      setError(err.message);
    }
  }, [selectedId, token]);

  useEffect(() => {
    loadAssessments();
  }, [loadAssessments]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  function handleDecided(gradingResultId) {
    setQueue((q) => q.filter((item) => item.id !== gradingResultId));
    loadData();
  }

  return (
    <Shell>
      <h1 className="font-serif text-2xl text-ink mb-1">Faculty dashboard</h1>
      <p className="text-slate text-sm mb-6">Review low-confidence AI grades and browse final results.</p>

      {error && (
        <p className="text-sm text-flag bg-flag/5 border border-flag/20 rounded-sm px-3 py-2 mb-6">{error}</p>
      )}

      {assessments.length === 0 ? (
        <div className="border border-dashed border-ink/20 rounded-sm p-10 text-center text-slate text-sm">
          No assessments yet — ask an admin to set one up.
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between mb-6">
            <div>
              <label className="block text-xs font-medium text-slate mb-1">Assessment</label>
              <AssessmentPicker assessments={assessments} selectedId={selectedId} onChange={setSelectedId} />
            </div>
            <div className="flex border-b border-ink/10">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`px-4 pb-2 text-sm font-medium transition-colors ${
                    tab === t.id ? 'text-ink border-b-2 border-gold' : 'text-slate'
                  }`}
                >
                  {t.label}
                  {t.id === 'review' && queue.length > 0 && (
                    <span className="ml-1.5 inline-flex items-center justify-center text-xs bg-gold text-paper rounded-full w-5 h-5">
                      {queue.length}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {tab === 'review' ? (
            <ReviewQueue queue={queue} onDecided={handleDecided} />
          ) : (
            <div className="bg-white border border-ink/10 rounded-sm p-6">
              <ResultsTable results={results} />
            </div>
          )}
        </>
      )}
    </Shell>
  );
}
