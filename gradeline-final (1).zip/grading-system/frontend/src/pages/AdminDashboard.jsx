import { useState, useEffect, useCallback } from 'react';
import Shell from '../components/Shell.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { assessmentsApi, answerSheetsApi, referenceDocsApi, gradingApi } from '../services/api.js';
import AssessmentForm from '../components/AssessmentForm.jsx';
import AssessmentPicker from '../components/AssessmentPicker.jsx';
import AnswerSheetPanel from '../components/AnswerSheetPanel.jsx';
import ReferenceDocsPanel from '../components/ReferenceDocsPanel.jsx';
import ResultsTable from '../components/ResultsTable.jsx';

export default function AdminDashboard() {
  const { token } = useAuth();
  const [assessments, setAssessments] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [answerSheets, setAnswerSheets] = useState([]);
  const [refDocs, setRefDocs] = useState([]);
  const [results, setResults] = useState([]);
  const [error, setError] = useState('');

  const loadAssessments = useCallback(async () => {
    try {
      const { assessments } = await assessmentsApi.list(token);
      setAssessments(assessments);
      setSelectedId((prev) => prev || (assessments.length > 0 ? assessments[0].id : null));
    } catch (err) {
      setError(err.message);
    }
  }, [token]);

  const loadAssessmentData = useCallback(async () => {
    if (!selectedId) return;
    try {
      const [sheetsRes, docsRes, resultsRes] = await Promise.all([
        answerSheetsApi.list(selectedId, token),
        referenceDocsApi.list(selectedId, token),
        gradingApi.results(selectedId, token),
      ]);
      setAnswerSheets(sheetsRes.answerSheets);
      setRefDocs(docsRes.referenceDocuments);
      setResults(resultsRes.results);
    } catch (err) {
      setError(err.message);
    }
  }, [selectedId, token]);

  useEffect(() => {
    loadAssessments();
  }, [loadAssessments]);

  useEffect(() => {
    loadAssessmentData();
  }, [loadAssessmentData]);

  async function handleCreateAssessment(payload) {
    await assessmentsApi.create(payload, token);
    await loadAssessments();
  }

  return (
    <Shell>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-serif text-2xl text-ink mb-1">Admin dashboard</h1>
          <p className="text-slate text-sm">Set up assessments, upload answer sheets, and run AI grading.</p>
        </div>
        <AssessmentForm onCreate={handleCreateAssessment} />
      </div>

      {error && (
        <p className="text-sm text-flag bg-flag/5 border border-flag/20 rounded-sm px-3 py-2 mb-6">{error}</p>
      )}

      {assessments.length === 0 ? (
        <div className="border border-dashed border-ink/20 rounded-sm p-10 text-center text-slate text-sm">
          Create your first assessment to get started.
        </div>
      ) : (
        <>
          <div className="mb-6">
            <label className="block text-xs font-medium text-slate mb-1">Assessment</label>
            <AssessmentPicker assessments={assessments} selectedId={selectedId} onChange={setSelectedId} />
          </div>

          <div className="space-y-6">
            <ReferenceDocsPanel assessmentId={selectedId} docs={refDocs} onRefresh={loadAssessmentData} />
            <AnswerSheetPanel assessmentId={selectedId} answerSheets={answerSheets} onRefresh={loadAssessmentData} />

            <div className="bg-white border border-ink/10 rounded-sm p-6">
              <h2 className="font-serif text-lg text-ink mb-4">Results</h2>
              <ResultsTable results={results} />
            </div>
          </div>
        </>
      )}
    </Shell>
  );
}
