import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Login() {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'faculty', adminInviteCode: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      if (mode === 'login') {
        await login(form.email, form.password);
      } else {
        await register(form);
      }
      const redirectTo = location.state?.from || '/';
      navigate(redirectTo, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-paper flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="mb-10 text-center">
          <div className="inline-flex items-baseline gap-2 mb-2">
            <span className="font-serif text-3xl text-ink">Gradeline</span>
          </div>
          <p className="text-slate text-sm">AI-assisted answer sheet grading</p>
        </div>

        <div className="bg-white border border-ink/10 rounded-sm p-8">
          <div className="flex mb-6 border-b border-ink/10">
            <button
              type="button"
              onClick={() => setMode('login')}
              className={`flex-1 pb-3 text-sm font-medium transition-colors ${
                mode === 'login' ? 'text-ink border-b-2 border-gold' : 'text-slate'
              }`}
            >
              Sign in
            </button>
            <button
              type="button"
              onClick={() => setMode('register')}
              className={`flex-1 pb-3 text-sm font-medium transition-colors ${
                mode === 'register' ? 'text-ink border-b-2 border-gold' : 'text-slate'
              }`}
            >
              Create account
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-slate mb-1">Full name</label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={update('name')}
                  className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate mb-1">Email</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={update('email')}
                className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate mb-1">Password</label>
              <input
                type="password"
                required
                minLength={8}
                value={form.password}
                onChange={update('password')}
                className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold"
              />
              {mode === 'register' && (
                <p className="text-xs text-slate mt-1">At least 8 characters.</p>
              )}
            </div>

            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-slate mb-1">Role</label>
                <select
                  value={form.role}
                  onChange={update('role')}
                  className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold"
                >
                  <option value="faculty">Faculty</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
            )}

            {mode === 'register' && form.role === 'admin' && (
              <div>
                <label className="block text-xs font-medium text-slate mb-1">Admin invite code</label>
                <input
                  type="password"
                  value={form.adminInviteCode}
                  onChange={update('adminInviteCode')}
                  placeholder="Required to register as admin"
                  className="w-full border border-ink/15 rounded-sm px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold"
                />
                <p className="text-xs text-slate mt-1">Ask whoever set up this server for the code (ADMIN_INVITE_CODE in their .env).</p>
              </div>
            )}

            {error && (
              <p className="text-sm text-flag bg-flag/5 border border-flag/20 rounded-sm px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-ink text-paper font-medium text-sm py-2.5 rounded-sm hover:bg-ink/90 transition-colors disabled:opacity-50"
            >
              {submitting ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
