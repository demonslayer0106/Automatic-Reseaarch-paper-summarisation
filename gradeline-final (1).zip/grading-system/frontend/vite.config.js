import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // Anything the frontend calls at /api/* is forwarded to the backend.
    // This is how the two chunks (frontend + backend) talk to each other
    // in development without CORS headaches.
    proxy: {
      '/api': 'http://localhost:4000',
    },
  },
});
