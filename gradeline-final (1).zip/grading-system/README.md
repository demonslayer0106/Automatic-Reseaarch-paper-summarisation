# Gradeline — AI Answer Sheet Grading System

## Setup

Requires Node.js 22.5+ (for the built-in `node:sqlite` module — see note below).

> **Why 22.5+, not 18+ like earlier**: the backend originally used the `better-sqlite3` npm
> package, which ships pre-compiled binaries per Node version — on a very new or uncommon
> Node build, none exists yet, forcing a from-source compile that needs a C++ toolchain
> (Visual Studio Build Tools on Windows) most machines don't have. It's since been switched
> to Node's own built-in `node:sqlite` module instead, so there's nothing to install or
> compile for the database at all — it's part of Node itself. The only cost is the version
> floor: `node:sqlite` didn't exist before Node 22.5. It's marked "experimental" by Node but
> is functionally solid for this project's use (verified against the full pipeline: vector
> search via sqlite-vec, multi-statement transactions, foreign-key enforcement).

**Backend**
```bash
cd backend
npm install
cp .env.example .env
```
Edit `.env`:
- `JWT_SECRET` and `ADMIN_INVITE_CODE` — any two long random strings (`openssl rand -hex 32`)
- `GEMINI_API_KEY` — free, no credit card, from https://aistudio.google.com/apikey (used for OCR + embeddings)
- `GROQ_API_KEY` — free, no credit card, from https://console.groq.com (used for grading)

```bash
npm run dev
```
Runs at `http://localhost:4000`. Creates `backend/data.sqlite` and `backend/uploads/` automatically.

**Frontend** (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Runs at `http://localhost:5173`.

**First account**: register normally (creates a `faculty` account). To get an `admin` account, register with role `admin` and the `ADMIN_INVITE_CODE` you set above — the registration form shows an invite-code field once you pick "Admin".

## What faculty vs admin can do

Both roles can create assessments, upload answer sheets, add reference material, run OCR/grading, and review results — but **faculty only see and act on assessments they personally created**; admin sees everything. This was a real gap in an earlier version (any faculty account could see any assessment by guessing its id) — see the security report below.

## How the pipeline works, end to end

1. Create an assessment with a rubric (question text, max marks, criteria — criteria marks must sum to the question's max, enforced server-side)
2. Optionally add reference material — paste text, or point `POST /api/reference-documents/ingest-path` at a folder on the server's disk containing PDFs/DOCX/PPTX/TXT/MD in any mix; every file gets chunked and embedded automatically
3. Upload a handwritten (or typed) PDF answer sheet
4. Click **Run OCR** — Gemini reads the PDF directly (no conversion needed) and transcribes + splits it by question
5. Click **Run AI grading** — starts a background job (doesn't block the UI); for each question: retrieves relevant evidence by real vector search (question + rubric only, never the student's answer), sends question + rubric + answer + evidence to Groq, gets back marks per criterion and a confidence score
6. Confidence = `min(OCR confidence, grading confidence)`. Below 0.75 (configurable) → **Review queue**; above → auto-approved
7. Both land in **Results**

## Known limitations

- OCR needs legible handwriting and question numbers Gemini can identify (Q1, Question 2, etc.)
- RAG retrieval is real vector search (Gemini embeddings + sqlite-vec), not keyword matching — but still cosine similarity, not a reranked/hybrid system; fine for a course-sized corpus
- The async grading "job queue" is in-process (no Redis/worker service) — appropriate for one backend instance, not for horizontal scaling
- No password-reset or email-verification flow

## Security & correctness audit (this pass)

A focused security/correctness review was done against 14 specific concerns. Full report below. In short: admin self-registration is closed off, faculty are now scoped to their own assessments everywhere, re-grading no longer creates duplicates (it versions), rubric math is validated server-side, prompt injection has a real mitigation (system/user message separation + explicit data delimiting), reference material is cleaned and deduped, there's an audit log, and there's a real (currently empty) evaluation-dataset schema for measuring AI-vs-human grading accuracy later.

**Migration note**: the database schema changed (new columns, new constraints, new tables). Since this is prototype/dev data, the simplest safe path is: delete `backend/data.sqlite*` and let it recreate on next `npm run dev`. There is no production data to preserve at this stage.
