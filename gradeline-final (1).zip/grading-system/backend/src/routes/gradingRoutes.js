const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { startGrading, getJobStatus, listResults } = require('../controllers/gradingController');

router.use(authenticate);

router.post('/run', requireRole('admin', 'faculty'), startGrading); // returns a jobId immediately, grades in the background
router.get('/jobs/:id', requireRole('admin', 'faculty'), getJobStatus); // poll for progress
router.get('/results', listResults); // ownership-checked inside the controller

module.exports = router;
