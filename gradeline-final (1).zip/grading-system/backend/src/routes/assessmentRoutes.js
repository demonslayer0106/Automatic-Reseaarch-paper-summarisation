const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const {
  createAssessment,
  listAssessments,
  getAssessment,
} = require('../controllers/assessmentController');

router.use(authenticate);

router.post('/', requireRole('admin', 'faculty'), createAssessment); // faculty create their own; ownership tracked via created_by
router.get('/', listAssessments); // scoped by ownership inside the controller — admin sees all, faculty see their own
router.get('/:id', getAssessment); // ownership-checked inside the controller

module.exports = router;
