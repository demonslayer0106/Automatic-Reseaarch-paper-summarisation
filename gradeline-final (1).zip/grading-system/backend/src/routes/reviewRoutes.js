const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { getReviewQueue, submitDecision } = require('../controllers/reviewController');

router.use(authenticate);

router.get('/queue', requireRole('admin', 'faculty'), getReviewQueue);
router.post('/:id/decide', requireRole('admin', 'faculty'), submitDecision);

module.exports = router;
