const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { ingestPath, addPastedText, listSources } = require('../controllers/referenceDocController');

router.use(authenticate);

router.post('/ingest-path', requireRole('admin'), ingestPath); // folder/file on the server's disk
router.post('/', requireRole('admin'), addPastedText);         // pasted text
router.get('/', listSources);

module.exports = router;
