const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const {
  uploadAnswerSheet,
  listAnswerSheets,
} = require('../controllers/answerSheetController');
const {
  triggerProcessing,
  listStructuredAnswers,
} = require('../controllers/processingController');

router.use(authenticate);

// Chunk 3: upload & list
router.post('/', requireRole('admin', 'faculty'), upload.single('file'), uploadAnswerSheet);
router.get('/', listAnswerSheets); // ownership-checked inside the controller

// Chunk 4: OCR / segmentation pipeline
router.post('/:id/process', requireRole('admin', 'faculty'), triggerProcessing); // ownership-checked inside the controller
router.get('/:id/structured-answers', listStructuredAnswers); // ownership-checked inside the controller

module.exports = router;
