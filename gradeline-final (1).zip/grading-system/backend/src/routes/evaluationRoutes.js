const express = require('express');
const router = express.Router();
const { authenticate, requireRole } = require('../middleware/auth');
const { recordEvaluation, getMetrics } = require('../controllers/evaluationController');

router.use(authenticate);

router.post('/:id', requireRole('admin', 'faculty'), recordEvaluation);
router.get('/metrics', requireRole('admin', 'faculty'), getMetrics);

module.exports = router;
