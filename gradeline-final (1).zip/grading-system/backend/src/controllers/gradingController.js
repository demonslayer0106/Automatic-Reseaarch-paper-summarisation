const { db } = require('../db');
const { newId } = require('../utils/ids');
const { retrieveEvidence } = require('../pipeline/ragRetrieval');
const { gradeAnswer } = require('../pipeline/gradingAgent');
const { logAudit } = require('../utils/audit');
const { checkAnswerSheetAccess, checkAssessmentAccess } = require('../utils/ownership');

const CONFIDENCE_THRESHOLD = Number(process.env.CONFIDENCE_THRESHOLD || 0.75);
const OCR_MODEL = process.env.OCR_MODEL || 'gemini-2.5-flash';

/**
 * ASYNC GRADING — the old version graded every question in a sheet
 * sequentially inside one HTTP request handler, so a 10-question sheet
 * blocked the request (and the frontend spinner) until all 10 Groq calls
 * finished, one after another. Now: POST /run creates a grading_jobs row
 * and returns immediately; the actual grading happens in this function,
 * called WITHOUT awaiting it from the route handler, so control returns
 * to the event loop and the server can serve other requests (including
 * the frontend's progress-polling calls) while grading continues.
 */
async function runGradingJob(jobId, answerSheetId, actorUserId) {
  db.prepare(`UPDATE grading_jobs SET status = 'running', started_at = CURRENT_TIMESTAMP WHERE id = ?`).run(jobId);

  const sheet = db.prepare('SELECT * FROM answer_sheets WHERE id = ?').get(answerSheetId);
  const assessment = db.prepare('SELECT * FROM assessments WHERE id = ?').get(sheet.assessment_id);
  const structuredAnswers = db.prepare('SELECT * FROM structured_answers WHERE answer_sheet_id = ?').all(answerSheetId);
  const rubricItems = db.prepare('SELECT * FROM rubric_items WHERE assessment_id = ?').all(sheet.assessment_id);
  // Safe to key by question_number now: the DB's UNIQUE(assessment_id,
  // question_number) constraint on rubric_items guarantees no duplicates
  // can exist here to silently collide in this Map.
  const rubricByQuestion = new Map(rubricItems.map((r) => [r.question_number, r]));

  const errors = [];
  let completed = 0;

  for (const answer of structuredAnswers) {
    const rubricItem = rubricByQuestion.get(answer.question_number);
    if (!rubricItem) {
      errors.push({ questionNumber: answer.question_number, error: 'No matching rubric item found for this question number' });
      completed++;
      db.prepare('UPDATE grading_jobs SET completed = ? WHERE id = ?').run(completed, jobId);
      continue;
    }

    const criteria = db
      .prepare('SELECT id, description, marks FROM rubric_criteria WHERE rubric_item_id = ?')
      .all(rubricItem.id);

    try {
      // Retrieve evidence using the QUESTION + RUBRIC only — never the student's
      // answer (see ragRetrieval.js comment for why).
      const criteriaText = criteria.map((c) => c.description).join('. ');
      const evidence = await retrieveEvidence(sheet.assessment_id, `${rubricItem.question_text}. ${criteriaText}`);

      const graded = await gradeAnswer({
        questionText: rubricItem.question_text,
        maxMarks: rubricItem.max_marks,
        criteria,
        studentAnswer: answer.answer_text,
        evidence,
      });

      // FINAL CONFIDENCE = min(OCR confidence, grading confidence) — a shaky
      // handwriting transcription drags confidence down even if the grader
      // felt sure about the (possibly wrong) text it was handed.
      const finalConfidence = Math.min(answer.ocr_confidence, graded.confidenceScore);
      const reviewStatus = finalConfidence >= CONFIDENCE_THRESHOLD ? 'auto_approved' : 'pending_review';

      const id = newId('grade');

      // VERSIONING: supersede any existing current result for this exact
      // (sheet, question) pair rather than insert a duplicate. The old row
      // is kept (is_current=0) for history/audit, not deleted — re-running
      // grading is a deliberate, tracked action, not a silent overwrite.
      const runTransaction = db.transaction(() => {
        db.prepare(
          `UPDATE grading_results SET is_current = 0 WHERE answer_sheet_id = ? AND question_number = ? AND is_current = 1`
        ).run(answerSheetId, answer.question_number);

        db.prepare(
          `INSERT INTO grading_results
           (id, assessment_id, answer_sheet_id, question_number, student_identifier, question_text, answer_text,
            marks_awarded, max_marks, criterion_results, explanation, evidence, confidence_score, review_status,
            is_current, grading_run_id, grading_model, ocr_model, evidence_as_of)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)`
        ).run(
          id,
          sheet.assessment_id,
          answerSheetId,
          answer.question_number,
          sheet.student_identifier,
          rubricItem.question_text,
          answer.answer_text,
          graded.marksAwarded,
          rubricItem.max_marks,
          JSON.stringify(graded.criterionResults),
          graded.explanation,
          JSON.stringify(evidence),
          finalConfidence,
          reviewStatus,
          jobId,
          graded.model,
          OCR_MODEL,
          assessment.reference_updated_at || null
        );
      });
      runTransaction();
    } catch (err) {
      errors.push({ questionNumber: answer.question_number, error: err.message });
    }

    completed++;
    db.prepare('UPDATE grading_jobs SET completed = ? WHERE id = ?').run(completed, jobId);
  }

  db.prepare(
    `UPDATE grading_jobs SET status = 'completed', finished_at = CURRENT_TIMESTAMP, error = ? WHERE id = ?`
  ).run(errors.length > 0 ? JSON.stringify(errors) : null, jobId);

  logAudit(actorUserId, 'grading.run_completed', 'answer_sheet', answerSheetId, {
    jobId,
    questionsGraded: completed - errors.length,
    errors: errors.length,
  });
}

/**
 * Starts a grading job and returns immediately — the frontend polls
 * GET /api/grading/jobs/:id for progress instead of waiting on this
 * request to finish.
 */
async function startGrading(req, res) {
  const { answerSheetId } = req.body;
  if (!answerSheetId) return res.status(400).json({ error: 'answerSheetId is required' });

  const { sheet, error } = checkAnswerSheetAccess(answerSheetId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });
  if (sheet.status !== 'processed') {
    return res.status(400).json({ error: `Answer sheet must be processed first (current status: ${sheet.status})` });
  }

  const totalQuestions = db
    .prepare('SELECT COUNT(*) as n FROM structured_answers WHERE answer_sheet_id = ?')
    .get(answerSheetId).n;

  const jobId = newId('job');
  db.prepare(
    'INSERT INTO grading_jobs (id, answer_sheet_id, status, total, completed) VALUES (?, ?, ?, ?, 0)'
  ).run(jobId, answerSheetId, 'queued', totalQuestions);

  logAudit(req.user.id, 'grading.run_started', 'answer_sheet', answerSheetId, { jobId, totalQuestions });

  // Deliberately not awaited — see runGradingJob's docstring.
  runGradingJob(jobId, answerSheetId, req.user.id).catch((err) => {
    db.prepare(`UPDATE grading_jobs SET status = 'failed', error = ?, finished_at = CURRENT_TIMESTAMP WHERE id = ?`).run(err.message, jobId);
  });

  res.status(202).json({ jobId, status: 'queued', total: totalQuestions });
}

function getJobStatus(req, res) {
  const job = db.prepare('SELECT * FROM grading_jobs WHERE id = ?').get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Grading job not found' });

  const { error } = checkAnswerSheetAccess(job.answer_sheet_id, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  res.json({
    id: job.id,
    answerSheetId: job.answer_sheet_id,
    status: job.status,
    total: job.total,
    completed: job.completed,
    errors: job.error ? JSON.parse(job.error) : null,
    startedAt: job.started_at,
    finishedAt: job.finished_at,
  });
}

function toGradingResultShape(row) {
  return {
    id: row.id,
    assessmentId: row.assessment_id,
    answerSheetId: row.answer_sheet_id,
    questionNumber: row.question_number,
    studentIdentifier: row.student_identifier,
    questionText: row.question_text,
    answerText: row.answer_text,
    marksAwarded: row.marks_awarded,
    maxMarks: row.max_marks,
    criterionResults: JSON.parse(row.criterion_results),
    explanation: row.explanation,
    evidence: JSON.parse(row.evidence),
    confidenceScore: row.confidence_score,
    reviewStatus: row.review_status,
    gradingModel: row.grading_model,
    ocrModel: row.ocr_model,
    // Staleness signal: true if reference material was added/changed after
    // this grade was produced, so the UI can flag "evidence may be outdated".
    evidenceStale: Boolean(row.assessment_reference_updated_at && row.evidence_as_of !== row.assessment_reference_updated_at),
    createdAt: row.created_at,
  };
}

/**
 * Final results (also used as the review queue's "all results" view).
 * Only ever returns is_current=1 rows — superseded grading runs stay in
 * the table for history but are never shown as if they were current.
 */
function listResults(req, res) {
  const { assessmentId, reviewStatus } = req.query;
  if (!assessmentId) return res.status(400).json({ error: 'assessmentId query param is required' });

  const { error } = checkAssessmentAccess(assessmentId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  let query = `
    SELECT gr.*, a.reference_updated_at as assessment_reference_updated_at
    FROM grading_results gr
    JOIN assessments a ON a.id = gr.assessment_id
    WHERE gr.assessment_id = ? AND gr.is_current = 1`;
  const params = [assessmentId];
  if (reviewStatus) {
    query += ' AND gr.review_status = ?';
    params.push(reviewStatus);
  }
  query += ' ORDER BY gr.created_at DESC';

  const rows = db.prepare(query).all(...params);
  res.json({ results: rows.map(toGradingResultShape) });
}

module.exports = { startGrading, getJobStatus, listResults, toGradingResultShape };
