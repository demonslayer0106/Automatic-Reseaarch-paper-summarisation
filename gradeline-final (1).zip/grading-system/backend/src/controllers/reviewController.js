const { db } = require('../db');
const { newId } = require('../utils/ids');
const { toGradingResultShape } = require('./gradingController');
const { logAudit } = require('../utils/audit');
const { checkAssessmentAccess, checkGradingResultAccess } = require('../utils/ownership');

function getReviewQueue(req, res) {
  const { assessmentId } = req.query;
  if (!assessmentId) return res.status(400).json({ error: 'assessmentId query param is required' });

  const { error } = checkAssessmentAccess(assessmentId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  const rows = db
    .prepare(
      `SELECT gr.*, a.reference_updated_at as assessment_reference_updated_at
       FROM grading_results gr
       JOIN assessments a ON a.id = gr.assessment_id
       WHERE gr.assessment_id = ? AND gr.review_status = 'pending_review' AND gr.is_current = 1
       ORDER BY gr.confidence_score ASC`
    )
    .all(assessmentId);

  res.json({ queue: rows.map(toGradingResultShape) });
}

function submitDecision(req, res) {
  const { id } = req.params; // grading_result id
  const { finalMarksAwarded, reviewerNotes } = req.body;

  if (typeof finalMarksAwarded !== 'number' || !Number.isFinite(finalMarksAwarded)) {
    return res.status(400).json({ error: 'finalMarksAwarded (number) is required' });
  }

  // SECURITY: without this, any authenticated faculty account could submit
  // a review decision for ANY grading result on the server just by
  // guessing/enumerating ids — this scopes it to results the caller
  // actually has access to (their own assessments, or all of them if admin).
  const { result: gradingResult, error } = checkGradingResultAccess(id, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  if (!gradingResult.is_current) {
    return res.status(409).json({ error: 'This grading result has been superseded by a newer grading run and can no longer be reviewed' });
  }
  if (finalMarksAwarded < 0 || finalMarksAwarded > gradingResult.max_marks) {
    return res.status(400).json({ error: `finalMarksAwarded must be between 0 and ${gradingResult.max_marks}` });
  }

  const runTransaction = db.transaction(() => {
    db.prepare(
      `INSERT INTO review_decisions (id, grading_result_id, reviewer_id, final_marks_awarded, reviewer_notes)
       VALUES (?, ?, ?, ?, ?)`
    ).run(newId('review'), id, req.user.id, finalMarksAwarded, reviewerNotes || '');

    db.prepare(
      `UPDATE grading_results SET marks_awarded = ?, review_status = 'reviewed' WHERE id = ?`
    ).run(finalMarksAwarded, id);
  });
  runTransaction();

  logAudit(req.user.id, 'review.decided', 'grading_result', id, {
    finalMarksAwarded,
    aiOriginalMarks: gradingResult.marks_awarded,
    reviewerNotes: reviewerNotes || '',
  });

  const updated = db
    .prepare(
      `SELECT gr.*, a.reference_updated_at as assessment_reference_updated_at
       FROM grading_results gr JOIN assessments a ON a.id = gr.assessment_id WHERE gr.id = ?`
    )
    .get(id);
  res.json({ result: toGradingResultShape(updated) });
}

module.exports = { getReviewQueue, submitDecision };
