const fs = require('fs');
const { db } = require('../db');
const { newId } = require('../utils/ids');
const { processAnswerSheet } = require('../pipeline/ocrSegmentation');
const { logAudit } = require('../utils/audit');
const { checkAnswerSheetAccess } = require('../utils/ownership');

async function triggerProcessing(req, res) {
  const sheetId = req.params.id;

  const { sheet, error } = checkAnswerSheetAccess(sheetId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  db.prepare('UPDATE answer_sheets SET status = ? WHERE id = ?').run('processing', sheetId);

  try {
    const pdfBuffer = fs.readFileSync(sheet.file_path);
    const structuredAnswers = await processAnswerSheet(pdfBuffer);

    // The UNIQUE(answer_sheet_id, question_number) constraint added to
    // structured_answers means a duplicate question number from Gemini's
    // response would fail this insert — parseOcrResponse() in
    // ocrSegmentation.js already merges duplicates before we get here, so
    // this is a real guarantee, not just an assumption.
    const deleteExisting = db.prepare('DELETE FROM structured_answers WHERE answer_sheet_id = ?');
    const insert = db.prepare(
      `INSERT INTO structured_answers (id, answer_sheet_id, question_number, answer_text, ocr_confidence)
       VALUES (?, ?, ?, ?, ?)`
    );

    const runTransaction = db.transaction(() => {
      deleteExisting.run(sheetId);
      for (const ans of structuredAnswers) {
        insert.run(newId('sa'), sheetId, ans.questionNumber, ans.answerText, ans.confidence);
      }
      db.prepare('UPDATE answer_sheets SET status = ? WHERE id = ?').run('processed', sheetId);
    });
    runTransaction();

    logAudit(req.user.id, 'answer_sheet.processed', 'answer_sheet', sheetId, {
      questionsDetected: structuredAnswers.length,
      ocrModel: process.env.OCR_MODEL || 'gemini-2.5-flash',
    });

    res.json({ structuredAnswers: getStructuredAnswers(sheetId) });
  } catch (err) {
    db.prepare('UPDATE answer_sheets SET status = ? WHERE id = ?').run('failed', sheetId);
    logAudit(req.user.id, 'answer_sheet.processing_failed', 'answer_sheet', sheetId, { error: err.message });
    res.status(422).json({ error: `Processing failed: ${err.message}` });
  }
}

function getStructuredAnswers(sheetId) {
  return db
    .prepare('SELECT * FROM structured_answers WHERE answer_sheet_id = ?')
    .all(sheetId)
    .map((r) => ({
      id: r.id,
      answerSheetId: r.answer_sheet_id,
      questionNumber: r.question_number,
      answerText: r.answer_text,
      confidence: r.ocr_confidence,
    }));
}

function listStructuredAnswers(req, res) {
  const { error } = checkAnswerSheetAccess(req.params.id, req.user);
  if (error) return res.status(error.status).json({ error: error.message });
  res.json({ structuredAnswers: getStructuredAnswers(req.params.id) });
}

module.exports = { triggerProcessing, listStructuredAnswers, getStructuredAnswers };
