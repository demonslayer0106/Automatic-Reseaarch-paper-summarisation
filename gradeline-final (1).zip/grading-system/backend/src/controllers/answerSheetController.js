const fs = require('fs');
const { db } = require('../db');
const { newId } = require('../utils/ids');
const { logAudit } = require('../utils/audit');
const { checkAssessmentAccess } = require('../utils/ownership');

function uploadAnswerSheet(req, res) {
  const { assessmentId, studentIdentifier } = req.body;
  if (!assessmentId || !studentIdentifier) {
    if (req.file) fs.unlink(req.file.path, () => {}); // don't leave an orphaned upload on disk
    return res.status(400).json({ error: 'assessmentId and studentIdentifier are required' });
  }
  if (!req.file) {
    return res.status(400).json({ error: 'A PDF file is required (field name: file)' });
  }

  // SECURITY: a faculty member could otherwise upload a sheet against an
  // assessment they don't own — checkAssessmentAccess() rejects that with
  // the same ownership rule used everywhere else (admin: all, faculty: own).
  const { error } = checkAssessmentAccess(assessmentId, req.user);
  if (error) {
    fs.unlink(req.file.path, () => {});
    return res.status(error.status).json({ error: error.message });
  }

  const id = newId('sheet');
  db.prepare(
    `INSERT INTO answer_sheets (id, assessment_id, student_identifier, file_name, file_path, status, uploaded_by)
     VALUES (?, ?, ?, ?, ?, 'uploaded', ?)`
  ).run(id, assessmentId, studentIdentifier.trim(), req.file.originalname, req.file.path, req.user.id);

  logAudit(req.user.id, 'answer_sheet.uploaded', 'answer_sheet', id, { assessmentId, studentIdentifier: studentIdentifier.trim() });

  res.status(201).json({ answerSheet: getAnswerSheetById(id) });
}

function getAnswerSheetById(id) {
  const row = db.prepare('SELECT * FROM answer_sheets WHERE id = ?').get(id);
  if (!row) return null;
  return {
    id: row.id,
    assessmentId: row.assessment_id,
    studentIdentifier: row.student_identifier,
    fileName: row.file_name,
    status: row.status,
    uploadedAt: row.uploaded_at,
  };
}

function listAnswerSheets(req, res) {
  const { assessmentId } = req.query;
  if (!assessmentId) {
    return res.status(400).json({ error: 'assessmentId query param is required' });
  }

  const { error } = checkAssessmentAccess(assessmentId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  const rows = db
    .prepare('SELECT * FROM answer_sheets WHERE assessment_id = ? ORDER BY uploaded_at DESC')
    .all(assessmentId);
  res.json({ answerSheets: rows.map((r) => getAnswerSheetById(r.id)) });
}

module.exports = { uploadAnswerSheet, listAnswerSheets, getAnswerSheetById };
