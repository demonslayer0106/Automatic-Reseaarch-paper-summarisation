const { db } = require('../db');
const { newId } = require('../utils/ids');
const { ingestFromPath } = require('../pipeline/documentIngestion');
const { chunkText, embedBatch } = require('../pipeline/embeddings');
const { logAudit } = require('../utils/audit');
const { checkAssessmentAccess } = require('../utils/ownership');

function toVectorBuffer(float32Array) {
  return Buffer.from(float32Array.buffer);
}

/**
 * Cleans raw ingested text before it's chunked/embedded:
 *  - collapses excessive whitespace (multiple blank lines, repeated spaces)
 *    left behind by PDF/PPTX extraction
 *  - rejects chunks that are mostly non-alphanumeric noise (garbled
 *    extraction artifacts), so junk doesn't get embedded and returned as
 *    if it were real evidence
 * This does NOT try to detect/strip "instruction-like" phrasing — that's
 * unreliable (it would also strip legitimate academic content that happens
 * to contain words like "ignore" or "must") and it's not actually where
 * that defense belongs. The real defense against reference material
 * (or a student answer) containing injected instructions is in
 * gradingAgent.js: everything retrieved as evidence is wrapped in
 * <retrieved_evidence> tags and explicitly framed as data, never
 * instructions, regardless of what it contains.
 */
function cleanText(text) {
  return text
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]+\n/g, '\n')
    .trim();
}

function isLikelyJunkChunk(chunk) {
  const alphanumeric = (chunk.match(/[a-zA-Z0-9]/g) || []).length;
  return chunk.length === 0 || alphanumeric / chunk.length < 0.3;
}

/**
 * Chunks one document's text, embeds every chunk, and writes both the
 * chunk rows and their vectors. Shared by both ingestion routes below.
 */
async function storeDocument({ assessmentId, title, content, sourcePath }) {
  const cleaned = cleanText(content);
  let chunks = chunkText(cleaned).filter((c) => !isLikelyJunkChunk(c));

  // Dedupe against chunks already stored for this assessment — re-ingesting
  // the same file, or a document with heavily repeated boilerplate (e.g.
  // a slide header repeated on every slide), shouldn't burn embedding
  // calls and storage on identical text.
  const existingHashes = new Set(
    db.prepare('SELECT chunk_text FROM document_chunks WHERE assessment_id = ?').all(assessmentId).map((r) => r.chunk_text)
  );
  const beforeDedupe = chunks.length;
  chunks = chunks.filter((c) => !existingHashes.has(c));
  const duplicatesSkipped = beforeDedupe - chunks.length;

  if (chunks.length === 0) {
    return { title, chunkCount: 0, duplicatesSkipped, skipped: true, reason: 'No usable new text after cleaning/deduplication' };
  }

  const sourceId = newId('src');
  db.prepare(
    'INSERT INTO reference_sources (id, assessment_id, title, source_path, chunk_count) VALUES (?, ?, ?, ?, ?)'
  ).run(sourceId, assessmentId, title, sourcePath || null, chunks.length);

  // Embedding calls happen one at a time (see embeddings.js) to stay under
  // free-tier rate limits, so this can take a few seconds for a big document.
  const vectors = await embedBatch(chunks, 'RETRIEVAL_DOCUMENT');

  const insertChunk = db.prepare(
    'INSERT INTO document_chunks (id, source_id, assessment_id, source_title, chunk_text) VALUES (?, ?, ?, ?, ?)'
  );
  const insertVector = db.prepare('INSERT INTO chunk_vectors (rowid, embedding) VALUES (?, ?)');

  const runTransaction = db.transaction(() => {
    chunks.forEach((chunkTextValue, i) => {
      const chunkId = newId('chunk');
      const info = insertChunk.run(chunkId, sourceId, assessmentId, title, chunkTextValue);
      // sqlite-vec requires the rowid passed as BigInt, not a plain number.
      insertVector.run(BigInt(info.lastInsertRowid), toVectorBuffer(vectors[i]));
    });
  });
  runTransaction();

  // VERSIONING (issue 10): touch the assessment's reference_updated_at
  // whenever the corpus changes, so grading_results snapshot this
  // timestamp as evidence_as_of and the UI can flag "reference material
  // has changed since this grade was produced" for anything graded before it.
  db.prepare('UPDATE assessments SET reference_updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(assessmentId);

  return { title, chunkCount: chunks.length, duplicatesSkipped, skipped: false };
}

/**
 * Ingests every supported file under a server-side folder or file path —
 * this is the "documents are all in one place, formats differ" entry
 * point. The path must be reachable from the backend process's filesystem.
 */
async function ingestPath(req, res) {
  const { assessmentId, sourcePath } = req.body;
  if (!assessmentId || !sourcePath) {
    return res.status(400).json({ error: 'assessmentId and sourcePath are required' });
  }
  const { error } = checkAssessmentAccess(assessmentId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  let documents, ingestErrors;
  try {
    ({ documents, errors: ingestErrors } = await ingestFromPath(sourcePath));
  } catch (err) {
    return res.status(400).json({ error: `Could not read path: ${err.message}` });
  }

  if (documents.length === 0) {
    return res.status(422).json({ error: 'No supported files found at that path', errors: ingestErrors });
  }

  const results = [];
  const embedErrors = [...ingestErrors];
  for (const doc of documents) {
    try {
      results.push(await storeDocument({ assessmentId, title: doc.title, content: doc.content, sourcePath: doc.sourcePath }));
    } catch (err) {
      embedErrors.push({ filePath: doc.sourcePath, error: err.message });
    }
  }

  logAudit(req.user.id, 'reference.ingested', 'assessment', assessmentId, {
    sourcePath,
    documentsIngested: results.length,
    errors: embedErrors.length,
  });

  res.status(201).json({ ingested: results, errors: embedErrors });
}

/**
 * Adds one reference document from pasted text (no file involved).
 */
async function addPastedText(req, res) {
  const { assessmentId, title, content } = req.body;
  if (!assessmentId || !title || !content) {
    return res.status(400).json({ error: 'assessmentId, title, and content are required' });
  }
  const { error } = checkAssessmentAccess(assessmentId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  try {
    const result = await storeDocument({ assessmentId, title, content });
    logAudit(req.user.id, 'reference.added', 'assessment', assessmentId, { title, chunkCount: result.chunkCount });
    res.status(201).json(result);
  } catch (err) {
    res.status(502).json({ error: `Embedding failed: ${err.message}` });
  }
}

function listSources(req, res) {
  const { assessmentId } = req.query;
  if (!assessmentId) return res.status(400).json({ error: 'assessmentId query param is required' });

  const { error } = checkAssessmentAccess(assessmentId, req.user);
  if (error) return res.status(error.status).json({ error: error.message });

  const rows = db
    .prepare('SELECT id, title, chunk_count, uploaded_at FROM reference_sources WHERE assessment_id = ? ORDER BY uploaded_at DESC')
    .all(assessmentId);
  res.json({
    sources: rows.map((r) => ({ id: r.id, title: r.title, chunkCount: r.chunk_count, uploadedAt: r.uploaded_at })),
  });
}

module.exports = { ingestPath, addPastedText, listSources };
