const { DatabaseSync } = require('node:sqlite');
const sqliteVec = require('sqlite-vec');
const path = require('path');

/**
 * DRIVER NOTE: this uses Node's own built-in SQLite module (node:sqlite,
 * available since Node 22.5) instead of the better-sqlite3 npm package.
 * better-sqlite3 ships pre-compiled binaries per exact Node version, and
 * when none exists yet for a very new Node release, npm falls back to
 * compiling it from source — which needs a C++ toolchain (Visual Studio
 * Build Tools on Windows) that most machines don't have set up. node:sqlite
 * needs none of that: it's compiled into the Node binary you already have,
 * so there's nothing to install or compile here at all.
 *
 * node:sqlite's API is close to better-sqlite3's (same prepare/run/get/all
 * shape) but not identical — two gaps are bridged right here so nothing
 * elsewhere in the project has to change:
 *   - no db.pragma() helper -> use db.exec('PRAGMA ...') instead
 *   - no db.transaction() helper -> a small shim below adds one with the
 *     exact same call signature (db.transaction(fn) returns a function
 *     that runs fn() wrapped in BEGIN/COMMIT/ROLLBACK), since five
 *     controllers already call it that way.
 */
const db = new DatabaseSync(path.join(__dirname, '..', 'data.sqlite'), {
  allowExtension: true, // required before loadExtension() (sqlite-vec) will work
});

db.exec('PRAGMA journal_mode = WAL');

// SQLite declares foreign keys but does NOT enforce them unless this is
// set on every connection. Without it, every `REFERENCES` clause below was
// decorative — you could insert a grading_results row pointing at an
// answer_sheet_id that doesn't exist, and SQLite would happily accept it.
db.exec('PRAGMA foreign_keys = ON');

// Loads the sqlite-vec extension into THIS SQLite connection, giving us
// real vector KNN search (cosine/L2 distance) inside the same .sqlite file
// — no separate vector database server to run or pay for. sqlite-vec's
// load() just calls db.loadExtension() under the hood, which node:sqlite
// also implements, so this line is unchanged from the better-sqlite3 version.
sqliteVec.load(db);

// better-sqlite3 compatibility shim — see driver note above.
db.transaction = function (fn) {
  return function (...args) {
    db.exec('BEGIN');
    try {
      const result = fn(...args);
      db.exec('COMMIT');
      return result;
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  };
};

const EMBEDDING_DIM = Number(process.env.EMBEDDING_DIM || 768);

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      name          TEXT NOT NULL,
      email         TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role          TEXT NOT NULL CHECK(role IN ('admin','faculty')),
      created_at    TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
  // ---------- Chunk 3: Upload & Setup ----------
  db.exec(`
    CREATE TABLE IF NOT EXISTS assessments (
      id                    TEXT PRIMARY KEY,
      title                 TEXT NOT NULL,
      created_by            INTEGER NOT NULL REFERENCES users(id),
      -- Touched whenever reference material changes, so a grading result
      -- can record "evidence as of" and later be flagged stale if the
      -- corpus has moved on since it was graded (see grading_results below).
      reference_updated_at  TEXT,
      created_at            TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS rubric_items (
      id               TEXT PRIMARY KEY,
      assessment_id    TEXT NOT NULL REFERENCES assessments(id),
      question_number  TEXT NOT NULL,
      question_text    TEXT NOT NULL,
      max_marks        REAL NOT NULL CHECK(max_marks > 0),
      sort_order       INTEGER NOT NULL,
      -- A typo'd duplicate question number ("Q1" entered twice) used to be
      -- silently swallowed by JS Maps keyed on question_number downstream
      -- (see gradingController.js) — this constraint stops it at the source.
      UNIQUE(assessment_id, question_number)
    );

    CREATE TABLE IF NOT EXISTS rubric_criteria (
      id              TEXT PRIMARY KEY,
      rubric_item_id  TEXT NOT NULL REFERENCES rubric_items(id),
      description     TEXT NOT NULL,
      marks           REAL NOT NULL CHECK(marks >= 0)
    );

    CREATE TABLE IF NOT EXISTS answer_sheets (
      id                  TEXT PRIMARY KEY,
      assessment_id       TEXT NOT NULL REFERENCES assessments(id),
      student_identifier  TEXT NOT NULL,
      file_name           TEXT NOT NULL,
      file_path           TEXT NOT NULL,
      status              TEXT NOT NULL DEFAULT 'uploaded'
                            CHECK(status IN ('uploaded','processing','processed','failed')),
      uploaded_by         INTEGER NOT NULL REFERENCES users(id),
      uploaded_at         TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // ---------- Chunk 4: OCR / Segmentation output ----------
  db.exec(`
    CREATE TABLE IF NOT EXISTS structured_answers (
      id                TEXT PRIMARY KEY,
      answer_sheet_id   TEXT NOT NULL REFERENCES answer_sheets(id),
      question_number   TEXT NOT NULL,
      answer_text       TEXT NOT NULL,
      ocr_confidence    REAL NOT NULL,
      -- A sheet re-processed twice, or Gemini splitting one answer into two
      -- entries under the same question number, used to create silent
      -- duplicates that grading would then run twice for. This constraint
      -- makes that impossible; processingController.js deletes-then-inserts
      -- on reprocess specifically to work within it (see that file).
      UNIQUE(answer_sheet_id, question_number)
    );
  `);

  // ---------- Chunk 5: AI Grading Agent — RAG corpus ----------
  db.exec(`
    -- One row per ingested source document (a file, or a pasted note).
    CREATE TABLE IF NOT EXISTS reference_sources (
      id            TEXT PRIMARY KEY,
      assessment_id TEXT NOT NULL REFERENCES assessments(id),
      title         TEXT NOT NULL,
      source_path   TEXT,             -- original file path, if ingested from disk
      chunk_count   INTEGER NOT NULL DEFAULT 0,
      uploaded_at   TEXT DEFAULT CURRENT_TIMESTAMP
    );

    -- One row per chunk of a source document. "seq" is a plain autoincrementing
    -- integer used ONLY as the rowid link into the vec0 table below, since
    -- sqlite-vec requires an integer rowid, but every other table in this
    -- project uses text ids (see utils/ids.js) — this column bridges the two.
    CREATE TABLE IF NOT EXISTS document_chunks (
      seq              INTEGER PRIMARY KEY AUTOINCREMENT,
      id               TEXT NOT NULL UNIQUE,
      source_id        TEXT NOT NULL REFERENCES reference_sources(id),
      assessment_id    TEXT NOT NULL REFERENCES assessments(id),
      source_title     TEXT NOT NULL,
      chunk_text       TEXT NOT NULL
    );
  `);

  // Real vector index: cosine-distance KNN search over chunk embeddings,
  // embedded in this same SQLite file via the sqlite-vec extension.
  db.exec(`
    CREATE VIRTUAL TABLE IF NOT EXISTS chunk_vectors USING vec0(
      embedding float[${EMBEDDING_DIM}]
    );
  `);

  db.exec(`
    -- Student -> paper -> question -> answer -> marks linkage: every field
    -- needed to identify which student's paper produced this mark is
    -- snapshotted directly on this row (question_text, answer_text,
    -- student_identifier), not just joined in from other tables — so this
    -- row remains a complete, permanent record even if upstream rows change.
    CREATE TABLE IF NOT EXISTS grading_results (
      id                  TEXT PRIMARY KEY,
      assessment_id       TEXT NOT NULL REFERENCES assessments(id),
      answer_sheet_id     TEXT NOT NULL REFERENCES answer_sheets(id),
      question_number     TEXT NOT NULL,
      student_identifier  TEXT NOT NULL,
      question_text       TEXT NOT NULL,
      answer_text         TEXT NOT NULL,
      marks_awarded       REAL NOT NULL,
      max_marks           REAL NOT NULL,
      criterion_results   TEXT NOT NULL, -- JSON array, see shared/types.ts CriterionResult[]
      explanation         TEXT NOT NULL,
      evidence            TEXT NOT NULL, -- JSON array, see shared/types.ts EvidenceSnippet[]
      confidence_score    REAL NOT NULL,
      review_status       TEXT NOT NULL DEFAULT 'pending_review'
                            CHECK(review_status IN ('auto_approved','pending_review','reviewed')),
      -- VERSIONING: re-running grading on an already-graded sheet does not
      -- overwrite or duplicate — the old row is kept for history with
      -- is_current=0, and exactly one row per (answer_sheet_id,
      -- question_number) may have is_current=1 (enforced by the partial
      -- unique index below, not just application logic).
      is_current           INTEGER NOT NULL DEFAULT 1,
      grading_run_id        TEXT NOT NULL, -- groups all results produced by one "Run AI grading" click
      grading_model         TEXT NOT NULL, -- which model produced this grade (e.g. groq:llama-3.3-70b-versatile)
      ocr_model              TEXT,          -- which model transcribed the answer this was graded from
      evidence_as_of          TEXT,          -- assessments.reference_updated_at at grading time — lets the UI
                                              -- detect "reference material has changed since this grade" staleness
      created_at          TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_grading_results_current
      ON grading_results(answer_sheet_id, question_number) WHERE is_current = 1;
  `);

  // ---------- Chunk 5: async grading jobs ----------
  db.exec(`
    -- Grading used to run synchronously inside one HTTP request, blocking
    -- until every question on a sheet was graded. This table lets
    -- POST /api/grading/run return immediately with a job id while grading
    -- continues in the background; the frontend polls for progress.
    CREATE TABLE IF NOT EXISTS grading_jobs (
      id              TEXT PRIMARY KEY,
      answer_sheet_id TEXT NOT NULL REFERENCES answer_sheets(id),
      status          TEXT NOT NULL DEFAULT 'queued'
                        CHECK(status IN ('queued','running','completed','failed')),
      total           INTEGER NOT NULL DEFAULT 0,
      completed       INTEGER NOT NULL DEFAULT 0,
      error           TEXT,
      started_at      TEXT,
      finished_at     TEXT,
      created_at      TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // ---------- Chunk 6: Human Review ----------
  db.exec(`
    CREATE TABLE IF NOT EXISTS review_decisions (
      id                    TEXT PRIMARY KEY,
      grading_result_id     TEXT NOT NULL REFERENCES grading_results(id),
      reviewer_id           INTEGER NOT NULL REFERENCES users(id),
      final_marks_awarded   REAL NOT NULL,
      reviewer_notes        TEXT,
      decided_at            TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // ---------- Audit trail ----------
  // Deliberately simple: one row per notable action, enough to answer "who
  // did what, when" for the actions that matter (grading runs, review
  // decisions, rubric/reference changes). Not a full event-sourcing system —
  // appropriate for a prototype, expandable later.
  db.exec(`
    CREATE TABLE IF NOT EXISTS audit_log (
      id              TEXT PRIMARY KEY,
      actor_user_id   INTEGER REFERENCES users(id),
      action          TEXT NOT NULL, -- e.g. 'assessment.created', 'grading.run', 'review.decided'
      entity_type     TEXT NOT NULL, -- e.g. 'assessment', 'answer_sheet', 'grading_result'
      entity_id       TEXT NOT NULL,
      metadata        TEXT,          -- JSON blob, action-specific details
      created_at      TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // ---------- Evaluation dataset (AI grade vs human grade) ----------
  // Distinct from review_decisions: a review decision CHANGES the official
  // grade. A human evaluation is a separate, non-authoritative data point
  // recorded specifically to measure AI grading accuracy later — it never
  // overwrites marks_awarded. No rows exist here until a real person enters
  // real grades; see controllers/evaluationController.js, which refuses to
  // compute metrics from an empty table rather than fabricating numbers.
  db.exec(`
    CREATE TABLE IF NOT EXISTS human_evaluations (
      id                     TEXT PRIMARY KEY,
      grading_result_id      TEXT NOT NULL REFERENCES grading_results(id),
      evaluator_id            INTEGER NOT NULL REFERENCES users(id),
      human_marks_awarded    REAL NOT NULL,
      notes                  TEXT,
      created_at              TEXT DEFAULT CURRENT_TIMESTAMP
    );
  `);
}

module.exports = { db, initDb };
