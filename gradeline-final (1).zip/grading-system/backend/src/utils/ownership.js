const { db } = require('../db');

/**
 * Fetches an assessment and checks whether `user` is allowed to see it.
 * Admins can access every assessment. Faculty can only access assessments
 * they personally created — this is the fix for "faculty could view any
 * assessment's answer sheets/review queue just by knowing its id", since
 * every route that takes an assessmentId (directly, or indirectly via an
 * answer_sheet_id/grading_result_id) funnels through this check.
 *
 * Returns { assessment } on success, or { error: { status, message } } on
 * failure — callers check `.error` rather than relying on a thrown
 * exception, since none of the controllers in this project use an
 * async-error-catching wrapper around route handlers.
 */
function checkAssessmentAccess(assessmentId, user) {
  const assessment = db.prepare('SELECT * FROM assessments WHERE id = ?').get(assessmentId);
  if (!assessment) {
    return { error: { status: 404, message: 'Assessment not found' } };
  }
  if (user.role !== 'admin' && assessment.created_by !== user.id) {
    return { error: { status: 403, message: 'You do not have access to this assessment' } };
  }
  return { assessment };
}

/**
 * Same access rule, starting from an answer_sheet_id instead — resolves
 * the sheet's assessment first, then applies the same check. Used by
 * routes keyed on answer_sheet_id (processing, grading).
 */
function checkAnswerSheetAccess(answerSheetId, user) {
  const sheet = db.prepare('SELECT * FROM answer_sheets WHERE id = ?').get(answerSheetId);
  if (!sheet) {
    return { error: { status: 404, message: 'Answer sheet not found' } };
  }
  const { assessment, error } = checkAssessmentAccess(sheet.assessment_id, user);
  if (error) return { error };
  return { sheet, assessment };
}

/**
 * Same access rule, starting from a grading_result_id — resolves the
 * result's answer sheet's assessment, then applies the same check. Used
 * by the review-decision route.
 */
function checkGradingResultAccess(gradingResultId, user) {
  const result = db.prepare('SELECT * FROM grading_results WHERE id = ?').get(gradingResultId);
  if (!result) {
    return { error: { status: 404, message: 'Grading result not found' } };
  }
  const { assessment, error } = checkAssessmentAccess(result.assessment_id, user);
  if (error) return { error };
  return { result, assessment };
}

module.exports = { checkAssessmentAccess, checkAnswerSheetAccess, checkGradingResultAccess };
