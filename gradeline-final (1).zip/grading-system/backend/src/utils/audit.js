const { db } = require('../db');
const { newId } = require('./ids');

/**
 * Records one audit entry. Called at the key action points listed in
 * README's audit trail section — grading runs, review decisions, rubric
 * and reference-material changes. Never throws: a logging failure should
 * never break the action it's logging.
 */
function logAudit(actorUserId, action, entityType, entityId, metadata = {}) {
  try {
    db.prepare(
      'INSERT INTO audit_log (id, actor_user_id, action, entity_type, entity_id, metadata) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(newId('audit'), actorUserId ?? null, action, entityType, entityId, JSON.stringify(metadata));
  } catch (err) {
    console.error('Audit log write failed (non-fatal):', err.message);
  }
}

module.exports = { logAudit };
