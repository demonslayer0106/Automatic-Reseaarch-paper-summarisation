const pdfjsLib = require('pdfjs-dist/legacy/build/pdf.js');

/**
 * Extracts embedded text from a digitally-typed PDF (lecture notes, slides
 * exported to PDF, typed answer keys). This does NOT do OCR — there's no
 * text layer to read in a scanned/handwritten PDF, which is exactly why
 * answer sheets (pipeline/ocrSegmentation.js) use Gemini's vision instead.
 */
async function extractPdfText(pdfBuffer) {
  const doc = await pdfjsLib.getDocument({
    data: new Uint8Array(pdfBuffer),
    isEvalSupported: false,
  }).promise;

  const pageTexts = [];
  for (let pageNum = 1; pageNum <= doc.numPages; pageNum++) {
    const page = await doc.getPage(pageNum);
    const content = await page.getTextContent();
    let pageText = '';
    for (const item of content.items) {
      pageText += item.str;
      pageText += item.hasEOL ? '\n' : ' ';
    }
    pageTexts.push(pageText);
  }
  await doc.destroy();

  return pageTexts.join('\n\n');
}

module.exports = { extractPdfText };
