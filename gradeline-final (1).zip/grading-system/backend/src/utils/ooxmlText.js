const AdmZip = require('adm-zip');

function decodeXmlEntities(str) {
  return str
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

/**
 * DOCX text extraction. A .docx is a zip archive; the document body text
 * lives in word/document.xml, inside <w:t> tags, with <w:p> marking
 * paragraph boundaries.
 */
function extractDocxText(fileBuffer) {
  const zip = new AdmZip(fileBuffer);
  const entry = zip.getEntry('word/document.xml');
  if (!entry) throw new Error('Not a valid .docx file (missing word/document.xml)');
  const xml = entry.getData().toString('utf-8');

  // Split into paragraphs first, then pull run text out of each paragraph
  // separately, so paragraph boundaries survive as newlines in the output.
  const paragraphs = xml.split(/<\/w:p>/);
  const lines = paragraphs.map((para) => {
    const matches = [...para.matchAll(/<w:t[^>]*>(.*?)<\/w:t>/gs)];
    return matches.map((m) => decodeXmlEntities(m[1])).join('');
  });
  return lines.filter((l) => l.trim().length > 0).join('\n').trim();
}

/**
 * PPTX text extraction. A .pptx is also a zip archive, with one XML file
 * per slide under ppt/slides/slideN.xml, text inside <a:t> tags.
 */
function extractPptxText(fileBuffer) {
  const zip = new AdmZip(fileBuffer);
  const slideEntries = zip
    .getEntries()
    .filter((e) => /^ppt\/slides\/slide\d+\.xml$/.test(e.entryName))
    .sort((a, b) => {
      const na = Number(a.entryName.match(/slide(\d+)\.xml/)[1]);
      const nb = Number(b.entryName.match(/slide(\d+)\.xml/)[1]);
      return na - nb;
    });

  if (slideEntries.length === 0) throw new Error('Not a valid .pptx file (no slides found)');

  return slideEntries
    .map((entry, i) => {
      const xml = entry.getData().toString('utf-8');
      const matches = [...xml.matchAll(/<a:t[^>]*>(.*?)<\/a:t>/gs)];
      const slideText = matches.map((m) => decodeXmlEntities(m[1])).join(' ');
      return `[Slide ${i + 1}] ${slideText}`;
    })
    .join('\n\n');
}

module.exports = { extractDocxText, extractPptxText };
