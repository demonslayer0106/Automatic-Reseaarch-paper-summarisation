/**
 * OCR + QUESTION DETECTION + ANSWER SEGMENTATION
 * ------------------------------------------------------------------
 * Handwritten answer sheets have no embedded text layer, so there's
 * nothing for a traditional text-extraction library to read — this is
 * why chunk 4's original pdfjs-dist approach only worked for typed PDFs.
 *
 * Gemini's document understanding reads the PDF's pages as images
 * natively (no separate PDF-to-image conversion needed) and can
 * transcribe handwriting directly, using surrounding context the way a
 * person would — which is why vision-language models noticeably
 * outperform traditional OCR engines on handwriting.
 *
 * One Gemini call does all three pipeline stages from the architecture
 * diagram (OCR, question-number detection, answer segmentation) at once,
 * because asking it to both transcribe AND segment in a single structured
 * response is more reliable than transcribing first and regex-parsing the
 * result afterward (regex has no idea what a page actually looks like).
 */

const MODEL = process.env.OCR_MODEL || 'gemini-2.5-flash';

function buildPrompt() {
  return `This is a scanned handwritten exam answer sheet. Transcribe it and split it by question.

Instructions:
- Find every question number the student wrote (e.g. "Q1", "Question 2", "3", "4a") and transcribe everything the student wrote for that question, in your own best reading of their handwriting.
- If a question's answer continues after being interrupted (e.g. by a page break), merge it back into that question's single entry.
- Ignore headers, the student's name/roll number, and printed instructions — only transcribe their actual answers.
- For each question, give a transcriptionConfidence from 0 to 1 for how confident you are in your reading — lower it for messy handwriting, cross-outs, smudging, or any word you had to guess at.

Respond with ONLY valid JSON, no markdown code fences, no commentary, matching exactly this shape:
{
  "answers": [
    { "questionNumber": "string, normalized like 'Q1', 'Q2a'", "answerText": "string, the transcribed answer", "transcriptionConfidence": number between 0 and 1 }
  ]
}`;
}

async function callGeminiVision(pdfBuffer) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not set in backend/.env');
  }

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { inline_data: { mime_type: 'application/pdf', data: pdfBuffer.toString('base64') } },
              { text: buildPrompt() },
            ],
          },
        ],
      }),
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Gemini API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('No text content in Gemini response');
  return text;
}

function parseOcrResponse(rawText) {
  const cleaned = rawText.replace(/```json|```/g, '').trim();
  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (err) {
    throw new Error(`Could not parse OCR response as JSON: ${err.message}`);
  }
  if (!Array.isArray(parsed.answers)) {
    throw new Error('OCR response missing "answers" array');
  }

  const cleaned_answers = parsed.answers
    .filter((a) => a.questionNumber && a.answerText && a.answerText.trim().length > 0)
    .map((a) => ({
      questionNumber: normalizeQuestionNumber(a.questionNumber),
      answerText: a.answerText.trim(),
      confidence: Math.max(0, Math.min(1, Number(a.transcriptionConfidence) || 0.5)),
    }));

  // QUESTION-NUMBER COLLISION HANDLING: Gemini occasionally splits one
  // answer into two entries under the same question number (e.g. if a
  // student's answer wraps onto a second area of the page). Rather than
  // silently keeping only one (which a naive Map-keyed-by-question-number
  // would do) or letting both through to violate the DB's UNIQUE
  // constraint on (answer_sheet_id, question_number), merge same-numbered
  // entries into one, concatenating their text and keeping the lower
  // (more cautious) of the two confidence scores.
  const merged = new Map();
  for (const ans of cleaned_answers) {
    if (merged.has(ans.questionNumber)) {
      const existing = merged.get(ans.questionNumber);
      existing.answerText = `${existing.answerText}\n${ans.answerText}`;
      existing.confidence = Math.min(existing.confidence, ans.confidence);
    } else {
      merged.set(ans.questionNumber, { ...ans });
    }
  }
  return Array.from(merged.values());
}

function normalizeQuestionNumber(raw) {
  const match = String(raw).match(/(\d+[a-zA-Z]?)/);
  return match ? `Q${match[1].toUpperCase()}` : String(raw).toUpperCase();
}

/**
 * Full pipeline entry point used by the processing controller.
 * Returns StructuredAnswer[] shapes (minus answerSheetId, which the
 * caller attaches) matching shared/types.ts.
 */
async function processAnswerSheet(pdfBuffer) {
  const rawText = await callGeminiVision(pdfBuffer);
  const answers = parseOcrResponse(rawText);
  if (answers.length === 0) {
    throw new Error('Gemini did not detect any question answers on this sheet — check the scan is legible and questions are numbered');
  }
  return answers;
}

module.exports = { processAnswerSheet, parseOcrResponse };
