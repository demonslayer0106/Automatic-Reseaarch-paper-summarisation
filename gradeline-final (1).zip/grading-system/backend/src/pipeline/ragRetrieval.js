const { db } = require('../db');
const { embedText } = require('./embeddings');

function toVectorBuffer(float32Array) {
  return Buffer.from(float32Array.buffer);
}

/**
 * Retrieves the top-N most relevant chunks from an assessment's reference
 * corpus for a given query (question + rubric — see gradingController.js,
 * which deliberately never passes the student's answer here).
 *
 * How it works:
 *   1. Embed the query text with the same Gemini embedding model used for
 *      ingestion.
 *   2. Ask sqlite-vec for the K nearest chunks BY VECTOR DISTANCE across
 *      the whole table (sqlite-vec's vec0 doesn't filter by arbitrary
 *      columns in a WHERE clause), pulling more than we need (topN * 8)
 *   3. Filter that candidate set down to this assessment's chunks and take
 *      the closest topN — cheap in JS since the candidate set is small.
 *
 * This replaces the earlier keyword-overlap version: same function
 * signature and return shape (EvidenceSnippet[] from shared/types.ts), so
 * nothing in gradingController.js had to change to use it.
 */
async function retrieveEvidence(assessmentId, queryText, topN = 3, minRelevance = 0.15) {
  const totalChunks = db.prepare('SELECT COUNT(*) as n FROM document_chunks').get().n;
  if (totalChunks === 0) return [];

  const queryVector = await embedText(queryText, 'RETRIEVAL_QUERY');
  const candidateK = Math.min(totalChunks, topN * 8);

  const nearest = db
    .prepare(
      `SELECT rowid, distance FROM chunk_vectors WHERE embedding MATCH ? AND k = ? ORDER BY distance`
    )
    .all(toVectorBuffer(queryVector), candidateK);

  if (nearest.length === 0) return [];

  const seqs = nearest.map((r) => r.rowid);
  const placeholders = seqs.map(() => '?').join(',');
  const chunkRows = db
    .prepare(`SELECT seq, source_title, chunk_text FROM document_chunks WHERE seq IN (${placeholders}) AND assessment_id = ?`)
    .all(...seqs, assessmentId);

  const distanceBySeq = new Map(nearest.map((r) => [r.rowid, r.distance]));

  const matched = chunkRows
    .map((row) => ({ row, distance: distanceBySeq.get(row.seq) }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, topN);

  if (matched.length === 0) return [];

  // Convert cosine distance (0 = identical, 2 = opposite) to a 0-1
  // "relevance score" that's intuitive to display: 1 = very relevant.
  // Chunks below minRelevance are dropped rather than force-included —
  // handing the grading agent a "closest available" chunk that isn't
  // actually relevant is worse than giving it no evidence at all, since
  // it can mistake weak evidence for a real signal.
  return matched
    .map(({ row, distance }) => ({
      source: row.source_title,
      excerpt: row.chunk_text.slice(0, 500),
      relevanceScore: Math.round(Math.max(0, 1 - distance / 2) * 100) / 100,
    }))
    .filter((e) => e.relevanceScore >= minRelevance);
}

module.exports = { retrieveEvidence };
