const fs = require('fs');
const path = require('path');
const { extractPdfText } = require('../utils/pdfText');
const { extractDocxText, extractPptxText } = require('../utils/ooxmlText');

const SUPPORTED_EXTENSIONS = new Set(['.pdf', '.docx', '.pptx', '.txt', '.md']);

/**
 * Recursively lists every file under a folder whose extension we know how
 * to read. This is the "documents are all in one place, formats differ"
 * entry point — point it at a folder and it sorts out the rest.
 */
function listSupportedFiles(rootPath) {
  const results = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(fullPath);
      } else if (SUPPORTED_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) {
        results.push(fullPath);
      }
    }
  }
  const stat = fs.statSync(rootPath);
  if (stat.isDirectory()) {
    walk(rootPath);
  } else if (SUPPORTED_EXTENSIONS.has(path.extname(rootPath).toLowerCase())) {
    results.push(rootPath);
  } else {
    throw new Error(`Unsupported file type: ${rootPath}`);
  }
  return results;
}

/**
 * Extracts plain text from one file, dispatching by extension.
 * Every extractor returns a plain string — that's the only contract
 * the rest of the RAG pipeline (chunking, embeddings) depends on.
 */
async function extractTextFromFile(filePath) {
  const buffer = fs.readFileSync(filePath);
  const ext = path.extname(filePath).toLowerCase();

  switch (ext) {
    case '.pdf':
      return extractPdfText(buffer);
    case '.docx':
      return extractDocxText(buffer);
    case '.pptx':
      return extractPptxText(buffer);
    case '.txt':
    case '.md':
      return buffer.toString('utf-8');
    default:
      throw new Error(`Unsupported file type: ${ext}`);
  }
}

/**
 * Ingests every supported file under a path (file or folder), returning
 * [{ title, content, sourcePath }] — one entry per source document.
 * A file that fails to extract is skipped with its error attached rather
 * than aborting the whole batch, since one corrupt file shouldn't block
 * ingesting the other forty.
 */
async function ingestFromPath(rootPath) {
  const files = listSupportedFiles(rootPath);
  const documents = [];
  const errors = [];

  for (const filePath of files) {
    try {
      const content = await extractTextFromFile(filePath);
      if (content.trim().length === 0) {
        errors.push({ filePath, error: 'No extractable text found' });
        continue;
      }
      documents.push({
        title: path.basename(filePath),
        content,
        sourcePath: filePath,
      });
    } catch (err) {
      errors.push({ filePath, error: err.message });
    }
  }

  return { documents, errors };
}

module.exports = { ingestFromPath, listSupportedFiles, extractTextFromFile };
