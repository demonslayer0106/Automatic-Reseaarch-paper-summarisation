const EMBEDDING_MODEL = process.env.EMBEDDING_MODEL || 'gemini-embedding-001';
const EMBEDDING_DIM = Number(process.env.EMBEDDING_DIM || 768);
const CHUNK_SIZE = 800; // characters per chunk — small enough for focused retrieval
const CHUNK_OVERLAP = 150; // overlap so a sentence split across chunks isn't lost entirely

/**
 * Splits text into overlapping chunks along paragraph boundaries where
 * possible, falling back to a hard character split for very long
 * paragraphs. Overlap means a fact stated right at a chunk boundary still
 * appears whole in at least one chunk.
 */
function chunkText(text) {
  const paragraphs = text.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const chunks = [];
  let current = '';

  for (const para of paragraphs) {
    if ((current + '\n\n' + para).length <= CHUNK_SIZE) {
      current = current ? `${current}\n\n${para}` : para;
      continue;
    }
    if (current) chunks.push(current);

    if (para.length <= CHUNK_SIZE) {
      current = para;
    } else {
      // A single paragraph longer than one chunk — hard-split it with overlap.
      let start = 0;
      while (start < para.length) {
        const end = Math.min(start + CHUNK_SIZE, para.length);
        chunks.push(para.slice(start, end));
        start = end - CHUNK_OVERLAP;
        if (start <= 0 || end === para.length) break;
      }
      current = '';
    }
  }
  if (current) chunks.push(current);

  return chunks.filter((c) => c.trim().length > 20); // discard trivially short scraps
}

/**
 * Calls the real Gemini embedding API for one piece of text.
 * Returns a Float32Array of length EMBEDDING_DIM.
 */
async function embedText(text, taskType = 'RETRIEVAL_DOCUMENT') {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error('GEMINI_API_KEY is not set in backend/.env');

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${EMBEDDING_MODEL}:embedContent`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        model: `models/${EMBEDDING_MODEL}`,
        content: { parts: [{ text }] },
        taskType, // RETRIEVAL_DOCUMENT for corpus chunks, RETRIEVAL_QUERY for the search query
        outputDimensionality: EMBEDDING_DIM,
      }),
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Gemini embedding API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const values = data.embedding?.values;
  if (!values) throw new Error('Gemini embedding response missing values');
  return new Float32Array(values);
}

/**
 * Embeds many chunks sequentially. Sequential (not parallel) on purpose —
 * the free tier's requests-per-minute limit is easy to blow through with
 * a burst of parallel calls during a big ingestion.
 */
async function embedBatch(texts, taskType = 'RETRIEVAL_DOCUMENT') {
  const vectors = [];
  for (const text of texts) {
    vectors.push(await embedText(text, taskType));
  }
  return vectors;
}

module.exports = { chunkText, embedText, embedBatch, EMBEDDING_DIM, EMBEDDING_MODEL };
