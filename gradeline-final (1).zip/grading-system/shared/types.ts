/**
 * SHARED DATA CONTRACTS
 * ----------------------------------------------------------------
 * These are the shapes that flow between every chunk of the system.
 * Backend and frontend should both conform to these. As we build
 * chunks 3, 4, 5... later, they plug into these same interfaces —
 * that's what makes integration additive instead of a rewrite.
 *
 * This file is not imported by JS code directly (backend is plain
 * JS for simplicity) — it's the contract we build both sides against.
 * Copy the relevant shape into JSDoc comments or a real TS setup
 * later if you want compile-time checking.
 */

// ---------- Chunk 2: Auth ----------

export type Role = 'admin' | 'faculty';

export interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface AuthResponse {
  token: string; // JWT, sent as "Authorization: Bearer <token>"
  user: User;
}

// ---------- Chunk 3: Upload / Setup ----------

export interface Assessment {
  id: string;
  title: string;
  createdBy: number; // User.id
  questions: RubricItem[];
  createdAt: string;
}

export interface RubricItem {
  questionNumber: string; // "Q1", "Q2a", etc.
  questionText: string;
  maxMarks: number;
  criteria: RubricCriterion[];
}

export interface RubricCriterion {
  id: string;
  description: string;
  marks: number;
}

export interface AnswerSheetUpload {
  id: string;
  assessmentId: string;
  studentIdentifier: string; // roll number / name, however you tag sheets
  fileName: string;
  uploadedAt: string;
  status: 'uploaded' | 'processing' | 'processed' | 'failed';
}

// ---------- Chunk 4: OCR / Segmentation output ----------

export interface StructuredAnswer {
  answerSheetId: string;
  questionNumber: string;
  answerText: string;
  confidence: number; // OCR confidence, 0-1
}

// ---------- Chunk 5: AI Grading Agent ----------

export interface EvidenceSnippet {
  source: string; // e.g. "Lecture 4 slides.pptx"
  excerpt: string;
  relevanceScore: number;
}

export interface CriterionResult {
  criterionId: string;
  marksAwarded: number;
  maxMarks: number;
  justification: string;
}

export interface GradingResult {
  answerSheetId: string;
  questionNumber: string;
  studentIdentifier: string;
  questionText: string;
  answerText: string;
  marksAwarded: number;
  maxMarks: number;
  criterionResults: CriterionResult[];
  explanation: string;
  evidence: EvidenceSnippet[];
  confidenceScore: number; // 0-1, model's confidence in this grade
  reviewStatus: 'auto_approved' | 'pending_review' | 'reviewed';
}

// ---------- Chunk 6: Human Review ----------

export interface ReviewDecision {
  gradingResultId: string;
  reviewerId: number; // User.id (faculty/admin)
  finalMarksAwarded: number;
  reviewerNotes: string;
  decidedAt: string;
}
