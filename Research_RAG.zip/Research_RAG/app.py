"""
app.py
======
Streamlit UI for the Research RAG Pipeline.

Two main flows:
1. INGEST TAB: Search arXiv → Download PDFs → Process → Embed → Index
2. QUERY TAB: Ask a research question → Retrieve → Rerank → Generate answer

Uses Streamlit session_state to persist the pipeline across rerenders
(avoids reloading models on every interaction).
"""

import streamlit as st
import sys
import os
from pathlib import Path

# Add src/ to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

# ─── Page config (must be first Streamlit call) ────────────────────────────
st.set_page_config(
    page_title="Research RAG",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Custom CSS ─────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Main background and text */
    .stApp { background-color: #0f1117; color: #e0e0e0; }
    
    /* Citation card styling */
    .citation-card {
        background: #1e2130;
        border-left: 3px solid #4f8ef7;
        border-radius: 4px;
        padding: 12px 16px;
        margin: 8px 0;
        font-size: 0.85em;
    }
    .citation-number {
        color: #4f8ef7;
        font-weight: 700;
        font-size: 1.1em;
    }
    .paper-title {
        color: #b0c4f5;
        font-weight: 600;
    }
    
    /* Answer box */
    .answer-box {
        background: #161b27;
        border: 1px solid #2d3348;
        border-radius: 8px;
        padding: 20px;
        margin: 12px 0;
        line-height: 1.7;
    }
    
    /* Stats pill */
    .stat-pill {
        display: inline-block;
        background: #1e3a5f;
        color: #7eb8f7;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.85em;
        margin: 4px;
    }

    /* Section headers */
    .section-header {
        color: #7eb8f7;
        font-size: 1.1em;
        font-weight: 600;
        margin-bottom: 8px;
        border-bottom: 1px solid #2d3348;
        padding-bottom: 4px;
    }
</style>
""", unsafe_allow_html=True)


# ─── Pipeline initialization (cached across rerenders) ──────────────────────
@st.cache_resource(show_spinner="Loading AI models (first run may take a few minutes)...")
def load_pipeline(embedding_model: str, llm_backend: str):
    """
    Initialize the pipeline once and cache it in Streamlit's resource cache.
    This prevents reloading heavy models (BGE, cross-encoder) on every interaction.
    """
    from pipeline import ResearchRAGPipeline
    return ResearchRAGPipeline(
        embedding_model=embedding_model,
        llm_backend=llm_backend,
        data_dir="data"
    )


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuration")
    st.markdown("---")

    embedding_model = st.selectbox(
        "Embedding Model",
        options=[
            "BAAI/bge-base-en-v1.5",
            "BAAI/bge-large-en-v1.5",
            "intfloat/e5-base-v2",
            "sentence-transformers/all-MiniLM-L6-v2",
        ],
        index=0,
        help="BGE-base is the best quality/speed tradeoff. BGE-large is higher quality but slower."
    )

    llm_backend = st.selectbox(
        "LLM Backend",
        options=["auto", "ollama", "openai", "anthropic"],
        index=0,
        help="'auto' tries Ollama first, then OpenAI, then Anthropic"
    )

    st.markdown("---")
    st.markdown("### 🔑 API Keys (optional)")
    openai_key = st.text_input("OpenAI API Key", type="password", placeholder="sk-...")
    anthropic_key = st.text_input("Anthropic API Key", type="password", placeholder="sk-ant-...")

    if openai_key:
        os.environ["OPENAI_API_KEY"] = openai_key
    if anthropic_key:
        os.environ["ANTHROPIC_API_KEY"] = anthropic_key

    st.markdown("---")
    st.markdown("### 💡 Quick Start")
    st.markdown("""
    1. Go to **Ingest Papers** tab
    2. Enter a research topic (e.g., *"attention mechanism transformers"*)
    3. Click **Fetch & Index Papers**
    4. Go to **Ask a Question** tab
    5. Type your research question!
    """)
    st.markdown("---")
    st.caption("For local LLMs: Install [Ollama](https://ollama.ai) and run `ollama pull mistral`")


# ─── Load pipeline ───────────────────────────────────────────────────────────
try:
    pipeline = load_pipeline(embedding_model, llm_backend)
except Exception as e:
    st.error(f"Failed to initialize pipeline: {e}")
    st.stop()


# ─── Header ──────────────────────────────────────────────────────────────────
st.markdown("# 🔬 Research RAG")
st.markdown("*Chat with academic papers — arXiv-powered, citation-grounded*")

# Stats bar
stats = pipeline.get_stats()
col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Papers Indexed", stats.get("papers", 0))
with col2:
    st.metric("Total Chunks", stats.get("total_chunks", 0))
with col3:
    st.metric("Year Range", stats.get("year_range", "N/A"))

st.markdown("---")


# ─── Tabs ────────────────────────────────────────────────────────────────────
tab_ingest, tab_query, tab_debug = st.tabs([
    "📥 Ingest Papers",
    "💬 Ask a Question",
    "🔍 Debug / Retrieval"
])


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1: INGEST PAPERS
# ══════════════════════════════════════════════════════════════════════════════
with tab_ingest:
    st.markdown("### Search and index papers from arXiv")
    st.caption("Papers are downloaded as PDFs, parsed, chunked, and embedded into the vector store.")

    col_left, col_right = st.columns([2, 1])

    with col_left:
        search_query = st.text_input(
            "Research Topic / Keywords",
            placeholder="e.g., retrieval augmented generation, attention mechanism, LoRA fine-tuning",
            help="Searches arXiv title+abstract"
        )

    with col_right:
        max_papers = st.slider("Max Papers", 1, 20, 5)

    col1, col2, col3 = st.columns(3)
    with col1:
        category = st.selectbox(
            "arXiv Category (optional)",
            ["All", "cs.AI", "cs.CL", "cs.LG", "cs.CV", "cs.IR", "stat.ML"],
            index=0
        )
        category = None if category == "All" else category

    with col2:
        year_from_ingest = st.number_input("From Year", value=2020, min_value=1990, max_value=2026)

    with col3:
        year_to_ingest = st.number_input("To Year", value=2026, min_value=1990, max_value=2026)

    if st.button("🚀 Fetch & Index Papers", type="primary", disabled=not search_query):
        progress_bar = st.progress(0)
        status_text = st.empty()

        def update_progress(pct, msg):
            progress_bar.progress(pct)
            status_text.text(msg)

        with st.spinner(""):
            try:
                results = pipeline.ingest_papers(
                    query=search_query,
                    max_papers=max_papers,
                    category=category,
                    year_from=int(year_from_ingest),
                    year_to=int(year_to_ingest),
                    progress_callback=update_progress
                )

                st.success(
                    f"✅ Indexed {results['processed']} papers "
                    f"({results['chunks_added']} new chunks added)"
                )

                if results["papers"]:
                    st.markdown("#### Indexed Papers:")
                    for paper in results["papers"]:
                        with st.expander(f"📄 {paper['title'][:80]}..."):
                            st.markdown(f"**Authors:** {', '.join(str(a) for a in paper['authors'])}")
                            st.markdown(f"**Year:** {paper['year']}")
                            st.markdown(f"**URL:** [{paper['url']}]({paper['url']})")

            except Exception as e:
                st.error(f"Ingestion failed: {e}")
                st.exception(e)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2: ASK A QUESTION
# ══════════════════════════════════════════════════════════════════════════════
with tab_query:
    if stats.get("total_chunks", 0) == 0:
        st.info("👆 Please ingest some papers first using the **Ingest Papers** tab.")
    else:
        st.markdown("### Ask a research question")

        question = st.text_area(
            "Your Question",
            placeholder="e.g., What are the key differences between RAG and fine-tuning for LLMs?\n"
                        "e.g., How does LoRA reduce training parameters?\n"
                        "e.g., What benchmarks are used to evaluate retrieval systems?",
            height=100
        )

        col1, col2, col3 = st.columns(3)
        with col1:
            year_from_q = st.number_input("From Year", value=2020, min_value=1990, max_value=2026, key="qyf")
        with col2:
            year_to_q = st.number_input("To Year", value=2026, min_value=1990, max_value=2026, key="qyt")
        with col3:
            author_filter = st.text_input("Author Filter (optional)", placeholder="e.g., Vaswani")

        top_k = st.slider("Chunks to retrieve", 3, 10, 5, key="topk")

        if st.button("🔍 Search & Answer", type="primary", disabled=not question):
            with st.spinner("Retrieving relevant passages and generating answer..."):
                try:
                    response = pipeline.query(
                        question=question,
                        year_from=int(year_from_q) if year_from_q else None,
                        year_to=int(year_to_q) if year_to_q else None,
                        author=author_filter if author_filter else None,
                        top_k=top_k,
                    )

                    # ── Answer ──────────────────────────────────────────────
                    st.markdown("### 🤖 Answer")
                    st.markdown(
                        f'<div class="answer-box">{response.answer}</div>',
                        unsafe_allow_html=True
                    )
                    st.caption(f"*Generated by: {response.model_used}*")

                    # ── Citations ─────────────────────────────────────────
                    if response.citations:
                        st.markdown("### 📚 Sources Cited")
                        for citation in response.citations:
                            st.markdown(
                                f'<div class="citation-card">'
                                f'<span class="citation-number">[{citation.number}]</span> '
                                f'<span class="paper-title">{citation.title}</span><br>'
                                f'<small>{citation.authors} · {citation.year}</small><br>'
                                f'<a href="{citation.url}" target="_blank">🔗 View on arXiv</a>'
                                f'</div>',
                                unsafe_allow_html=True
                            )

                except Exception as e:
                    st.error(f"Query failed: {e}")
                    st.exception(e)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3: DEBUG / RETRIEVAL INSPECTOR
# ══════════════════════════════════════════════════════════════════════════════
with tab_debug:
    st.markdown("### 🔍 Retrieval Inspector")
    st.caption("Inspect what chunks are retrieved for a query — useful for debugging retrieval quality.")

    debug_query = st.text_input("Test Query", placeholder="Type a query to inspect raw retrieval...")

    if st.button("Inspect Retrieval", disabled=not debug_query):
        with st.spinner("Running retrieval..."):
            try:
                retrieved = pipeline.retriever.retrieve(
                    query=debug_query,
                    top_k=10,
                )

                st.markdown(f"**{len(retrieved)} chunks retrieved:**")
                for i, chunk in enumerate(retrieved, 1):
                    meta = chunk["metadata"]
                    with st.expander(
                        f"[{i}] {meta['title'][:60]}... (score: {chunk.get('rerank_score', 0):.3f})"
                    ):
                        col1, col2 = st.columns(2)
                        with col1:
                            st.markdown(f"**Paper:** {meta['title']}")
                            st.markdown(f"**Authors:** {meta['authors']}")
                            st.markdown(f"**Year:** {meta['year']}")
                            st.markdown(f"**Section:** {meta.get('section', 'N/A')}")
                            st.markdown(f"**Page:** {meta.get('page_number', 'N/A')}")
                        with col2:
                            st.markdown(f"**Rerank Score:** `{chunk.get('rerank_score', 'N/A')}`")
                            st.markdown(f"**RRF Score:** `{chunk.get('rrf_score', 'N/A'):.4f}`")
                        st.markdown("**Chunk Text:**")
                        st.text(chunk["text"][:600] + "...")

            except Exception as e:
                st.error(f"Retrieval inspection failed: {e}")
