"""
agent.py
========
LLM Agent that synthesizes retrieved chunks into citation-grounded responses.

Supports multiple LLM backends:
1. Ollama (local): Mistral 7B, Llama 3, Gemma — fully offline, free
2. OpenAI: GPT-3.5/4 — best quality, requires API key
3. Anthropic Claude: claude-3-haiku/sonnet — high quality

The CITATION GROUNDING mechanism:
- Each retrieved chunk is numbered [1], [2], [3], ...
- The prompt instructs the LLM to cite by number in its response
- We parse citations from the response and attach source metadata
- This prevents hallucination and makes the response verifiable
"""

import os
import re
import json
from typing import List, Optional, Dict, Any
from loguru import logger
from dataclasses import dataclass


@dataclass
class Citation:
    """A single citation extracted from the LLM response."""
    number: int
    title: str
    authors: str
    year: int
    url: str
    excerpt: str   # The chunk text that was cited


@dataclass
class AgentResponse:
    """Full structured response from the LLM agent."""
    answer: str
    citations: List[Citation]
    raw_context: List[dict]   # The retrieved chunks passed to the LLM
    query: str
    model_used: str


def build_context_prompt(retrieved_chunks: List[dict]) -> str:
    """
    Format retrieved chunks as numbered context for the LLM.
    
    Each chunk gets:
    - A number for citation reference [1], [2], ...
    - The source paper metadata (title, authors, year)
    - The chunk text itself
    
    This format lets the LLM easily cite specific sources.
    """
    context_parts = []
    for i, chunk in enumerate(retrieved_chunks, 1):
        meta = chunk["metadata"]
        context_parts.append(
            f"[{i}] SOURCE: {meta['title']}\n"
            f"    Authors: {meta['authors']} ({meta['year']})\n"
            f"    Section: {meta.get('section', 'N/A')}\n"
            f"    URL: {meta['source_url']}\n"
            f"    TEXT: {chunk['text']}\n"
        )
    return "\n---\n".join(context_parts)


def build_system_prompt() -> str:
    """System prompt that instructs the LLM to give citation-grounded responses."""
    return """You are an expert AI research assistant specializing in synthesizing information from academic papers.

Your task is to answer research questions using ONLY the provided source context.

CITATION RULES (strictly follow):
1. Every factual claim MUST be cited using [number] notation matching the source list
2. Cite the specific source number immediately after the claim: "...transformer attention [1]."
3. If multiple sources support a claim, cite all: "...shown to improve performance [1][3]."
4. Never make claims not supported by the provided sources
5. If the sources don't contain enough information, say so clearly

RESPONSE FORMAT:
- Write in clear, academic but accessible language
- Structure: Brief direct answer → Detailed explanation with citations → Summary
- Use markdown formatting for readability
- End with a "Sources Used" section listing all cited papers

Remember: Only cite what's actually in the provided context. Accuracy over completeness."""


def extract_citations(
    response_text: str,
    retrieved_chunks: List[dict]
) -> List[Citation]:
    """
    Parse [N] citation markers from the LLM response and
    attach source metadata to create Citation objects.
    """
    # Find all unique citation numbers in the response
    cited_numbers = set(
        int(n) for n in re.findall(r"\[(\d+)\]", response_text)
    )

    citations = []
    for num in sorted(cited_numbers):
        idx = num - 1  # Convert 1-indexed to 0-indexed
        if 0 <= idx < len(retrieved_chunks):
            chunk = retrieved_chunks[idx]
            meta = chunk["metadata"]
            citations.append(Citation(
                number=num,
                title=meta["title"],
                authors=meta["authors"],
                year=meta["year"],
                url=meta["source_url"],
                excerpt=chunk["text"][:300] + "..."  # First 300 chars
            ))

    return citations


class ResearchAgent:
    """
    LLM-powered research agent with citation grounding.
    Automatically selects backend based on available API keys.
    """

    def __init__(
        self,
        backend: str = "auto",   # "ollama", "openai", "anthropic", "auto"
        model: str = None,
        ollama_base_url: str = "http://localhost:11434",
        temperature: float = 0.1,   # Low temp for factual accuracy
    ):
        self.temperature = temperature
        self.ollama_base_url = ollama_base_url
        self.backend, self.model = self._setup_backend(backend, model)
        logger.info(f"Agent initialized: {self.backend} / {self.model}")

    def _setup_backend(self, backend: str, model: Optional[str]) -> tuple:
        """Auto-detect the best available LLM backend."""
        
        if backend == "auto":
            # Priority: Ollama (free, local) → OpenAI → Anthropic
            if self._check_ollama():
                return "ollama", model or "llama3:latest"
            elif os.getenv("OPENAI_API_KEY"):
                return "openai", model or "gpt-3.5-turbo"
            elif os.getenv("ANTHROPIC_API_KEY"):
                return "anthropic", model or "claude-haiku-4-5"
            else:
                logger.warning("No LLM backend found. Set OPENAI_API_KEY or run Ollama.")
                return "mock", "mock"

        return backend, model or self._default_model(backend)

    def _default_model(self, backend: str) -> str:
        defaults = {
            "ollama": "llama3:latest",
            "openai": "gpt-3.5-turbo",
            "anthropic": "claude-haiku-4-5",
        }
        return defaults.get(backend, "llama3:latest")

    def _check_ollama(self) -> bool:
        """Check if Ollama is running locally."""
        try:
            import requests
            r = requests.get(f"{self.ollama_base_url}/api/tags", timeout=2)
            return r.status_code == 200
        except Exception:
            return False

    def _call_ollama(self, messages: List[dict]) -> str:
        """Call local Ollama API."""
        import requests

        # Convert messages to Ollama format
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": self.temperature}
        }

        response = requests.post(
            f"{self.ollama_base_url}/api/chat",
            json=payload,
            timeout=120
        )
        response.raise_for_status()
        return response.json()["message"]["content"]

    def _call_openai(self, messages: List[dict]) -> str:
        """Call OpenAI API."""
        from openai import OpenAI
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=2000
        )
        return response.choices[0].message.content

    def _call_anthropic(self, messages: List[dict]) -> str:
        """Call Anthropic API."""
        import anthropic
        client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

        # Separate system from user messages
        system = next((m["content"] for m in messages if m["role"] == "system"), "")
        user_messages = [m for m in messages if m["role"] != "system"]

        response = client.messages.create(
            model=self.model,
            max_tokens=2000,
            system=system,
            messages=user_messages,
            temperature=self.temperature
        )
        return response.content[0].text

    def _call_mock(self, query: str, chunks: List[dict]) -> str:
        """Mock response when no LLM backend is available (for testing)."""
        return (
            f"[MOCK RESPONSE - No LLM backend configured]\n\n"
            f"Query: {query}\n\n"
            f"I found {len(chunks)} relevant chunks. "
            f"To get real responses, please:\n"
            f"1. Run Ollama locally: `ollama serve` then `ollama pull mistral`\n"
            f"2. Or set OPENAI_API_KEY environment variable\n"
            f"3. Or set ANTHROPIC_API_KEY environment variable\n\n"
            f"Retrieved sources: " + 
            ", ".join(set(c["metadata"]["title"][:50] for c in chunks[:3]))
        )

    def generate(
        self,
        query: str,
        retrieved_chunks: List[dict],
    ) -> AgentResponse:
        """
        Generate a citation-grounded response from retrieved chunks.
        
        Args:
            query: The user's original research question
            retrieved_chunks: Chunks from the retriever (with text + metadata)
        
        Returns:
            AgentResponse with answer text + parsed citations
        """
        if not retrieved_chunks:
            return AgentResponse(
                answer="I couldn't find relevant papers for your query. "
                       "Try fetching papers first or broadening your search.",
                citations=[],
                raw_context=[],
                query=query,
                model_used=self.model
            )

        # Build the context from retrieved chunks
        context = build_context_prompt(retrieved_chunks)

        # Build messages for the LLM
        user_message = (
            f"Research Question: {query}\n\n"
            f"SOURCE CONTEXT:\n{context}\n\n"
            f"Please provide a comprehensive, citation-grounded answer to the research question "
            f"using the sources above. Remember to cite each claim with [N] notation."
        )

        messages = [
            {"role": "system", "content": build_system_prompt()},
            {"role": "user", "content": user_message}
        ]

        # Call the appropriate backend
        logger.info(f"Calling {self.backend}/{self.model}...")
        try:
            if self.backend == "ollama":
                answer = self._call_ollama(messages)
            elif self.backend == "openai":
                answer = self._call_openai(messages)
            elif self.backend == "anthropic":
                answer = self._call_anthropic(messages)
            else:
                answer = self._call_mock(query, retrieved_chunks)
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            answer = f"Error generating response: {str(e)}\n\n" + self._call_mock(query, retrieved_chunks)

        # Extract citations from the response
        citations = extract_citations(answer, retrieved_chunks)

        return AgentResponse(
            answer=answer,
            citations=citations,
            raw_context=retrieved_chunks,
            query=query,
            model_used=f"{self.backend}/{self.model}"
        )
