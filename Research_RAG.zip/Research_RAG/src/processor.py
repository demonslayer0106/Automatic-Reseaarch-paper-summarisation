"""
processor.py
============
PDF parsing → text cleaning → semantic chunking → metadata extraction.

Key design choices:
- Uses PyMuPDF (fitz) for robust PDF text extraction
- Semantic chunking: splits on paragraph boundaries, not arbitrary token counts
- Each chunk carries full paper metadata for citation generation
"""

import fitz  # PyMuPDF
import re
import nltk
from pathlib import Path
from loguru import logger
from dataclasses import dataclass, field
from typing import List, Optional

from fetcher import Paper

# Download NLTK sentence tokenizer if not present
try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt", quiet=True)


@dataclass
class DocumentChunk:
    """
    A single chunk of text from a paper, with full metadata attached.
    This is the unit stored in the vector database.
    """
    chunk_id: str           # Unique ID: "{paper_id}_chunk_{n}"
    text: str               # The actual chunk text
    paper_id: str
    title: str
    authors: List[str]
    year: int
    abstract: str
    source_url: str
    page_number: int        # Which PDF page this came from
    chunk_index: int        # Position of chunk within paper
    section: Optional[str] = None   # e.g., "Introduction", "Methods"
    keywords: List[str] = field(default_factory=list)


class PDFProcessor:
    """
    Processes downloaded PDFs into DocumentChunks ready for embedding.
    
    Pipeline:
    1. Extract text from each page using PyMuPDF
    2. Clean text (remove artifacts, normalize whitespace)
    3. Detect section headers
    4. Chunk text semantically (paragraph-aware)
    5. Attach metadata to each chunk
    """

    def __init__(
        self,
        chunk_size: int = 512,      # Target tokens per chunk
        chunk_overlap: int = 64,    # Overlap between chunks (context continuity)
        min_chunk_length: int = 100 # Skip very short chunks (headers, page nums)
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.min_chunk_length = min_chunk_length

        # Common section headers in academic papers
        self.section_patterns = re.compile(
            r"^(abstract|introduction|related work|background|methodology|"
            r"method|approach|experiments?|results?|discussion|conclusion|"
            r"references?|acknowledgments?|appendix)",
            re.IGNORECASE | re.MULTILINE
        )

    def extract_text_from_pdf(self, pdf_path: str) -> List[dict]:
        """
        Extract raw text from PDF using PyMuPDF.
        
        Returns list of {page_num, text} dicts.
        PyMuPDF preserves reading order better than pdfplumber for multi-column papers.
        """
        pages = []
        try:
            doc = fitz.open(pdf_path)
            for page_num, page in enumerate(doc):
                text = page.get_text("text")  # "text" mode preserves layout
                if text.strip():
                    pages.append({
                        "page_num": page_num + 1,
                        "text": text
                    })
            doc.close()
            logger.debug(f"Extracted {len(pages)} pages from {pdf_path}")
        except Exception as e:
            logger.error(f"PDF extraction failed for {pdf_path}: {e}")
        return pages

    def clean_text(self, text: str) -> str:
        """
        Clean extracted PDF text.
        
        Common PDF artifacts we fix:
        - Hyphenated line breaks ("computa-\ntion" → "computation")
        - Multiple whitespace/newlines
        - Page numbers, headers/footers
        - LaTeX remnants (\\begin, \\end, etc.)
        """
        # Fix hyphenated word breaks
        text = re.sub(r"(\w+)-\n(\w+)", r"\1\2", text)

        # Collapse multiple newlines (keep paragraph breaks as double newline)
        text = re.sub(r"\n{3,}", "\n\n", text)

        # Remove common PDF page number patterns
        text = re.sub(r"\n\d+\n", "\n", text)

        # Remove LaTeX-style commands
        text = re.sub(r"\\[a-zA-Z]+\{[^}]*\}", "", text)
        text = re.sub(r"\$[^$]+\$", "[MATH]", text)  # Inline math

        # Normalize whitespace within lines
        text = re.sub(r"[ \t]+", " ", text)

        # Remove lines that are just numbers or very short (likely page artifacts)
        lines = [l for l in text.split("\n") if len(l.strip()) > 3]
        text = "\n".join(lines)

        return text.strip()

    def detect_section(self, text: str) -> Optional[str]:
        """Detect if a text block starts a new section."""
        first_line = text.strip().split("\n")[0].strip()
        match = self.section_patterns.match(first_line)
        if match:
            return match.group(0).title()
        return None

    def semantic_chunk(self, text: str, page_num: int) -> List[dict]:
        """
        Split text into semantic chunks.
        
        Strategy:
        1. Split on paragraph boundaries (double newlines) first
        2. If a paragraph is too long, split by sentences
        3. Merge short paragraphs with the next one to meet min chunk size
        4. Add overlap by prepending last N words from previous chunk
        
        This preserves semantic coherence better than sliding window.
        """
        # Split into paragraphs
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]

        chunks = []
        current_chunk = ""
        current_section = None

        for para in paragraphs:
            # Check if paragraph is a section header
            section = self.detect_section(para)
            if section:
                current_section = section

            # Estimate word count (rough token proxy: 1 token ≈ 0.75 words)
            word_count = len(current_chunk.split()) + len(para.split())

            if word_count > self.chunk_size * 0.75:
                # Current chunk is large enough — save it
                if len(current_chunk) >= self.min_chunk_length:
                    chunks.append({
                        "text": current_chunk.strip(),
                        "page_num": page_num,
                        "section": current_section
                    })

                # Start new chunk with overlap from the end of previous
                if current_chunk:
                    # Take last `overlap` words from previous chunk
                    prev_words = current_chunk.split()
                    overlap_text = " ".join(prev_words[-self.chunk_overlap:])
                    current_chunk = overlap_text + " " + para
                else:
                    current_chunk = para
            else:
                # Accumulate paragraphs
                current_chunk = (current_chunk + "\n\n" + para).strip()

        # Don't forget the last chunk
        if current_chunk and len(current_chunk) >= self.min_chunk_length:
            chunks.append({
                "text": current_chunk.strip(),
                "page_num": page_num,
                "section": current_section
            })

        return chunks

    def process_paper(self, paper: Paper) -> List[DocumentChunk]:
        """
        Full processing pipeline for a single paper.
        Returns a list of DocumentChunks ready for embedding.
        """
        if not paper.local_pdf_path:
            logger.warning(f"No local PDF for {paper.paper_id}")
            return []

        logger.info(f"Processing: {paper.title[:60]}...")

        # Step 1: Extract text from PDF
        pages = self.extract_text_from_pdf(paper.local_pdf_path)
        if not pages:
            return []

        # Step 2: Clean and chunk each page
        all_chunks = []
        for page_data in pages:
            clean_text = self.clean_text(page_data["text"])
            raw_chunks = self.semantic_chunk(clean_text, page_data["page_num"])
            all_chunks.extend(raw_chunks)

        # Step 3: Convert to DocumentChunk objects with metadata
        document_chunks = []
        for idx, chunk_data in enumerate(all_chunks):
            chunk = DocumentChunk(
                chunk_id=f"{paper.paper_id}_chunk_{idx}",
                text=chunk_data["text"],
                paper_id=paper.paper_id,
                title=paper.title,
                authors=paper.authors,
                year=paper.year,
                abstract=paper.abstract,
                source_url=paper.url,
                page_number=chunk_data["page_num"],
                chunk_index=idx,
                section=chunk_data.get("section"),
                keywords=paper.keywords,
            )
            document_chunks.append(chunk)

        logger.info(f"Created {len(document_chunks)} chunks from '{paper.title[:50]}'")
        return document_chunks

    def process_papers(self, papers: List[Paper]) -> List[DocumentChunk]:
        """Process multiple papers and return all chunks."""
        all_chunks = []
        for paper in papers:
            chunks = self.process_paper(paper)
            all_chunks.extend(chunks)
        logger.info(f"Total chunks created: {len(all_chunks)}")
        return all_chunks
