"""
agentic_pipeline.py
===================
Upgraded pipeline orchestrator that wraps both:
1. Simple one-shot RAG (fast, for simple queries)
2. ReAct agentic loop (thorough, for complex multi-hop queries)

The Streamlit UI calls this instead of pipeline.py.
"""

from loguru import logger
from typing import List, Optional, Callable

from fetcher import ArxivFetcher
from processor import PDFProcessor
from embedder import EmbeddingStore
from retriever import HybridRetriever
from agent import ResearchAgent, AgentResponse, Citation
from react_agent import ReactAgent
from tools import build_tool_registry


class AgenticRAGPipeline:
    """
    Full agentic RAG pipeline with ReAct loop.
    
    Simple queries → one-shot RAG (fast)
    Complex queries → ReAct agent (thorough, multi-hop)
    """

    def __init__(
        self,
        embedding_model: str = "BAAI/bge-base-en-v1.5",
        llm_backend: str = "auto",
        llm_model: Optional[str] = None,
        data_dir: str = "data",
    ):
        logger.info("Initializing Agentic RAG Pipeline...")

        # Core components (same as before)
        self.fetcher = ArxivFetcher(download_dir=f"{data_dir}/pdfs")
        self.processor = PDFProcessor(chunk_size=512, chunk_overlap=64)
        self.embedding_store = EmbeddingStore(
            model_name=embedding_model,
            persist_dir=f"{data_dir}/chromadb"
        )
        self.retriever = HybridRetriever(
            embedding_store=self.embedding_store,
            top_k_candidates=20,
            top_k_final=5,
        )

        # One-shot agent (for simple queries)
        self.simple_agent = ResearchAgent(backend=llm_backend, model=llm_model)

        # Build tool registry (wires tools to pipeline components)
        self.tool_registry = build_tool_registry(
            fetcher=self.fetcher,
            embedding_store=self.embedding_store,
            retriever=self.retriever,
            processor=self.processor
        )

        # ReAct agent (for complex queries)
        self.react_agent = ReactAgent(
            tool_registry=self.tool_registry,
            llm_backend=self.simple_agent.backend,
            llm_model=self.simple_agent.model,
            max_iterations=6,
            confidence_threshold=0.75,
        )

        logger.info("Agentic pipeline ready!")

    def ingest_papers(
        self,
        query: str,
        max_papers: int = 5,
        category: Optional[str] = None,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        progress_callback=None,
    ) -> dict:
        """Fetch → process → embed papers. Same as before."""
        results = {"fetched": 0, "processed": 0, "chunks_added": 0, "papers": []}

        if progress_callback:
            progress_callback(0.1, "Searching arXiv...")

        papers = self.fetcher.search(query, max_papers, category=category,
                                     year_from=year_from, year_to=year_to)
        results["fetched"] = len(papers)

        if not papers:
            return results

        if progress_callback:
            progress_callback(0.3, f"Downloading {len(papers)} PDFs...")

        downloaded = [self.fetcher.download_pdf(p) for p in papers]
        downloaded = [p for p in downloaded if p.local_pdf_path]

        if progress_callback:
            progress_callback(0.55, "Processing PDFs...")

        chunks = self.processor.process_papers(downloaded)
        results["processed"] = len(downloaded)

        if progress_callback:
            progress_callback(0.75, "Embedding and indexing...")

        added = self.embedding_store.add_chunks(chunks)
        results["chunks_added"] = added

        if progress_callback:
            progress_callback(0.9, "Updating search indexes...")

        self.retriever.rebuild_index()
        results["papers"] = [
            {"title": p.title, "authors": p.authors[:2], "year": p.year, "url": p.url}
            for p in downloaded
        ]

        if progress_callback:
            progress_callback(1.0, "Done!")

        return results

    def query_simple(
        self,
        question: str,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
        top_k: int = 5,
    ) -> AgentResponse:
        """One-shot RAG — fast, no looping."""
        retrieved = self.retriever.retrieve(
            query=question, year_from=year_from, year_to=year_to,
            author=author, top_k=top_k
        )
        return self.simple_agent.generate(query=question, retrieved_chunks=retrieved)

    def query_agentic(
        self,
        question: str,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
        stream_callback: Optional[Callable] = None,
    ) -> dict:
        """
        Full ReAct agent loop — multi-hop, self-evaluating, tool-using.
        Returns a dict with answer, citations, trace, steps, confidence.
        """
        return self.react_agent.run(
            query=question,
            year_from=year_from,
            year_to=year_to,
            author=author,
            stream_callback=stream_callback,
        )

    def get_stats(self) -> dict:
        return self.embedding_store.get_stats()
