"""
react_agent.py
==============
The ReAct (Reason + Act) agent loop.

This is what makes the system truly AGENTIC vs the one-shot RAG pipeline:

ONE-SHOT RAG:
  query → retrieve once → generate answer

REACT AGENT:
  query
    → Think: what do I need to know?
    → Act: call a tool
    → Observe: what did I learn?
    → Think: is this enough? what's still missing?
    → Act: call another tool (different query / different tool)
    → Observe: ...
    → Self-evaluate: confidence score 0–1
    → If confidence < threshold AND iterations < max: loop
    → Final synthesis: combine ALL observations into answer

The LLM output at each Think step follows a strict JSON format:
{
  "thought": "...",
  "action": "tool_name",
  "action_input": {"param": "value"},
  "confidence": 0.0–1.0,
  "final_answer": null  (or the answer string when done)
}

When the LLM sets final_answer, the loop exits.
"""

import json
import re
import os
from typing import List, Optional, Dict, Any
from loguru import logger

from tools import ToolRegistry, ToolResult
from memory import AgentMemory, AgentStep
from agent import build_context_prompt, build_system_prompt, extract_citations


# ── Confidence threshold: if self-eval score < this, keep iterating ──────────
DEFAULT_CONFIDENCE_THRESHOLD = 0.75
DEFAULT_MAX_ITERATIONS = 6


def build_react_system_prompt(tool_registry: ToolRegistry) -> str:
    """
    System prompt that teaches the LLM the ReAct format.
    Critically includes the tool descriptions and the exact JSON schema to follow.
    """
    tools_desc = tool_registry.describe_all()
    return f"""You are an expert research agent that answers questions about academic papers using a step-by-step reasoning loop.

You have access to these tools:
{tools_desc}

At each step, respond with ONLY a JSON object in this exact format:
{{
  "thought": "Your reasoning about what you know, what you need, and what to do next",
  "action": "tool_name",
  "action_input": {{"param1": "value1", "param2": "value2"}},
  "confidence": 0.65,
  "final_answer": null
}}

When you have sufficient evidence to answer the question confidently (confidence >= 0.75):
{{
  "thought": "I now have enough evidence to give a comprehensive, citation-grounded answer",
  "action": "none",
  "action_input": {{}},
  "confidence": 0.85,
  "final_answer": "Your complete answer here with [N] citations referencing the chunks you've seen"
}}

RULES:
1. Start by calling retrieve_chunks to check what's already indexed
2. Only call search_arxiv if retrieve_chunks returns too few/irrelevant results
3. Never call the same tool with the same query twice — use memory context
4. Build on previous observations — reference what you already know
5. Score confidence honestly: 0 = no evidence, 1 = very strong evidence
6. Citations: when writing final_answer, use [1], [2], [3] referencing the chunk numbers shown to you
7. Output ONLY the JSON — no markdown, no preamble, no explanation outside JSON
"""


def build_react_user_prompt(
    query: str,
    memory: AgentMemory,
    last_observation: Optional[str] = None,
    iteration: int = 1
) -> str:
    """
    The user message sent at each iteration.
    Includes:
    - The original query
    - Current memory state (what's been searched/retrieved)
    - The last observation (what the tool just returned)
    - Numbered chunks accumulated so far (for citation)
    """
    chunks = memory.get_all_chunks_as_context()
    context_str = build_context_prompt(chunks) if chunks else "No chunks retrieved yet."

    memory_str = memory.get_context_summary()

    prompt_parts = [
        f"Research question: {query}",
        f"\nIteration: {iteration} of {DEFAULT_MAX_ITERATIONS}",
        f"\n--- MEMORY ---\n{memory_str}",
    ]

    if last_observation:
        prompt_parts.append(f"\n--- LAST OBSERVATION ---\n{last_observation}")

    if chunks:
        prompt_parts.append(f"\n--- ACCUMULATED EVIDENCE ({len(chunks)} chunks) ---\n{context_str}")

    prompt_parts.append("\nNow respond with your JSON thought/action/observation:")
    return "\n".join(prompt_parts)


def parse_llm_json(text: str) -> Optional[Dict]:
    """
    Robustly parse JSON from LLM output.
    LLMs sometimes wrap JSON in markdown fences or add trailing text.
    """
    # Strip markdown code blocks
    text = re.sub(r"```(?:json)?\s*", "", text).strip()
    text = text.rstrip("`").strip()

    # Try direct parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to extract JSON object with regex
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass

    logger.warning(f"Could not parse LLM output as JSON: {text[:200]}")
    return None


class ReactAgent:
    """
    ReAct agent with tool use, memory, and self-evaluation loop.
    
    This replaces the simple one-shot agent.py for complex queries.
    Falls back gracefully to the one-shot approach on simple queries.
    """

    def __init__(
        self,
        tool_registry: ToolRegistry,
        llm_backend: str = "auto",
        llm_model: Optional[str] = None,
        max_iterations: int = DEFAULT_MAX_ITERATIONS,
        confidence_threshold: float = DEFAULT_CONFIDENCE_THRESHOLD,
        ollama_base_url: str = "http://localhost:11434",
        temperature: float = 0.1,
    ):
        self.tools = tool_registry
        self.max_iterations = max_iterations
        self.confidence_threshold = confidence_threshold
        self.temperature = temperature
        self.ollama_base_url = ollama_base_url

        # Reuse backend detection from agent.py
        from agent import ResearchAgent
        _agent = ResearchAgent(backend=llm_backend, model=llm_model)
        self.backend = _agent.backend
        self.model = _agent.model
        self._call_llm_messages = _agent._call_ollama if self.backend == "ollama" else (
            _agent._call_openai if self.backend == "openai" else
            _agent._call_anthropic if self.backend == "anthropic" else
            None
        )
        logger.info(f"ReAct agent: {self.backend}/{self.model}")

    def _call_llm(self, messages: List[dict]) -> str:
        """Call the configured LLM backend."""
        if self._call_llm_messages is None:
            # Mock response for testing
            return json.dumps({
                "thought": "No LLM backend available. Please configure Ollama or an API key.",
                "action": "retrieve_chunks",
                "action_input": {"query": "research papers"},
                "confidence": 0.1,
                "final_answer": None
            })
        try:
            return self._call_llm_messages(messages)
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            return json.dumps({
                "thought": f"LLM error: {e}",
                "action": "none",
                "action_input": {},
                "confidence": 0.5,
                "final_answer": f"I encountered an LLM error: {e}. Based on retrieved context, I'll provide a partial answer."
            })

    def run(
        self,
        query: str,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
        stream_callback=None,  # Optional: called with each step for live UI updates
    ) -> Dict[str, Any]:
        """
        Run the full ReAct loop for a query.
        
        Returns:
        {
            "answer": str,           # Final citation-grounded answer
            "citations": List,       # Parsed citations
            "trace": str,            # Full reasoning trace
            "steps": int,            # How many iterations ran
            "confidence": float,     # Final confidence score
            "memory": AgentMemory,   # Full memory object (for UI)
        }
        """
        memory = AgentMemory()
        memory.query = query
        memory.sub_queries = self._decompose_query(query)

        system_prompt = build_react_system_prompt(self.tools)
        last_observation = None
        final_answer = None

        logger.info(f"Starting ReAct loop for: '{query}'")
        logger.info(f"Sub-queries: {memory.sub_queries}")

        for iteration in range(1, self.max_iterations + 1):
            logger.info(f"── Iteration {iteration}/{self.max_iterations} ──")

            if stream_callback:
                stream_callback("thinking", iteration, None)

            # Build messages for this iteration
            user_msg = build_react_user_prompt(
                query=query,
                memory=memory,
                last_observation=last_observation,
                iteration=iteration
            )

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_msg}
            ]

            # Call LLM for Think step
            raw_response = self._call_llm(messages)
            parsed = parse_llm_json(raw_response)

            if not parsed:
                logger.warning("Failed to parse LLM response, using fallback")
                parsed = {
                    "thought": "Parse error — stopping loop",
                    "action": "none",
                    "action_input": {},
                    "confidence": 0.5,
                    "final_answer": "Unable to parse reasoning. Please try again."
                }

            thought = parsed.get("thought", "")
            action = parsed.get("action", "none")
            action_input = parsed.get("action_input", {})
            confidence = float(parsed.get("confidence", 0.5))
            final_answer_text = parsed.get("final_answer")

            logger.info(f"Thought: {thought[:100]}...")
            logger.info(f"Action: {action}({action_input})")
            logger.info(f"Confidence: {confidence:.2f}")

            # Check for final answer
            if final_answer_text or action == "none":
                if stream_callback:
                    stream_callback("done", iteration, thought)
                final_answer = final_answer_text or "Insufficient evidence found."
                memory.log_step(AgentStep(
                    step_number=iteration,
                    thought=thought,
                    action="final_answer",
                    action_input={},
                    observation="[Agent decided to finalize answer]",
                    confidence=confidence
                ))
                break

            # Execute the tool
            if stream_callback:
                stream_callback("acting", iteration, action)

            # Inject year filters into retrieve_chunks automatically
            if action == "retrieve_chunks":
                if year_from and "year_from" not in action_input:
                    action_input["year_from"] = year_from
                if year_to and "year_to" not in action_input:
                    action_input["year_to"] = year_to

            tool_result: ToolResult = self.tools.call(action, **action_input)
            memory.increment_tool_count(action)

            # Track what was searched
            if action == "search_arxiv":
                memory.add_searched_query(action_input.get("query", ""))

            # Accumulate retrieved chunks
            if action == "retrieve_chunks" and tool_result.success and tool_result.data:
                memory.add_retrieved_chunks(tool_result.data)

            last_observation = tool_result.output

            # Log the full step
            memory.log_step(AgentStep(
                step_number=iteration,
                thought=thought,
                action=action,
                action_input=action_input,
                observation=tool_result.output,
                confidence=confidence
            ))

            if stream_callback:
                stream_callback("observed", iteration, tool_result.output[:200])

            # Self-evaluation: if confidence is high enough, stop early
            if confidence >= self.confidence_threshold and iteration >= 2:
                logger.info(f"Confidence {confidence:.2f} >= {self.confidence_threshold} — generating final answer")

                # One more LLM call to synthesize the final answer
                synthesis_msg = (
                    f"Research question: {query}\n\n"
                    f"You have gathered sufficient evidence. "
                    f"Now write your final comprehensive, citation-grounded answer "
                    f"using the accumulated evidence. Use [N] notation to cite sources.\n\n"
                    f"Accumulated evidence:\n{build_context_prompt(memory.get_all_chunks_as_context())}"
                )

                synthesis_response = self._call_llm([
                    {"role": "system", "content": build_system_prompt()},
                    {"role": "user", "content": synthesis_msg}
                ])

                # The synthesis response is prose (not JSON)
                final_answer = synthesis_response
                break

        # If loop exhausted without final answer, synthesize from what we have
        if not final_answer:
            logger.info("Max iterations reached — synthesizing from accumulated evidence")
            chunks = memory.get_all_chunks_as_context()
            if chunks:
                synthesis_msg = (
                    f"Research question: {query}\n\n"
                    f"Synthesize a final answer from this evidence:\n"
                    f"{build_context_prompt(chunks)}"
                )
                final_answer = self._call_llm([
                    {"role": "system", "content": build_system_prompt()},
                    {"role": "user", "content": synthesis_msg}
                ])
            else:
                final_answer = (
                    "I could not find sufficient evidence to answer this question. "
                    "Try fetching papers first using the Ingest tab."
                )

        # Parse citations from final answer
        citations = extract_citations(final_answer, memory.get_all_chunks_as_context())

        return {
            "answer": final_answer,
            "citations": citations,
            "trace": memory.format_trace(),
            "steps": memory.iteration_count,
            "confidence": memory.last_confidence,
            "memory": memory,
            "model_used": f"{self.backend}/{self.model} (ReAct)"
        }

    def _decompose_query(self, query: str) -> List[str]:
        """
        Simple heuristic query decomposition.
        For a production system: use LLM for this step.
        
        Returns 1–3 sub-queries that together cover the original question.
        """
        query_lower = query.lower()

        # Multi-part questions: split on "and" / "vs" / "compare"
        if " and " in query_lower and len(query.split()) > 8:
            parts = re.split(r"\s+and\s+", query, flags=re.IGNORECASE)
            return [p.strip() for p in parts[:3]]

        if " vs " in query_lower or " versus " in query_lower:
            parts = re.split(r"\s+vs\.?\s+|\s+versus\s+", query, flags=re.IGNORECASE)
            return [p.strip() for p in parts[:2]] + [query]

        # "How does X compare to Y" → ["X", "Y", "X vs Y"]
        compare_match = re.search(r"compare\s+(.+?)\s+(?:to|with|and)\s+(.+)", query_lower)
        if compare_match:
            a, b = compare_match.group(1), compare_match.group(2)
            return [a.strip(), b.strip(), query]

        # Default: just use the original query
        return [query]
