"""
tools.py
========
Tool registry for the agentic ReAct loop.

Each tool is a callable with:
  - name: string identifier the LLM uses to call it
  - description: what it does (shown to LLM for tool selection)
  - parameters: what args it expects
  - run(): the actual execution

The LLM picks a tool by name + provides args. We execute it and return an observation.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional
from loguru import logger
import json


@dataclass
class ToolResult:
    """Structured result from a tool call."""
    tool_name: str
    success: bool
    output: str          # Human-readable string for the agent to observe
    data: Any = None     # Structured data for internal use
    error: str = ""


@dataclass
class Tool:
    """A single agent tool."""
    name: str
    description: str
    parameters: Dict[str, str]   # param_name → description
    _fn: Callable = field(repr=False)

    def run(self, **kwargs) -> ToolResult:
        try:
            result = self._fn(**kwargs)
            return result
        except Exception as e:
            logger.error(f"Tool '{self.name}' failed: {e}")
            return ToolResult(
                tool_name=self.name,
                success=False,
                output=f"Tool failed: {str(e)}",
                error=str(e)
            )


class ToolRegistry:
    """
    Registry of all tools available to the agent.
    Provides tool descriptions for LLM prompt and dispatches calls.
    """

    def __init__(self):
        self.tools: Dict[str, Tool] = {}

    def register(self, tool: Tool):
        self.tools[tool.name] = tool
        logger.debug(f"Registered tool: {tool.name}")

    def get(self, name: str) -> Optional[Tool]:
        return self.tools.get(name)

    def describe_all(self) -> str:
        """
        Returns a formatted string of all tools for the LLM system prompt.
        Format the LLM learns: tool_name(param=...) → what it does
        """
        lines = []
        for tool in self.tools.values():
            params = ", ".join(
                f"{k}: {v}" for k, v in tool.parameters.items()
            )
            lines.append(f"- {tool.name}({params})\n  → {tool.description}")
        return "\n".join(lines)

    def call(self, name: str, **kwargs) -> ToolResult:
        """Dispatch a tool call by name."""
        tool = self.get(name)
        if not tool:
            return ToolResult(
                tool_name=name,
                success=False,
                output=f"Unknown tool: '{name}'. Available: {list(self.tools.keys())}",
                error="unknown_tool"
            )
        logger.info(f"Calling tool: {name}({kwargs})")
        return tool.run(**kwargs)


def build_tool_registry(fetcher, embedding_store, retriever, processor) -> ToolRegistry:
    """
    Factory: builds and returns the full tool registry wired to pipeline components.
    
    Tools available to the agent:
    1. search_arxiv      - fetch new papers from arXiv
    2. retrieve_chunks   - hybrid semantic search in vector DB
    3. get_paper_details - metadata for a specific paper
    4. summarize_chunks  - summarize a set of chunk texts
    5. check_memory      - introspect what's been retrieved so far
    """
    registry = ToolRegistry()

    # ── Tool 1: search_arxiv ─────────────────────────────────────────────────
    def _search_arxiv(query: str, max_results: int = 5, year_from: int = 2020) -> ToolResult:
        """Fetch and index new papers from arXiv."""
        papers = fetcher.search(query=query, max_results=max_results, year_from=year_from)
        if not papers:
            return ToolResult(
                tool_name="search_arxiv",
                success=False,
                output=f"No papers found for query: '{query}'"
            )

        # Download + process + embed
        downloaded = []
        for paper in papers:
            paper = fetcher.download_pdf(paper)
            if paper.local_pdf_path:
                downloaded.append(paper)

        if downloaded:
            chunks = processor.process_papers(downloaded)
            embedding_store.add_chunks(chunks)
            retriever.rebuild_index()

        paper_summaries = "\n".join(
            f"  [{i+1}] {p.title} ({p.year}) — {p.authors[0] if p.authors else 'Unknown'}"
            for i, p in enumerate(papers)
        )
        return ToolResult(
            tool_name="search_arxiv",
            success=True,
            output=f"Found and indexed {len(downloaded)} papers:\n{paper_summaries}",
            data={"papers": [
                {"title": p.title, "year": p.year, "url": p.url, "abstract": p.abstract[:200]}
                for p in papers
            ]}
        )

    registry.register(Tool(
        name="search_arxiv",
        description="Search arXiv for research papers on a topic. Use when you need NEW papers not yet in the database.",
        parameters={
            "query": "search terms for arXiv (specific and technical)",
            "max_results": "number of papers to fetch (default 5)",
            "year_from": "earliest publication year (default 2020)"
        },
        _fn=_search_arxiv
    ))

    # ── Tool 2: retrieve_chunks ───────────────────────────────────────────────
    def _retrieve_chunks(query: str, top_k: int = 5, year_from: int = None, year_to: int = None) -> ToolResult:
        """Hybrid semantic search over indexed papers."""
        results = retriever.retrieve(
            query=query,
            year_from=year_from,
            year_to=year_to,
            top_k=top_k
        )
        if not results:
            return ToolResult(
                tool_name="retrieve_chunks",
                success=False,
                output="No relevant chunks found. Try a different query or search_arxiv first."
            )

        formatted = []
        for i, chunk in enumerate(results, 1):
            meta = chunk["metadata"]
            score = chunk.get("rerank_score", 0)
            formatted.append(
                f"[{i}] {meta['title']} ({meta['year']}) | score={score:.3f}\n"
                f"    Section: {meta.get('section','?')} | Page {meta.get('page_number','?')}\n"
                f"    Text: {chunk['text'][:300]}..."
            )

        return ToolResult(
            tool_name="retrieve_chunks",
            success=True,
            output="\n\n".join(formatted),
            data=results
        )

    registry.register(Tool(
        name="retrieve_chunks",
        description="Hybrid semantic + keyword search over already-indexed papers. Use this FIRST before search_arxiv.",
        parameters={
            "query": "specific research question or topic to search for",
            "top_k": "number of chunks to retrieve (default 5)",
            "year_from": "filter to papers from this year (optional)",
            "year_to": "filter to papers up to this year (optional)"
        },
        _fn=_retrieve_chunks
    ))

    # ── Tool 3: get_paper_details ─────────────────────────────────────────────
    def _get_paper_details(title_keyword: str) -> ToolResult:
        """Get full metadata for a specific paper by title keyword."""
        all_docs = embedding_store.get_all_texts()
        matches = [
            doc for doc in all_docs
            if title_keyword.lower() in doc["metadata"].get("title", "").lower()
        ]
        if not matches:
            return ToolResult(
                tool_name="get_paper_details",
                success=False,
                output=f"No paper found matching '{title_keyword}'"
            )

        meta = matches[0]["metadata"]
        output = (
            f"Title: {meta['title']}\n"
            f"Authors: {meta['authors']}\n"
            f"Year: {meta['year']}\n"
            f"URL: {meta['source_url']}\n"
            f"Abstract: {meta['abstract']}\n"
            f"Keywords: {meta.get('keywords','N/A')}"
        )
        return ToolResult(
            tool_name="get_paper_details",
            success=True,
            output=output,
            data=meta
        )

    registry.register(Tool(
        name="get_paper_details",
        description="Get full metadata (authors, abstract, URL) for a specific paper by keyword in its title.",
        parameters={"title_keyword": "keyword to match in paper title"},
        _fn=_get_paper_details
    ))

    # ── Tool 4: summarize_chunks ──────────────────────────────────────────────
    def _summarize_chunks(chunk_texts: str, focus: str = "") -> ToolResult:
        """
        Extract key points from a set of chunk texts.
        chunk_texts: newline-separated list of texts to summarize.
        focus: what aspect to focus the summary on.
        """
        texts = [t.strip() for t in chunk_texts.split("\n---\n") if t.strip()]
        if not texts:
            return ToolResult(
                tool_name="summarize_chunks",
                success=False,
                output="No texts provided to summarize."
            )

        # Simple extractive summary: first 2 sentences per chunk
        summaries = []
        for i, text in enumerate(texts[:5], 1):
            sentences = text.split(". ")
            key = ". ".join(sentences[:2]) + "."
            summaries.append(f"[{i}] {key}")

        focus_note = f" (focused on: {focus})" if focus else ""
        return ToolResult(
            tool_name="summarize_chunks",
            success=True,
            output=f"Key points{focus_note}:\n" + "\n".join(summaries),
            data=summaries
        )

    registry.register(Tool(
        name="summarize_chunks",
        description="Summarize and extract key points from retrieved text chunks. Use after retrieve_chunks.",
        parameters={
            "chunk_texts": "texts to summarize, separated by '---'",
            "focus": "specific aspect to focus summary on (optional)"
        },
        _fn=_summarize_chunks
    ))

    return registry
