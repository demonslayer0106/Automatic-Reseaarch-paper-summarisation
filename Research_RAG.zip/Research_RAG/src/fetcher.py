"""
fetcher.py
==========
Fetches research papers from arXiv using their public API.
Returns structured paper metadata + PDF download URLs.
"""

import arxiv
import requests
import os
import time
from pathlib import Path
from loguru import logger
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Paper:
    """Structured representation of a research paper."""
    paper_id: str
    title: str
    authors: List[str]
    abstract: str
    year: int
    url: str
    pdf_url: str
    categories: List[str]
    keywords: List[str] = field(default_factory=list)
    local_pdf_path: Optional[str] = None
    source: str = "arxiv"


class ArxivFetcher:
    """
    Fetches papers from arXiv based on a query.
    
    How it works:
    - Uses the `arxiv` Python client to query arXiv's search API
    - Supports filtering by category, year range, and max results
    - Downloads PDFs locally for processing
    """

    def __init__(self, download_dir: str = "data/pdfs"):
        self.download_dir = Path(download_dir)
        self.download_dir.mkdir(parents=True, exist_ok=True)
        self.client = arxiv.Client(
            page_size=10,
            delay_seconds=3,   # Respect arXiv rate limits
            num_retries=3
        )

    def search(
        self,
        query: str,
        max_results: int = 10,
        category: Optional[str] = None,  # e.g., "cs.LG", "cs.CL"
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
    ) -> List[Paper]:
        """
        Search arXiv and return Paper objects.
        
        Args:
            query: Natural language search query
            max_results: Max papers to fetch
            category: arXiv category filter (e.g., 'cs.AI')
            year_from / year_to: Optional year range filter
        
        Returns:
            List of Paper dataclass objects
        """
        logger.info(f"Searching arXiv for: '{query}' (max={max_results})")

        # Build query with optional category filter
        search_query = query
        if category:
            search_query = f"cat:{category} AND ({query})"

        search = arxiv.Search(
            query=search_query,
            max_results=max_results * 2,  # Fetch extra to allow year filtering
            sort_by=arxiv.SortCriterion.Relevance,
        )

        papers = []
        for result in self.client.results(search):
            year = result.published.year

            # Apply year filter
            if year_from and year < year_from:
                continue
            if year_to and year > year_to:
                continue

            paper = Paper(
                paper_id=result.entry_id.split("/")[-1],
                title=result.title,
                authors=[a.name for a in result.authors],
                abstract=result.summary,
                year=year,
                url=result.entry_id,
                pdf_url=result.pdf_url,
                categories=result.categories,
            )
            papers.append(paper)

            if len(papers) >= max_results:
                break

        logger.info(f"Found {len(papers)} papers")
        return papers

    def download_pdf(self, paper: Paper) -> Paper:
        """
        Download the PDF of a paper to local disk.
        
        Uses requests to fetch the PDF binary from arXiv.
        Skips download if file already exists (cache check).
        """
        pdf_path = self.download_dir / f"{paper.paper_id}.pdf"

        if pdf_path.exists():
            logger.debug(f"PDF already cached: {pdf_path}")
            paper.local_pdf_path = str(pdf_path)
            return paper

        logger.info(f"Downloading PDF: {paper.title[:60]}...")
        try:
            response = requests.get(paper.pdf_url, timeout=30, stream=True)
            response.raise_for_status()

            with open(pdf_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            paper.local_pdf_path = str(pdf_path)
            logger.info(f"Downloaded: {pdf_path}")
            time.sleep(1)  # Be polite to arXiv servers

        except Exception as e:
            logger.error(f"Failed to download {paper.paper_id}: {e}")

        return paper

    def fetch_and_download(
        self,
        query: str,
        max_results: int = 10,
        **kwargs
    ) -> List[Paper]:
        """Convenience method: search + download all PDFs."""
        papers = self.search(query, max_results, **kwargs)
        downloaded = []
        for paper in papers:
            paper = self.download_pdf(paper)
            if paper.local_pdf_path:
                downloaded.append(paper)
        return downloaded
