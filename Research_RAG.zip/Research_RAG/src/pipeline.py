"""
pipeline.py
===========
Orchestrates the full RAG pipeline end-to-end.
This is the single entry point used by the Streamlit UI.

Manages:
- Component initialization (embedder, retriever, agent)
- Paper ingestion workflow
- Query workflow
- State between Streamlit rerenders
"""

from loguru import logger
from typing import List, Optional

from fetcher import ArxivFetcher, Paper
from processor import PDFProcessor
from embedder import EmbeddingStore
from retriever import HybridRetriever
from agent import ResearchAgent, AgentResponse


class ResearchRAGPipeline:
    """
    Top-level orchestrator for the Research RAG pipeline.
    
    Initialization is expensive (loads models), so this is designed
    to be instantiated once and reused (via Streamlit session state).
    """

    def __init__(
        self,
        embedding_model: str = "BAAI/bge-base-en-v1.5",
        llm_backend: str = "auto",
        llm_model: Optional[str] = None,
        data_dir: str = "data",
    ):
        logger.info("Initializing Research RAG Pipeline...")

        # Initialize all components
        self.fetcher = ArxivFetcher(download_dir=f"{data_dir}/pdfs")
        self.processor = PDFProcessor(chunk_size=512, chunk_overlap=64)
        self.embedding_store = EmbeddingStore(
            model_name=embedding_model,
            persist_dir=f"{data_dir}/chromadb"
        )
        self.retriever = HybridRetriever(
            embedding_store=self.embedding_store,
            top_k_candidates=20,
            top_k_final=5,
        )
        self.agent = ResearchAgent(
            backend=llm_backend,
            model=llm_model,
        )

        logger.info("Pipeline ready!")

    def ingest_papers(
        self,
        query: str,
        max_papers: int = 5,
        category: Optional[str] = None,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        progress_callback=None,  # Streamlit progress callback
    ) -> dict:
        """
        Full ingestion: fetch → process → embed → store.
        
        Returns summary dict with stats.
        """
        results = {"fetched": 0, "processed": 0, "chunks_added": 0, "papers": []}

        # 1. Fetch papers from arXiv
        if progress_callback:
            progress_callback(0.1, "Searching arXiv...")

        papers = self.fetcher.search(
            query=query,
            max_results=max_papers,
            category=category,
            year_from=year_from,
            year_to=year_to,
        )
        results["fetched"] = len(papers)

        if not papers:
            logger.warning("No papers found for query.")
            return results

        # 2. Download PDFs
        if progress_callback:
            progress_callback(0.3, f"Downloading {len(papers)} PDFs...")

        downloaded = []
        for paper in papers:
            paper = self.fetcher.download_pdf(paper)
            if paper.local_pdf_path:
                downloaded.append(paper)

        # 3. Process PDFs into chunks
        if progress_callback:
            progress_callback(0.5, "Processing PDFs...")

        chunks = self.processor.process_papers(downloaded)
        results["processed"] = len(downloaded)

        # 4. Embed and store in ChromaDB
        if progress_callback:
            progress_callback(0.7, "Embedding and indexing...")

        added = self.embedding_store.add_chunks(chunks)
        results["chunks_added"] = added

        # 5. Rebuild BM25 index with new documents
        if progress_callback:
            progress_callback(0.9, "Updating search index...")

        self.retriever.rebuild_index()

        results["papers"] = [
            {"title": p.title, "authors": p.authors[:2], "year": p.year, "url": p.url}
            for p in downloaded
        ]

        if progress_callback:
            progress_callback(1.0, "Done!")

        logger.info(f"Ingestion complete: {results}")
        return results

    def query(
        self,
        question: str,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
        top_k: int = 5,
    ) -> AgentResponse:
        """
        Full query pipeline: retrieve → rerank → generate response.
        """
        logger.info(f"Query: {question}")

        # Retrieve relevant chunks
        retrieved = self.retriever.retrieve(
            query=question,
            year_from=year_from,
            year_to=year_to,
            author=author,
            top_k=top_k,
        )

        if not retrieved:
            logger.warning("No relevant chunks found.")

        # Generate citation-grounded response
        response = self.agent.generate(
            query=question,
            retrieved_chunks=retrieved,
        )

        return response

    def get_stats(self) -> dict:
        """Get current knowledge base statistics."""
        return self.embedding_store.get_stats()
