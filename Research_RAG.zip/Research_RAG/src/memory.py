"""
memory.py
=========
Session memory for the ReAct agent.

Tracks everything that happened within a single query session:
- What the agent was thinking at each step (scratchpad)
- What it searched for (prevents duplicate searches)
- What chunks it retrieved (builds up context across iterations)
- What partial answers it formed
- The full step-by-step trace (shown in UI debug mode)

This is EPHEMERAL — resets per query. It's not long-term user memory.
The key insight: by accumulating retrieved chunks across iterations,
later reasoning steps have access to ALL evidence gathered so far,
not just what was retrieved in the current step.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class AgentStep:
    """
    A single step in the ReAct trace.
    One step = Think + Act + Observe.
    """
    step_number: int
    thought: str          # What the agent was reasoning
    action: str           # Tool name called
    action_input: Dict    # Args passed to tool
    observation: str      # What the tool returned
    timestamp: str = field(default_factory=lambda: datetime.now().strftime("%H:%M:%S"))
    confidence: Optional[float] = None   # Self-eval score if computed


class AgentMemory:
    """
    In-session memory for one query's ReAct loop.
    
    The agent reads from memory to:
    - Avoid re-searching things it already searched
    - Build on previously retrieved evidence
    - Know how many iterations it's done
    - Track its own confidence progression
    """

    def __init__(self):
        self.reset()

    def reset(self):
        """Clear all memory for a new query."""
        self.query: str = ""
        self.sub_queries: List[str] = []
        self.steps: List[AgentStep] = []
        self.searched_queries: List[str] = []       # arXiv queries already fired
        self.retrieved_chunks: List[dict] = []      # All chunks gathered so far
        self.partial_answers: List[str] = []        # Thoughts accumulated
        self.papers_seen: List[str] = []            # Paper titles encountered
        self.confidence_scores: List[float] = []   # Self-eval per iteration
        self.tool_call_counts: Dict[str, int] = {} # How many times each tool was called

    def log_step(self, step: AgentStep):
        """Record a completed ReAct step."""
        self.steps.append(step)
        if step.confidence is not None:
            self.confidence_scores.append(step.confidence)

    def add_retrieved_chunks(self, chunks: List[dict]):
        """
        Accumulate retrieved chunks across iterations.
        Deduplicates by chunk ID so the same chunk isn't added twice
        even if multiple retrieve calls return it.
        """
        existing_ids = {c.get("id") for c in self.retrieved_chunks}
        for chunk in chunks:
            if chunk.get("id") not in existing_ids:
                self.retrieved_chunks.append(chunk)
                existing_ids.add(chunk.get("id"))

                # Track paper titles seen
                title = chunk.get("metadata", {}).get("title", "")
                if title and title not in self.papers_seen:
                    self.papers_seen.append(title)

    def add_searched_query(self, query: str):
        if query not in self.searched_queries:
            self.searched_queries.append(query)

    def increment_tool_count(self, tool_name: str):
        self.tool_call_counts[tool_name] = self.tool_call_counts.get(tool_name, 0) + 1

    def has_searched(self, query: str) -> bool:
        """Check if a very similar query has already been searched."""
        query_lower = query.lower()
        return any(
            query_lower in s.lower() or s.lower() in query_lower
            for s in self.searched_queries
        )

    def get_context_summary(self) -> str:
        """
        Returns a text summary of memory state for injection into the LLM prompt.
        This is what the agent 'sees' when it reads its own memory.
        """
        lines = []

        if self.searched_queries:
            lines.append(f"Already searched arXiv for: {', '.join(repr(q) for q in self.searched_queries)}")

        if self.retrieved_chunks:
            lines.append(f"Retrieved {len(self.retrieved_chunks)} chunks from {len(self.papers_seen)} papers")
            if self.papers_seen:
                lines.append(f"Papers in memory: {'; '.join(self.papers_seen[:5])}")

        if self.partial_answers:
            lines.append(f"Key findings so far:\n" + "\n".join(f"  - {a}" for a in self.partial_answers[-3:]))

        if self.tool_call_counts:
            counts = ", ".join(f"{k}×{v}" for k, v in self.tool_call_counts.items())
            lines.append(f"Tools used: {counts}")

        return "\n".join(lines) if lines else "No prior context in this session."

    def get_all_chunks_as_context(self) -> List[dict]:
        """Return all accumulated chunks for final answer synthesis."""
        # De-duplicate + sort by rerank score (best first)
        seen = {}
        for chunk in self.retrieved_chunks:
            cid = chunk.get("id", id(chunk))
            if cid not in seen or chunk.get("rerank_score", 0) > seen[cid].get("rerank_score", 0):
                seen[cid] = chunk
        return sorted(seen.values(), key=lambda x: x.get("rerank_score", 0), reverse=True)

    @property
    def iteration_count(self) -> int:
        return len(self.steps)

    @property
    def last_confidence(self) -> float:
        return self.confidence_scores[-1] if self.confidence_scores else 0.0

    def format_trace(self) -> str:
        """Format the full ReAct trace for display in the UI."""
        lines = [f"Query: {self.query}\n"]
        for step in self.steps:
            lines.append(f"── Step {step.step_number} [{step.timestamp}] ──")
            lines.append(f"🤔 Think: {step.thought}")
            lines.append(f"🔧 Act: {step.action}({step.action_input})")
            lines.append(f"👁 Observe: {step.observation[:300]}...")
            if step.confidence is not None:
                lines.append(f"📊 Confidence: {step.confidence:.2f}")
            lines.append("")
        return "\n".join(lines)
