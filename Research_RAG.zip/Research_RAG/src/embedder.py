"""
embedder.py
===========
Embedding model + ChromaDB vector store management.

Embedding model choices (ranked by quality/speed tradeoff):
- BAAI/bge-large-en-v1.5     → Best quality, ~1.3GB RAM
- BAAI/bge-base-en-v1.5      → Good quality, ~400MB RAM  ← Default
- intfloat/e5-large-v2        → Alternative, similar quality
- all-MiniLM-L6-v2            → Fastest, lower quality

BGE models need a query prefix "Represent this sentence for searching: "
for queries, but NOT for documents. This is critical for BGE performance.
"""

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from loguru import logger
from typing import List, Optional
from pathlib import Path
import hashlib

from processor import DocumentChunk


# BGE models require this prefix on QUERIES (not documents)
BGE_QUERY_PREFIX = "Represent this sentence for searching relevant passages: "


class EmbeddingStore:
    """
    Manages the embedding model and ChromaDB vector store.
    
    Architecture:
    - SentenceTransformer loads BGE model locally (downloads once, cached)
    - ChromaDB runs fully in-memory or persisted to disk
    - Chunks stored with embeddings + metadata for filtered retrieval
    
    Key design: We store metadata (year, authors, title, section) alongside 
    vectors so we can do metadata filtering BEFORE vector similarity search.
    This avoids retrieving irrelevant chunks even if they're semantically close.
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-base-en-v1.5",
        persist_dir: str = "data/chromadb",
        collection_name: str = "research_papers"
    ):
        self.model_name = model_name
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self.collection_name = collection_name

        # Load embedding model
        logger.info(f"Loading embedding model: {model_name}")
        self.model = SentenceTransformer(model_name)
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        logger.info(f"Embedding dimension: {self.embedding_dim}")

        # Initialize ChromaDB with disk persistence
        self.chroma_client = chromadb.PersistentClient(
            path=str(self.persist_dir),
            settings=Settings(anonymized_telemetry=False)
        )

        # Get or create collection
        self.collection = self.chroma_client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"},  # Cosine similarity for text
        )
        logger.info(f"ChromaDB collection '{collection_name}' ready. "
                    f"Documents: {self.collection.count()}")

    def embed_texts(self, texts: List[str], is_query: bool = False) -> List[List[float]]:
        """
        Generate embeddings for a list of texts.
        
        BGE-specific: queries need the instruction prefix, documents don't.
        batch_size=32 balances memory and speed.
        """
        if is_query:
            # BGE query prefix improves retrieval quality significantly
            texts = [BGE_QUERY_PREFIX + t for t in texts]

        embeddings = self.model.encode(
            texts,
            batch_size=32,
            show_progress_bar=len(texts) > 10,
            normalize_embeddings=True,  # Normalize for cosine similarity
            convert_to_numpy=True
        )
        return embeddings.tolist()

    def add_chunks(self, chunks: List[DocumentChunk]) -> int:
        """
        Add DocumentChunks to ChromaDB.
        
        ChromaDB expects:
        - ids: unique string IDs
        - embeddings: list of float vectors
        - documents: the text content
        - metadatas: dict of filterable fields (must be str/int/float, not lists)
        
        Note: ChromaDB doesn't support list metadata values, so we join lists as strings.
        """
        if not chunks:
            return 0

        # Filter out already-indexed chunks (avoid duplicates on re-run)
        existing_ids = set(self.collection.get()["ids"])
        new_chunks = [c for c in chunks if c.chunk_id not in existing_ids]

        if not new_chunks:
            logger.info("All chunks already in vector store, skipping.")
            return 0

        logger.info(f"Embedding {len(new_chunks)} chunks...")

        # Generate embeddings for all new chunks
        texts = [chunk.text for chunk in new_chunks]
        embeddings = self.embed_texts(texts, is_query=False)

        # Prepare ChromaDB batch
        ids = [c.chunk_id for c in new_chunks]
        documents = [c.text for c in new_chunks]
        metadatas = [
            {
                "paper_id": c.paper_id,
                "title": c.title,
                "authors": ", ".join(c.authors[:3]),  # First 3 authors
                "year": c.year,
                "abstract": c.abstract[:300],          # Truncated abstract
                "source_url": c.source_url,
                "page_number": c.page_number,
                "chunk_index": c.chunk_index,
                "section": c.section or "Unknown",
                "keywords": ", ".join(c.keywords),
            }
            for c in new_chunks
        ]

        # Add to ChromaDB in batches of 100
        batch_size = 100
        for i in range(0, len(new_chunks), batch_size):
            self.collection.add(
                ids=ids[i:i+batch_size],
                embeddings=embeddings[i:i+batch_size],
                documents=documents[i:i+batch_size],
                metadatas=metadatas[i:i+batch_size],
            )

        logger.info(f"Added {len(new_chunks)} chunks. Total: {self.collection.count()}")
        return len(new_chunks)

    def query(
        self,
        query_text: str,
        n_results: int = 10,
        where: Optional[dict] = None,  # ChromaDB metadata filter
    ) -> List[dict]:
        """
        Semantic vector search in ChromaDB.
        
        Args:
            query_text: The search query (gets BGE prefix applied)
            n_results: Number of results to return
            where: ChromaDB filter dict, e.g., {"year": {"$gte": 2022}}
        
        Returns:
            List of result dicts with text, metadata, and distance score
        """
        query_embedding = self.embed_texts([query_text], is_query=True)[0]

        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(n_results, self.collection.count()),
            where=where,
            include=["documents", "metadatas", "distances"]
        )

        # Flatten ChromaDB's nested response format
        formatted = []
        for i in range(len(results["ids"][0])):
            formatted.append({
                "id": results["ids"][0][i],
                "text": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
                "score": 1 - results["distances"][0][i],  # Convert distance to similarity
            })

        return formatted

    def get_all_texts(self) -> List[dict]:
        """Retrieve all stored texts (used for BM25 index building)."""
        if self.collection.count() == 0:
            return []
        result = self.collection.get(include=["documents", "metadatas"])
        return [
            {"text": doc, "metadata": meta, "id": id_}
            for doc, meta, id_ in zip(
                result["documents"], result["metadatas"], result["ids"]
            )
        ]

    def get_stats(self) -> dict:
        """Return store statistics."""
        count = self.collection.count()
        if count == 0:
            return {"total_chunks": 0, "papers": 0}

        metadatas = self.collection.get(include=["metadatas"])["metadatas"]
        unique_papers = len(set(m["paper_id"] for m in metadatas))
        unique_years = sorted(set(m["year"] for m in metadatas))

        return {
            "total_chunks": count,
            "papers": unique_papers,
            "year_range": f"{min(unique_years)}–{max(unique_years)}" if unique_years else "N/A"
        }
