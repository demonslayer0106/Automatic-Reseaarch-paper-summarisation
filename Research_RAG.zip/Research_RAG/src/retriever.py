"""
retriever.py
============
The full retrieval pipeline:
  Query Rewrite → Metadata Filter → Hybrid Retrieval → Cross-Encoder Reranking

This is the most important module for retrieval quality. Each stage explained:

1. QUERY REWRITE: Expands/denoises the raw user query into a cleaner search query.
   Simple version: use the LLM to rephrase. Improves recall significantly.

2. METADATA FILTERING: Filter by year/author before vector search.
   Reduces the search space and avoids semantic drift across irrelevant papers.

3. HYBRID RETRIEVAL: Combines dense (semantic) + sparse (BM25/keyword) search.
   - Dense (BGE): great at semantic similarity, misses exact terms
   - BM25: great at exact keyword match, misses paraphrasing
   - Reciprocal Rank Fusion (RRF) combines the two ranked lists

4. CROSS-ENCODER RERANKING: A small cross-encoder model (ms-marco-MiniLM) 
   re-scores each retrieved chunk against the query. Much more accurate than
   cosine similarity but too slow to run on all chunks — so we run it only 
   on the top-K candidates from hybrid retrieval.
"""

import re
from typing import List, Optional, Tuple
from loguru import logger
from rank_bm25 import BM25Okapi
from transformers import pipeline

from embedder import EmbeddingStore


class HybridRetriever:
    """
    Implements hybrid retrieval = dense vector search + BM25 keyword search,
    combined via Reciprocal Rank Fusion, then reranked with a cross-encoder.
    """

    def __init__(
        self,
        embedding_store: EmbeddingStore,
        reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2",
        top_k_candidates: int = 20,   # Candidates fed to reranker
        top_k_final: int = 5,         # Final results returned to LLM
    ):
        self.store = embedding_store
        self.top_k_candidates = top_k_candidates
        self.top_k_final = top_k_final

        # Build BM25 index from all stored chunks
        logger.info("Building BM25 index...")
        self._build_bm25_index()

        # Load cross-encoder reranker
        logger.info(f"Loading reranker: {reranker_model}")
        self.reranker = pipeline(
            "text-classification",
            model=reranker_model,
            device=-1,  # CPU; use device=0 for GPU
            truncation=True,
            max_length=512
        )
        logger.info("Retriever ready.")

    def _build_bm25_index(self):
        """
        Build BM25 index from all texts in ChromaDB.
        
        BM25 needs a tokenized corpus. We tokenize by whitespace for simplicity.
        In production, you'd add stemming + stopword removal.
        
        Re-call this after adding new documents.
        """
        all_docs = self.store.get_all_texts()
        self.bm25_docs = all_docs  # Store for retrieval mapping

        if not all_docs:
            self.bm25_index = None
            logger.warning("Empty corpus — BM25 index not built.")
            return

        tokenized_corpus = [doc["text"].lower().split() for doc in all_docs]
        self.bm25_index = BM25Okapi(tokenized_corpus)
        logger.info(f"BM25 index built with {len(all_docs)} documents.")

    def rebuild_index(self):
        """Call this after adding new papers to update the BM25 index."""
        self._build_bm25_index()

    def rewrite_query(self, raw_query: str) -> str:
        """
        Simple query rewriting without an LLM call.
        
        For a production system, you'd call the LLM here with a prompt like:
        "Rewrite the following research query to be more specific and 
        search-engine friendly: {raw_query}"
        
        Here we do lightweight rule-based cleanup:
        - Remove question words
        - Expand common abbreviations
        """
        query = raw_query.strip()

        # Remove common question prefixes that don't help vector search
        query = re.sub(
            r"^(what is|what are|how does|explain|tell me about|describe)\s+",
            "",
            query,
            flags=re.IGNORECASE
        )

        # Common ML abbreviation expansions
        expansions = {
            "LLM": "large language model",
            "RAG": "retrieval augmented generation",
            "RL": "reinforcement learning",
            "CV": "computer vision",
            "NLP": "natural language processing",
            "GAN": "generative adversarial network",
            "BERT": "bidirectional encoder representations from transformers",
            "GPT": "generative pretrained transformer",
        }
        for abbr, full in expansions.items():
            query = re.sub(rf"\b{abbr}\b", f"{abbr} {full}", query)

        return query.strip()

    def build_metadata_filter(
        self,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
    ) -> Optional[dict]:
        """
        Build ChromaDB metadata filter dict.
        
        ChromaDB uses MongoDB-style operators: $gte, $lte, $eq, $contains, $and
        """
        conditions = []

        if year_from:
            conditions.append({"year": {"$gte": year_from}})
        if year_to:
            conditions.append({"year": {"$lte": year_to}})
        if author:
            conditions.append({"authors": {"$contains": author}})

        if not conditions:
            return None
        if len(conditions) == 1:
            return conditions[0]
        return {"$and": conditions}

    def dense_search(
        self,
        query: str,
        n_results: int,
        metadata_filter: Optional[dict]
    ) -> List[dict]:
        """Semantic vector search via ChromaDB."""
        return self.store.query(
            query_text=query,
            n_results=n_results,
            where=metadata_filter
        )

    def bm25_search(
        self,
        query: str,
        n_results: int,
        metadata_filter: Optional[dict] = None
    ) -> List[dict]:
        """
        BM25 keyword search over the stored corpus.
        
        Returns results in the same format as dense_search for easy fusion.
        """
        if self.bm25_index is None:
            return []

        tokenized_query = query.lower().split()
        scores = self.bm25_index.get_scores(tokenized_query)

        # Create (score, doc_index) pairs and sort
        ranked = sorted(
            enumerate(scores),
            key=lambda x: x[1],
            reverse=True
        )

        results = []
        for doc_idx, score in ranked[:n_results * 2]:  # Over-fetch for filter
            doc = self.bm25_docs[doc_idx]

            # Apply metadata filters manually (BM25 has no built-in filter)
            if metadata_filter:
                meta = doc["metadata"]
                if not self._passes_filter(meta, metadata_filter):
                    continue

            results.append({
                "id": doc["id"],
                "text": doc["text"],
                "metadata": doc["metadata"],
                "score": float(score),
            })

            if len(results) >= n_results:
                break

        return results

    def _passes_filter(self, metadata: dict, filter_dict: dict) -> bool:
        """Check if a metadata dict satisfies a filter condition."""
        if "$and" in filter_dict:
            return all(self._passes_filter(metadata, f) for f in filter_dict["$and"])

        for field, condition in filter_dict.items():
            if isinstance(condition, dict):
                for op, value in condition.items():
                    if op == "$gte" and metadata.get(field, 0) < value:
                        return False
                    elif op == "$lte" and metadata.get(field, 9999) > value:
                        return False
                    elif op == "$contains" and value.lower() not in str(metadata.get(field, "")).lower():
                        return False
        return True

    def reciprocal_rank_fusion(
        self,
        dense_results: List[dict],
        bm25_results: List[dict],
        k: int = 60  # RRF constant — typically 60
    ) -> List[dict]:
        """
        Combine dense and BM25 rankings using Reciprocal Rank Fusion.
        
        RRF formula: score(d) = Σ 1/(k + rank(d))
        
        This is better than simply averaging scores because:
        - Scores from dense and BM25 are on different scales
        - RRF only uses rank positions, which are comparable
        - k=60 is empirically well-tuned (from the original RRF paper)
        """
        rrf_scores = {}
        id_to_doc = {}

        # Process dense results
        for rank, doc in enumerate(dense_results):
            doc_id = doc["id"]
            rrf_scores[doc_id] = rrf_scores.get(doc_id, 0) + 1 / (k + rank + 1)
            id_to_doc[doc_id] = doc

        # Process BM25 results
        for rank, doc in enumerate(bm25_results):
            doc_id = doc["id"]
            rrf_scores[doc_id] = rrf_scores.get(doc_id, 0) + 1 / (k + rank + 1)
            id_to_doc[doc_id] = doc

        # Sort by fused RRF score
        sorted_ids = sorted(rrf_scores, key=rrf_scores.get, reverse=True)

        fused = []
        for doc_id in sorted_ids:
            doc = id_to_doc[doc_id].copy()
            doc["rrf_score"] = rrf_scores[doc_id]
            fused.append(doc)

        return fused

    def rerank(self, query: str, candidates: List[dict]) -> List[dict]:
        """
        Cross-encoder reranking.
        
        The cross-encoder takes (query, document) pairs and outputs a relevance score.
        Unlike bi-encoders (used for retrieval), cross-encoders see both texts together,
        making them much more accurate but too slow for full corpus search.
        
        We only run reranking on top-K candidates (from hybrid retrieval).
        """
        if not candidates:
            return []

        # Build (query, passage) pairs for cross-encoder
        pairs = [[query, doc["text"]] for doc in candidates]

        # Get relevance scores from cross-encoder
        scores = self.reranker(pairs, batch_size=8)

        # Add reranker scores
        for doc, score_output in zip(candidates, scores):
            # ms-marco outputs 'score' for relevance
            doc["rerank_score"] = score_output["score"]

        # Sort by reranker score (higher = more relevant)
        reranked = sorted(candidates, key=lambda x: x["rerank_score"], reverse=True)
        return reranked

    def retrieve(
        self,
        query: str,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
        top_k: Optional[int] = None,
    ) -> List[dict]:
        """
        Full retrieval pipeline:
        1. Rewrite query
        2. Build metadata filter
        3. Dense search
        4. BM25 search  
        5. RRF fusion
        6. Cross-encoder reranking
        7. Return top-K
        """
        top_k = top_k or self.top_k_final

        # Step 1: Query rewriting
        rewritten_query = self.rewrite_query(query)
        logger.info(f"Query: '{query}' → Rewritten: '{rewritten_query}'")

        # Step 2: Metadata filter
        metadata_filter = self.build_metadata_filter(year_from, year_to, author)
        if metadata_filter:
            logger.info(f"Applying metadata filter: {metadata_filter}")

        # Step 3: Dense (semantic) search
        dense_results = self.dense_search(
            rewritten_query,
            n_results=self.top_k_candidates,
            metadata_filter=metadata_filter
        )
        logger.info(f"Dense search: {len(dense_results)} results")

        # Step 4: BM25 keyword search
        bm25_results = self.bm25_search(
            rewritten_query,
            n_results=self.top_k_candidates,
            metadata_filter=metadata_filter
        )
        logger.info(f"BM25 search: {len(bm25_results)} results")

        # Step 5: Reciprocal Rank Fusion
        fused_results = self.reciprocal_rank_fusion(dense_results, bm25_results)
        candidates = fused_results[:self.top_k_candidates]
        logger.info(f"After fusion: {len(candidates)} candidates")

        # Step 6: Cross-encoder reranking
        reranked = self.rerank(rewritten_query, candidates)
        logger.info(f"After reranking: returning top {top_k}")

        return reranked[:top_k]
