# 🔬 Research RAG Pipeline

A production-grade Retrieval-Augmented Generation system for academic research papers.  
Fetch arXiv papers → Index them → Ask questions → Get citation-grounded answers.

---

## 🏗️ Architecture

```
User Query
    │
    ▼
[ ArxivFetcher ]         fetcher.py
    │  arXiv API → Paper metadata + PDF download
    ▼
[ PDFProcessor ]         processor.py  
    │  PyMuPDF → clean text → semantic chunking → DocumentChunk objects
    ▼
[ EmbeddingStore ]       embedder.py
    │  BGE-base embeddings → ChromaDB (persistent vector store)
    ▼
[ HybridRetriever ]      retriever.py
    │  Query Rewrite → Metadata Filter → Dense + BM25 → RRF → Cross-Encoder Rerank
    ▼
[ ResearchAgent ]        agent.py
    │  Numbered context prompt → Ollama/OpenAI/Anthropic → Citation extraction
    ▼
[ Streamlit UI ]         app.py
       Ingest tab + Query tab + Debug tab
```

---

## 📂 File Structure

```
research_rag/
├── app.py                  # Streamlit UI (entry point)
├── requirements.txt        
├── data/                   # Auto-created
│   ├── pdfs/               # Downloaded PDFs (cached)
│   └── chromadb/           # Persistent vector store
└── src/
    ├── fetcher.py          # arXiv API + PDF download
    ├── processor.py        # PDF parsing + chunking
    ├── embedder.py         # BGE embeddings + ChromaDB
    ├── retriever.py        # Hybrid retrieval + reranking
    ├── agent.py            # LLM response generation
    └── pipeline.py         # Orchestrator
```

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. (Recommended) Set up local LLM with Ollama
```bash
# Install Ollama from https://ollama.ai
ollama serve                    # Start Ollama server
ollama pull mistral             # Download Mistral 7B (~4GB)
# OR
ollama pull llama3              # Download Llama 3 8B (~5GB)
```

### 3. (Alternative) Set API keys
```bash
export OPENAI_API_KEY="sk-..."
# OR
export ANTHROPIC_API_KEY="sk-ant-..."
```

### 4. Run the app
```bash
streamlit run app.py
```

---

## 🧠 How Each Component Works

### fetcher.py — ArxivFetcher
Uses the `arxiv` Python client to query arXiv's search API.
- Supports category filters (`cs.AI`, `cs.CL`, `cs.LG`, etc.)
- Year range filtering
- Downloads PDFs with rate limiting (polite to arXiv)
- Local PDF cache (won't re-download on rerun)

### processor.py — PDFProcessor  
- **PyMuPDF (fitz)**: Best-in-class PDF text extraction, preserves reading order
- **Text cleaning**: Fixes hyphenated line breaks, removes LaTeX artifacts, math placeholders
- **Semantic chunking**: Splits on paragraph boundaries (not arbitrary token windows)
  - Paragraphs > 512 tokens → split by sentences
  - Short paragraphs → merged with neighbors
  - Chunk overlap: last 64 words carried to next chunk for context continuity
- **Section detection**: Identifies Abstract/Introduction/Methods/Results headers

### embedder.py — EmbeddingStore
- **BGE-base-en-v1.5**: Best open-source embedding model for retrieval
  - Critical: BGE requires a query instruction prefix for queries (not for docs)
  - Normalized embeddings for cosine similarity
- **ChromaDB**: Persistent vector store with HNSW index
  - Metadata stored alongside vectors for filtered retrieval
  - Lists converted to strings (ChromaDB limitation)
  - Deduplication on re-indexing (checks existing IDs)

### retriever.py — HybridRetriever
Four-stage pipeline:

**1. Query Rewriting**
- Removes question prefixes ("what is", "explain")
- Expands abbreviations (LLM → large language model)
- In production: replace with LLM-based rewriting for best results

**2. Metadata Filtering**
- Filters by year range and/or author before vector search
- ChromaDB `where` clause: `{"year": {"$gte": 2022}}`
- BM25 applies the same filter post-hoc

**3. Hybrid Retrieval = Dense + BM25**
- **Dense**: ChromaDB semantic search (BGE embeddings)
- **BM25**: Keyword matching with `rank-bm25` (BM25Okapi)
- **Reciprocal Rank Fusion (RRF)**: Combines ranked lists without score normalization
  - Formula: `score(d) = Σ 1/(k + rank(d))` where k=60 (empirically optimal)
  - Better than weighted sum because scores are on incompatible scales

**4. Cross-Encoder Reranking**
- Model: `cross-encoder/ms-marco-MiniLM-L-6-v2`
- Takes (query, document) pairs → relevance score
- Much more accurate than bi-encoder similarity
- Only runs on top-20 candidates (too slow for full corpus)

### agent.py — ResearchAgent
- **Numbered context**: Each chunk labeled [1], [2], [3]...
- **System prompt**: Instructs LLM to cite every claim with [N] notation
- **Citation extraction**: Regex parses `[N]` markers → attaches source metadata
- **Multi-backend**: Ollama → OpenAI → Anthropic (auto-detects available)

---

## 🔧 Configuration Options

| Setting | Default | Notes |
|---------|---------|-------|
| Embedding model | `bge-base-en-v1.5` | Swap for `bge-large` for better quality |
| Chunk size | 512 tokens | Increase for more context per chunk |
| Chunk overlap | 64 tokens | Prevents context loss at boundaries |
| Top-K candidates | 20 | Candidates fed to cross-encoder |
| Top-K final | 5 | Chunks sent to LLM |
| LLM temperature | 0.1 | Low for factual accuracy |

---

## 🔄 Extending the Pipeline

**Add Semantic Scholar / PubMed:**
```python
# In fetcher.py, add a SemanticScholarFetcher class
import requests
class SemanticScholarFetcher:
    BASE_URL = "https://api.semanticscholar.org/graph/v1"
    def search(self, query, max_results=10):
        r = requests.get(f"{self.BASE_URL}/paper/search", 
                        params={"query": query, "limit": max_results,
                                "fields": "title,authors,year,abstract,openAccessPdf"})
        ...
```

**Use FAISS instead of ChromaDB:**
```python
import faiss
import numpy as np
# Build index: faiss.IndexFlatIP for cosine (after normalization)
index = faiss.IndexFlatIP(embedding_dim)
index.add(np.array(embeddings, dtype=np.float32))
```

**Add Kafka ingestion (async):**
```python
from kafka import KafkaProducer, KafkaConsumer
# Producer: sends paper_id + query to Kafka topic
# Consumer: worker processes PDF → embeds → stores
```

---

## 📊 Estimated Resource Requirements

| Component | RAM | Notes |
|-----------|-----|-------|
| BGE-base embeddings | ~400MB | Loaded into CPU RAM |
| Cross-encoder (MiniLM) | ~100MB | CPU only |
| Mistral 7B (Ollama) | ~5GB | GPU recommended |
| ChromaDB | ~50MB + 1.5KB/chunk | Persistent disk |

Total without LLM: ~600MB RAM  
With local Mistral: ~6GB RAM (GPU), ~10GB RAM (CPU)
