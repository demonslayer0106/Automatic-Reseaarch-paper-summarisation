"""
app_agentic.py
==============
Streamlit UI for the AGENTIC Research RAG Pipeline.

New vs old app.py:
- Mode toggle: Simple RAG vs Agentic ReAct
- Live reasoning trace displayed step by step
- Agent thought/action/observation shown in real time
- Confidence meter
- Tool call history
"""

import streamlit as st
import sys
import os
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

st.set_page_config(
    page_title="Agentic Research RAG",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
.stApp { background-color: #0f1117; }

.step-card {
    background: #161b27;
    border: 1px solid #2d3348;
    border-radius: 8px;
    padding: 14px 18px;
    margin: 8px 0;
}
.step-think { border-left: 3px solid #7f77dd; }
.step-act   { border-left: 3px solid #1d9e75; }
.step-obs   { border-left: 3px solid #ba7517; }
.step-eval  { border-left: 3px solid #d85a30; }

.badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.78em;
    font-weight: 600;
    margin-bottom: 6px;
}
.badge-think { background: #2d2660; color: #afa9ec; }
.badge-act   { background: #0a3d2e; color: #5dcaa5; }
.badge-obs   { background: #3d2c0a; color: #ef9f27; }
.badge-final { background: #1e3a5f; color: #85b7eb; }

.citation-card {
    background: #1e2130;
    border-left: 3px solid #4f8ef7;
    border-radius: 4px;
    padding: 12px 16px;
    margin: 8px 0;
    font-size: 0.85em;
}
.confidence-bar-wrap {
    background: #1e2130;
    border-radius: 20px;
    height: 8px;
    margin: 4px 0 8px;
    overflow: hidden;
}
.confidence-bar {
    height: 100%;
    border-radius: 20px;
    transition: width 0.4s;
}
.answer-box {
    background: #161b27;
    border: 1px solid #2d3348;
    border-radius: 8px;
    padding: 20px;
    margin: 12px 0;
    line-height: 1.7;
}
</style>
""", unsafe_allow_html=True)


@st.cache_resource(show_spinner="Loading AI models...")
def load_pipeline(embedding_model, llm_backend):
    from agentic_pipeline import AgenticRAGPipeline
    return AgenticRAGPipeline(
        embedding_model=embedding_model,
        llm_backend=llm_backend,
        data_dir="data"
    )


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuration")
    st.markdown("---")

    embedding_model = st.selectbox("Embedding Model", [
        "BAAI/bge-base-en-v1.5",
        "BAAI/bge-large-en-v1.5",
        "intfloat/e5-base-v2",
        "sentence-transformers/all-MiniLM-L6-v2",
    ])

    llm_backend = st.selectbox("LLM Backend",
        ["auto", "ollama", "openai", "anthropic"])

    st.markdown("---")
    openai_key = st.text_input("OpenAI API Key", type="password", placeholder="sk-...")
    anthropic_key = st.text_input("Anthropic API Key", type="password", placeholder="sk-ant-...")
    if openai_key: os.environ["OPENAI_API_KEY"] = openai_key
    if anthropic_key: os.environ["ANTHROPIC_API_KEY"] = anthropic_key

    st.markdown("---")
    st.markdown("### 🤖 Agentic Mode")
    st.markdown("""
    **Simple RAG**: One retrieval pass → answer.  
    Fast but shallow.
    
    **Agentic ReAct**: Multi-hop loop with tools.  
    - Retrieves, evaluates, re-searches  
    - Self-scores confidence  
    - Stops when satisfied  
    - Shows full reasoning trace
    """)
    st.markdown("---")
    st.caption("Run `ollama pull mistral` for local LLM")


# ── Load pipeline ─────────────────────────────────────────────────────────────
try:
    pipeline = load_pipeline(embedding_model, llm_backend)
except Exception as e:
    st.error(f"Pipeline init failed: {e}")
    st.stop()


# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("# 🤖 Agentic Research RAG")
st.markdown("*Multi-hop reasoning · Tool use · Self-evaluation · Citation grounding*")

stats = pipeline.get_stats()
c1, c2, c3 = st.columns(3)
c1.metric("Papers Indexed", stats.get("papers", 0))
c2.metric("Total Chunks", stats.get("total_chunks", 0))
c3.metric("Year Range", stats.get("year_range", "N/A"))
st.markdown("---")


# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_ingest, tab_query, tab_trace = st.tabs([
    "📥 Ingest Papers",
    "🤖 Ask (Agentic)",
    "🔍 Trace Inspector"
])


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1: INGEST
# ══════════════════════════════════════════════════════════════════════════════
with tab_ingest:
    st.markdown("### Fetch and index papers from arXiv")

    col_l, col_r = st.columns([2, 1])
    with col_l:
        search_query = st.text_input("Research Topic", 
            placeholder="e.g., retrieval augmented generation, LoRA fine-tuning")
    with col_r:
        max_papers = st.slider("Max Papers", 1, 20, 5)

    c1, c2, c3 = st.columns(3)
    with c1:
        cat = st.selectbox("Category", ["All","cs.AI","cs.CL","cs.LG","cs.CV","cs.IR","stat.ML"])
        cat = None if cat == "All" else cat
    with c2:
        yf = st.number_input("From Year", value=2020, min_value=1990, max_value=2026)
    with c3:
        yt = st.number_input("To Year", value=2026, min_value=1990, max_value=2026)

    if st.button("🚀 Fetch & Index", type="primary", disabled=not search_query):
        prog = st.progress(0)
        stat_txt = st.empty()

        def cb(pct, msg):
            prog.progress(pct)
            stat_txt.text(msg)

        with st.spinner(""):
            try:
                results = pipeline.ingest_papers(
                    query=search_query, max_papers=max_papers,
                    category=cat, year_from=int(yf), year_to=int(yt),
                    progress_callback=cb
                )
                st.success(f"✅ Indexed {results['processed']} papers ({results['chunks_added']} new chunks)")
                for paper in results.get("papers", []):
                    with st.expander(f"📄 {paper['title'][:80]}"):
                        st.write(f"**Authors:** {', '.join(str(a) for a in paper['authors'])}")
                        st.write(f"**Year:** {paper['year']}")
                        st.write(f"**URL:** [{paper['url']}]({paper['url']})")
            except Exception as e:
                st.error(f"Ingestion failed: {e}")
                st.exception(e)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2: AGENTIC QUERY
# ══════════════════════════════════════════════════════════════════════════════
with tab_query:
    if stats.get("total_chunks", 0) == 0:
        st.info("👆 Please ingest some papers first using the **Ingest Papers** tab.")
    else:
        st.markdown("### Ask a research question")

        question = st.text_area(
            "Your Question",
            placeholder=(
                "e.g., How does RAG compare to fine-tuning for knowledge-intensive tasks?\n"
                "e.g., What are the key innovations in LoRA and how does it reduce memory?\n"
                "e.g., What benchmarks are used to evaluate retrieval systems?"
            ),
            height=100
        )

        c1, c2 = st.columns(2)
        with c1:
            mode = st.radio("Query Mode", ["🤖 Agentic (ReAct)", "⚡ Simple RAG"], horizontal=True)
            agentic = "Agentic" in mode

        with c2:
            max_iter = st.slider("Max iterations (agentic)", 2, 8, 4, disabled=not agentic)

        c1, c2, c3 = st.columns(3)
        with c1:
            yf_q = st.number_input("From Year", value=2020, min_value=1990, max_value=2026, key="qyf")
        with c2:
            yt_q = st.number_input("To Year", value=2026, min_value=1990, max_value=2026, key="qyt")
        with c3:
            author_f = st.text_input("Author filter", placeholder="e.g., Vaswani")

        if st.button("🔍 Search & Answer", type="primary", disabled=not question):

            if agentic:
                # ── AGENTIC MODE ──────────────────────────────────────────────
                st.markdown("### 🔄 Agent reasoning trace")
                trace_container = st.container()
                step_placeholders = {}

                def stream_cb(event_type, iteration, data):
                    """Called by agent at each step for live UI updates."""
                    key = f"step_{iteration}_{event_type}"
                    if event_type == "thinking":
                        with trace_container:
                            step_placeholders[key] = st.empty()
                            step_placeholders[key].markdown(
                                f'<div class="step-card step-think">'
                                f'<span class="badge badge-think">🤔 Think — Step {iteration}</span>'
                                f'<p style="color:var(--text-secondary);font-size:0.85em;margin:0">Reasoning...</p>'
                                f'</div>', unsafe_allow_html=True
                            )
                    elif event_type == "acting":
                        with trace_container:
                            step_placeholders[key] = st.empty()
                            step_placeholders[key].markdown(
                                f'<div class="step-card step-act">'
                                f'<span class="badge badge-act">🔧 Act — Step {iteration}</span>'
                                f'<p style="color:var(--text-secondary);font-size:0.85em;margin:0">Calling: <code>{data}</code></p>'
                                f'</div>', unsafe_allow_html=True
                            )
                    elif event_type == "observed":
                        with trace_container:
                            step_placeholders[key] = st.empty()
                            step_placeholders[key].markdown(
                                f'<div class="step-card step-obs">'
                                f'<span class="badge badge-obs">👁 Observe — Step {iteration}</span>'
                                f'<p style="color:var(--text-secondary);font-size:0.85em;margin:0">{str(data)[:200]}...</p>'
                                f'</div>', unsafe_allow_html=True
                            )
                    elif event_type == "done":
                        with trace_container:
                            st.markdown(
                                f'<div class="step-card" style="border-left:3px solid #4f8ef7">'
                                f'<span class="badge badge-final">✅ Final synthesis — Step {iteration}</span>'
                                f'</div>', unsafe_allow_html=True
                            )

                # Override max iterations
                pipeline.react_agent.max_iterations = max_iter

                with st.spinner("Agent running..."):
                    try:
                        result = pipeline.query_agentic(
                            question=question,
                            year_from=int(yf_q) if yf_q else None,
                            year_to=int(yt_q) if yt_q else None,
                            author=author_f if author_f else None,
                            stream_callback=stream_cb
                        )

                        # Store trace in session state for the Trace tab
                        st.session_state["last_trace"] = result.get("trace", "")
                        st.session_state["last_memory"] = result.get("memory")

                        # ── Answer ───────────────────────────────────────────
                        st.markdown("---")
                        st.markdown("### 🤖 Answer")

                        conf = result.get("confidence", 0)
                        conf_color = "#1d9e75" if conf >= 0.75 else "#ba7517" if conf >= 0.5 else "#d85a30"
                        st.markdown(
                            f'<div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">'
                            f'<span style="color:var(--text-secondary);font-size:0.85em">Confidence: {conf:.0%}</span>'
                            f'<div class="confidence-bar-wrap" style="flex:1">'
                            f'<div class="confidence-bar" style="width:{conf*100:.0f}%;background:{conf_color}"></div>'
                            f'</div>'
                            f'<span style="color:var(--text-secondary);font-size:0.85em">{result.get("steps",0)} steps</span>'
                            f'</div>',
                            unsafe_allow_html=True
                        )

                        st.markdown(
                            f'<div class="answer-box">{result["answer"]}</div>',
                            unsafe_allow_html=True
                        )
                        st.caption(f"*{result.get('model_used','unknown')}*")

                        # ── Citations ────────────────────────────────────────
                        if result.get("citations"):
                            st.markdown("### 📚 Sources Cited")
                            for cit in result["citations"]:
                                st.markdown(
                                    f'<div class="citation-card">'
                                    f'<strong>[{cit.number}]</strong> {cit.title}<br>'
                                    f'<small>{cit.authors} · {cit.year}</small> '
                                    f'<a href="{cit.url}" target="_blank">🔗 arXiv</a>'
                                    f'</div>',
                                    unsafe_allow_html=True
                                )

                    except Exception as e:
                        st.error(f"Agentic query failed: {e}")
                        st.exception(e)

            else:
                # ── SIMPLE RAG MODE ───────────────────────────────────────────
                with st.spinner("Retrieving and generating..."):
                    try:
                        response = pipeline.query_simple(
                            question=question,
                            year_from=int(yf_q) if yf_q else None,
                            year_to=int(yt_q) if yt_q else None,
                            author=author_f if author_f else None,
                        )
                        st.markdown("### ⚡ Answer (Simple RAG)")
                        st.markdown(
                            f'<div class="answer-box">{response.answer}</div>',
                            unsafe_allow_html=True
                        )
                        st.caption(f"*{response.model_used}*")

                        if response.citations:
                            st.markdown("### 📚 Sources")
                            for cit in response.citations:
                                st.markdown(
                                    f'<div class="citation-card">'
                                    f'<strong>[{cit.number}]</strong> {cit.title}<br>'
                                    f'<small>{cit.authors} · {cit.year}</small>'
                                    f'</div>',
                                    unsafe_allow_html=True
                                )
                    except Exception as e:
                        st.error(f"Query failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3: TRACE INSPECTOR
# ══════════════════════════════════════════════════════════════════════════════
with tab_trace:
    st.markdown("### 🔍 ReAct Trace Inspector")
    st.caption("Full step-by-step reasoning trace from the last agentic query.")

    if "last_trace" not in st.session_state:
        st.info("Run an agentic query first to see the reasoning trace here.")
    else:
        trace = st.session_state["last_trace"]
        memory = st.session_state.get("last_memory")

        if memory:
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Steps taken", memory.iteration_count)
            c2.metric("Chunks accumulated", len(memory.retrieved_chunks))
            c3.metric("Papers seen", len(memory.papers_seen))
            c4.metric("Final confidence", f"{memory.last_confidence:.0%}")

            st.markdown("#### Tool calls")
            for tool, count in memory.tool_call_counts.items():
                st.markdown(f"- `{tool}`: called {count}× ")

            st.markdown("#### Queries searched")
            for q in memory.searched_queries:
                st.markdown(f"- `{q}`")

        st.markdown("#### Full trace")
        st.text(trace)
